#!/bin/bash
# ============================================================
# Go2 红蓝双色物体跟踪器 启动脚本
# 隔离 ROS2 DDS 环境，使用 SDK2 自有 DDS 库
# ============================================================
# 用法: ./run_red_tracker.sh [网卡名] [--no-move] [--no-lock]
# 示例: ./run_red_tracker.sh enp8s0
#       ./run_red_tracker.sh enp8s0 --no-move
#       ./run_red_tracker.sh enp8s0 --no-lock
# ============================================================

set -e

# 获取脚本所在目录 (支持软链接)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BINARY="${SCRIPT_DIR}/build/red_tracker"

# ===== SDK2 库路径配置 =====
# 默认路径，可通过环境变量覆盖
SDK2_ROOT="${UNITREE_SDK2_ROOT:-$HOME/unitree_sdk2}"
SDK2_LIB="${SDK2_ROOT}/lib/x86_64"
SDK2_DDS="${SDK2_ROOT}/thirdparty/lib/x86_64"

# ===== 清除 ROS2 环境变量，避免 DDS 冲突 =====
unset RMW_IMPLEMENTATION
unset CYCLONEDDS_URI
unset AMENT_PREFIX_PATH
unset ROS_DISTRO

# ===== 优先加载 SDK2 的 DDS 动态库 =====
export LD_LIBRARY_PATH="${SDK2_DDS}:${SDK2_LIB}:${LD_LIBRARY_PATH}"

# ===== 默认网卡 =====
NET_IF="${1:-enp8s0}"

# 检查二进制是否存在
if [ ! -x "$BINARY" ]; then
  echo "[ERROR] 找不到可执行文件: $BINARY"
  echo "请先编译: cd build && cmake .. && make -j\$(nproc)"
  exit 1
fi

echo "============================================"
echo "  Go2 红蓝双色物体跟踪器 v3"
echo "============================================"
echo "  网络接口 : ${NET_IF}"
echo "  SDK2 路径: ${SDK2_ROOT}"
echo "  二进制   : ${BINARY}"
echo "============================================"

exec "$BINARY" "$NET_IF" "$@"
