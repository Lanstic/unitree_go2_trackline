/**********************************************************************
 * icon_detector.hpp — Go2 警告标志识别器
 *
 * 检测流程:
 *   1. BGR → HSV, 提取黄/橙色掩码 (标志边框底色)
 *   2. 轮廓检测 + approxPolyDP 筛选三角形
 *   3. 提取三角形内部 ROI 二值化符号
 *   4. 模板匹配 (TM_CCOEFF_NORMED) 识别内部符号类型
 *
 * 支持的标志类型:
 *   - ELECTRIC_SHOCK  (当心触电 — 闪电符号)
 *   - OXIDIZER        (当心强氧化物 — 火焰符号)
 *   - RADIATION       (当心辐射 — 三叶形符号)
 **********************************************************************/

#pragma once

#include <opencv2/opencv.hpp>

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <map>
#include <string>
#include <vector>

// ============================================================
// 图标类型枚举
// ============================================================
enum class IconType : uint8_t {
  NONE            = 0,  ///< 未检测到
  ELECTRIC_SHOCK  = 1,  ///< 当心触电 (闪电)
  OXIDIZER        = 2,  ///< 当心强氧化物 (火焰)
  RADIATION       = 3,  ///< 当心辐射 (三叶形)
};

/// @brief 图标类型 → 可读字符串
inline const char* IconTypeName(IconType t) {
  switch (t) {
    case IconType::ELECTRIC_SHOCK: return "ELECTRIC_SHOCK";
    case IconType::OXIDIZER:       return "OXIDIZER";
    case IconType::RADIATION:      return "RADIATION";
    default:                       return "NONE";
  }
}

// ============================================================
// 单次检测结果
// ============================================================
struct IconDetection {
  IconType   type       = IconType::NONE;   ///< 图标类型
  double     confidence = 0.0;              ///< 置信度 0~1
  cv::Rect   bounding_box;                   ///< 在画面中的外接矩形
  int64_t    timestamp_ms = 0;               ///< 检测时刻 (毫秒)
};

// ============================================================
// 图标检测器参数
// ============================================================
struct IconDetectParams {
  // ---- 颜色分割 (支持黄色和橙色/红色标志) ----
  int hue_yellow_low      = 15;     ///< 黄色 H 下限
  int hue_yellow_high     = 35;     ///< 黄色 H 上限
  int hue_orange_low      = 0;      ///< 橙色 H 下限 (支持红色背景标志)
  int hue_orange_high     = 20;     ///< 橙色 H 上限
  int sat_min             = 80;     ///< 最小饱和度
  int val_min             = 100;    ///< 最小明度

  // ---- 轮廓过滤 ----
  double area_min       = 500.0;    ///< 最小轮廓面积 (像素²) — 与Python版一致
  double area_max_ratio = 0.8;     ///< 最大面积占比 (相对于图像面积)
  double triangle_eps   = 0.02;    ///< approxPolyDP 精度系数 — 与Python版一致

  // ---- 三角形有效性 ----
  double min_side_len   = 20.0;    ///< 最短边最小长度 (像素)
  double max_side_ratio = 1.6;    ///< 最长边/(最短边+次短边) 最大比例

  // ---- 内部符号识别 ----
  int    template_size  = 80;     ///< 模板尺寸 — 与Python版一致
  double match_threshold = 0.15;   ///< 模板匹配最低分数 — 与Python版一致

  // ---- 检测节流 ----
  int detect_interval_frames = 8;  ///< 每隔 N 帧执行一次全检测
};

// ============================================================
// 图标检测器主类
// ============================================================
class IconDetector {
public:
  IconDetector() = default;

  /// @brief 设置参数
  void SetParams(const IconDetectParams& params) { params_ = params; }

  /// @brief 获取参数 (可修改)
  IconDetectParams& Params() { return params_; }

  /// @brief 加载标志图片作为模板
  /// @param file_path 标志图片路径 (完整的警告三角形图)
  /// @param type      对应的图标类型
  /// @return true 加载成功
  bool LoadSingleTemplate(const std::string& file_path, IconType type);

  /// @brief 加载参考图标合成图 (包含三个模板的并排图像)
  /// @param ref_path  参考图标图片路径
  /// @return true 加载成功
  bool LoadReferenceIcons(const std::string& ref_path);

  /// @brief 对一帧图像执行图标检测
  /// @param frame      BGR 输入帧
  /// @param frame_idx  帧序号 (用于检测节流)
  /// @return 检测结果列表 (按置信度降序)
  std::vector<IconDetection> Detect(const cv::Mat& frame, int frame_idx);

  /// @brief 获取调试可视化图
  cv::Mat GetDebugVis() const { return debug_vis_.clone(); }

private:
  IconDetectParams params_;

  // 调试可视化
  mutable cv::Mat debug_vis_;

  // 模板: 80x80 二值图 (与Python版TEMPLATE_SIZE一致)
  static constexpr int kTemplateSize = 80;
  std::map<IconType, cv::Mat> templates_;

  // ---- 内部方法 ----

  /// @brief 提取黄色掩码
  cv::Mat GetYellowMask(const cv::Mat& frame_bgr) const;

  /// @brief 提取橙色/红色掩码 (用于红色背景的标志)
  cv::Mat GetOrangeMask(const cv::Mat& frame_bgr) const;

  /// @brief 合并黄/橙色掩码
  cv::Mat GetCombinedMask(const cv::Mat& frame_bgr) const;

  /// @brief 从轮廓中筛选有效三角形
  bool IsValidTriangle(const std::vector<cv::Point>& contour,
                       std::vector<cv::Point>& out_triangle,
                       double eps_pct = 0.02) const;

  /// @brief 提取三角形内部符号二值图 (核心: 仿Python版_extract_inner_symbol_bin)
  cv::Mat ExtractInnerSymbol(const cv::Mat& frame_bgr,
                             const std::vector<cv::Point>& triangle,
                             const cv::Rect& sign_bbox) const;

  /// @brief 模板匹配识别内部符号 (与Python版_identify_inner_symbol一致)
  IconType MatchByTemplate(const cv::Mat& binary_norm,
                           double* out_confidence = nullptr) const;

  /// @brief 识别ROI中的内部符号 (与Python版 _identify_inner_symbol 一致)
  IconType IdentifyInnerSymbol(const cv::Mat& roi, double* out_confidence) const;

  /// @brief 提取符号ROI (用于更精确的模板匹配)
  cv::Mat ExtractSymbolROI(const cv::Mat& roi_bgr) const;
};

// ============================================================
// 实现
// ============================================================

// ExtractSymbolFromSign removed - using inline code

inline bool IconDetector::LoadSingleTemplate(const std::string& file_path, IconType type) {
  cv::Mat img = cv::imread(file_path, cv::IMREAD_COLOR);
  if (img.empty()) {
    std::cerr << "[IconDetector] 无法读取: " << file_path << std::endl;
    return false;
  }

  // 检测图中的黄色/橙色三角形边框
  cv::Mat yellow = GetYellowMask(img);
  cv::Mat orange = GetOrangeMask(img);
  cv::Mat border = yellow | orange;

  std::vector<std::vector<cv::Point>> contours;
  cv::findContours(border, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
  if (contours.empty()) {
    std::cerr << "[IconDetector] 未在 " << file_path << " 中找到标志边框" << std::endl;
    return false;
  }

  // 选最大轮廓
  int best_i = 0; double best_a = 0;
  for (size_t i = 0; i < contours.size(); ++i) {
    double a = cv::contourArea(contours[i]);
    if (a > best_a) { best_a = a; best_i = static_cast<int>(i); }
  }

  // 渐进式epsilon验证三角形 (与Detect一致)
  // 不同图标在不同epsilon下表现不同:
  //   - ELECTRIC_SHOCK: eps=2%正确
  //   - OXIDIZER/RADIATION: 需要eps>=2.5%
  std::vector<double> eps_candidates = {0.02, 0.025, 0.03};
  std::vector<cv::Point> tri;
  bool found_triangle = false;

  for (double eps_pct : eps_candidates) {
    double arc_len = cv::arcLength(contours[best_i], true);
    double eps = eps_pct * arc_len;
    std::vector<cv::Point> poly;
    cv::approxPolyDP(contours[best_i], poly, eps, true);

    if (poly.size() == 3) {
      // 验证边长比例
      std::vector<double> sides;
      for (int i = 0; i < 3; ++i) {
        sides.push_back(cv::norm(poly[i] - poly[(i + 1) % 3]));
      }
      std::sort(sides.begin(), sides.end());
      if (sides[2] < (sides[0] + sides[1]) * params_.max_side_ratio && sides[0] >= params_.min_side_len) {
        tri = poly;
        found_triangle = true;
        break;
      }
    }
  }

  if (!found_triangle) {
    std::cerr << "[IconDetector] " << file_path << " 中轮廓非有效三角形" << std::endl;
    return false;
  }

  // 提取内部符号 - 使用与Python版 _extract_inner_symbol_bin 一致的方式
  // 在三角形区域内提取黑色符号的最小外接矩形
  cv::Mat mask = cv::Mat::zeros(img.size(), CV_8UC1);
  std::vector<std::vector<cv::Point>> pts = {tri};
  cv::fillPoly(mask, pts, cv::Scalar(255));

  // 裁剪ROI
  cv::Rect bbox = cv::boundingRect(tri);
  int pad = 5;
  bbox.x = std::max(0, bbox.x - pad);
  bbox.y = std::max(0, bbox.y - pad);
  bbox.width  = std::min(img.cols - bbox.x, bbox.width  + 2 * pad);
  bbox.height = std::min(img.rows - bbox.y, bbox.height + 2 * pad);

  cv::Mat roi_mask = mask(bbox);
  cv::Mat roi_bgr = img(bbox);

  // 提取黑色像素
  cv::Mat gray;
  cv::cvtColor(roi_bgr, gray, cv::COLOR_BGR2GRAY);
  cv::Mat black;
  cv::inRange(gray, cv::Scalar(0), cv::Scalar(80), black);
  cv::Mat inner;
  cv::bitwise_and(black, roi_mask, inner);

  // 找最大黑色连通域
  std::vector<std::vector<cv::Point>> cnts;
  cv::findContours(inner, cnts, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
  if (cnts.empty()) {
    std::cerr << "[IconDetector] " << file_path << " 提取符号失败" << std::endl;
    return false;
  }

  auto largest = std::max_element(cnts.begin(), cnts.end(),
    [](const std::vector<cv::Point>& a, const std::vector<cv::Point>& b) {
      return cv::contourArea(a) < cv::contourArea(b);
    });

  // 返回最大连通域的外接矩形区域
  cv::Rect sym_bbox = cv::boundingRect(*largest);
  cv::Mat sym = inner(sym_bbox);

  if (sym.empty()) {
    std::cerr << "[IconDetector] " << file_path << " 提取符号失败" << std::endl;
    return false;
  }

  cv::Mat tmpl;
  // ★ 使用 INTER_LINEAR 而非 INTER_AREA
  if (sym.rows >= 2 && sym.cols >= 2) {
    cv::resize(sym, tmpl, cv::Size(kTemplateSize, kTemplateSize), 0, 0, cv::INTER_LINEAR);
  } else {
    cv::copyMakeBorder(sym, tmpl, 0, kTemplateSize - sym.rows,
                       0, kTemplateSize - sym.cols,
                       cv::BORDER_REPLICATE);
    cv::resize(tmpl, tmpl, cv::Size(kTemplateSize, kTemplateSize), 0, 0, cv::INTER_LINEAR);
  }
  cv::threshold(tmpl, tmpl, 127, 255, cv::THRESH_BINARY);
  templates_[type] = tmpl;

  std::cout << "[IconDetector] 模板已加载: " << IconTypeName(type)
            << " (" << file_path << ") 符号尺寸: " << sym.cols << "x" << sym.rows
            << " → " << kTemplateSize << "x" << kTemplateSize
            << " 黑色像素: " << cv::countNonZero(tmpl) << std::endl;
  return true;
}

// 从 reference_icons.png 批量加载模板
inline bool IconDetector::LoadReferenceIcons(const std::string& ref_path) {
  std::cout << "[ICON_DBG] LoadReferenceIcons: 读取 " << ref_path << std::endl;
  cv::Mat ref = cv::imread(ref_path, cv::IMREAD_COLOR);
  if (ref.empty()) {
    std::cerr << "[IconDetector] 无法读取参考图标: " << ref_path << std::endl;
    return false;
  }
  std::cout << "[ICON_DBG] 读入图像 " << ref.cols << "x" << ref.rows << " channels=" << ref.channels() << std::endl;

  // reference_icons.png 中三个模板的位置 (与Python版一致)
  // positions = [(233, 126), (481, 128), (731, 127)]
  const int icon_width = 185;
  const int icon_height = 160;
  std::vector<std::pair<IconType, cv::Point>> icon_positions = {
    {IconType::ELECTRIC_SHOCK, cv::Point(233, 126)},
    {IconType::OXIDIZER,       cv::Point(481, 128)},
    {IconType::RADIATION,      cv::Point(731, 127)},
  };

  for (const auto& [itype, pos] : icon_positions) {
    std::cout << "[ICON_DBG] 处理 " << IconTypeName(itype) << " 位置(" << pos.x << "," << pos.y << ")" << std::endl;
    cv::Rect roi_rect(pos.x, pos.y, icon_width, icon_height);
    if (pos.x + icon_width > ref.cols || pos.y + icon_height > ref.rows) {
      std::cerr << "[IconDetector] 参考图标 ROI 超出范围: " << IconTypeName(itype) << std::endl;
      continue;
    }
    cv::Mat roi = ref(roi_rect);
    std::cout << "[ICON_DBG] ROI " << roi.cols << "x" << roi.rows << std::endl;

    // Inline symbol extraction (matches Python _extract_inner_symbol_bin)
    cv::Mat gray;
    cv::cvtColor(roi, gray, cv::COLOR_BGR2GRAY);
    std::cout << "[ICON_DBG]   cvtColor ok, gray=" << gray.cols << "x" << gray.rows << std::endl;

    cv::Mat black;
    cv::inRange(gray, cv::Scalar(0), cv::Scalar(80), black);
    std::cout << "[ICON_DBG]   inRange(black) ok, nz=" << cv::countNonZero(black) << std::endl;

    cv::Mat hsv;
    cv::cvtColor(roi, hsv, cv::COLOR_BGR2HSV);
    std::cout << "[ICON_DBG]   cvtColor(HSV) ok" << std::endl;

    cv::Mat yellow;
    cv::inRange(hsv, cv::Scalar(15, 80, 100), cv::Scalar(35, 255, 255), yellow);
    std::cout << "[ICON_DBG]   inRange(yellow) ok" << std::endl;

    cv::Mat orange;
    cv::inRange(hsv, cv::Scalar(0, 100, 100), cv::Scalar(20, 255, 255), orange);
    std::cout << "[ICON_DBG]   inRange(orange) ok" << std::endl;

    cv::Mat border = yellow | orange;
    std::cout << "[ICON_DBG]   border union ok" << std::endl;

    std::vector<std::vector<cv::Point>> cnts;
    cv::findContours(border, cnts, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
    std::cout << "[ICON_DBG]   findContours(border) → " << cnts.size() << " contours" << std::endl;
    if (cnts.empty()) {
      std::cerr << "[IconDetector] 提取符号失败: " << IconTypeName(itype) << std::endl;
      continue;
    }

    auto largest = std::max_element(cnts.begin(), cnts.end(),
      [](const std::vector<cv::Point>& a, const std::vector<cv::Point>& b) {
        return cv::contourArea(a) < cv::contourArea(b);
      });

    cv::Mat mask = cv::Mat::zeros(gray.size(), CV_8UC1);
    std::vector<std::vector<cv::Point>> largest_vec = {*largest};
    cv::drawContours(mask, largest_vec, -1, cv::Scalar(255), -1);
    std::cout << "[ICON_DBG]   drawContours ok" << std::endl;

    cv::Mat black_inside;
    cv::bitwise_and(black, mask, black_inside);
    std::cout << "[ICON_DBG]   bitwise_and ok" << std::endl;

    std::vector<std::vector<cv::Point>> black_cnts;
    cv::findContours(black_inside, black_cnts, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
    std::cout << "[ICON_DBG]   findContours(black) → " << black_cnts.size() << " contours" << std::endl;
    if (black_cnts.empty()) {
      std::cerr << "[IconDetector] 提取符号失败: " << IconTypeName(itype) << std::endl;
      continue;
    }

    auto largest_black = std::max_element(black_cnts.begin(), black_cnts.end(),
      [](const std::vector<cv::Point>& a, const std::vector<cv::Point>& b) {
        return cv::contourArea(a) < cv::contourArea(b);
      });

    cv::Rect sym_bbox = cv::boundingRect(*largest_black);
    std::cout << "[ICON_DBG]   sym_bbox=(" << sym_bbox.x << "," << sym_bbox.y << "," << sym_bbox.width << "," << sym_bbox.height << ")" << std::endl;
    cv::Mat sym_bin = black_inside(sym_bbox);

    if (sym_bin.empty()) {
      std::cerr << "[IconDetector] 提取符号失败: " << IconTypeName(itype) << std::endl;
      continue;
    }

    cv::Mat tmpl;
    // ★ 使用 INTER_LINEAR 而非 INTER_AREA: sym_bin 可能极小(1x1),
    //   INTER_AREA 在极小源图像上可能导致 OpenCV 内部断言失败
    if (sym_bin.rows >= 2 && sym_bin.cols >= 2) {
      cv::resize(sym_bin, tmpl, cv::Size(kTemplateSize, kTemplateSize), 0, 0, cv::INTER_LINEAR);
    } else {
      cv::copyMakeBorder(sym_bin, tmpl, 0, kTemplateSize - sym_bin.rows,
                         0, kTemplateSize - sym_bin.cols,
                         cv::BORDER_REPLICATE);
      cv::resize(tmpl, tmpl, cv::Size(kTemplateSize, kTemplateSize), 0, 0, cv::INTER_LINEAR);
    }
    std::cout << "[ICON_DBG]   resize ok, tmpl=" << tmpl.cols << "x" << tmpl.rows << " nz=" << cv::countNonZero(tmpl) << std::endl;
    templates_[itype] = tmpl;
    std::cout << "[IconDetector] 模板已加载: " << IconTypeName(itype)
              << " 黑色像素: " << cv::countNonZero(tmpl) << std::endl;
  }

  return !templates_.empty();
}

inline cv::Mat IconDetector::GetYellowMask(const cv::Mat& frame_bgr) const {
  cv::Mat hsv;
  cv::cvtColor(frame_bgr, hsv, cv::COLOR_BGR2HSV);
  cv::Mat mask;
  cv::inRange(hsv,
              cv::Scalar(params_.hue_yellow_low, params_.sat_min, params_.val_min),
              cv::Scalar(params_.hue_yellow_high, 255, 255),
              mask);
  return mask;
}

inline cv::Mat IconDetector::GetOrangeMask(const cv::Mat& frame_bgr) const {
  cv::Mat hsv;
  cv::cvtColor(frame_bgr, hsv, cv::COLOR_BGR2HSV);
  cv::Mat mask;
  cv::inRange(hsv,
              cv::Scalar(params_.hue_orange_low, params_.sat_min, params_.val_min),
              cv::Scalar(params_.hue_orange_high, 255, 255),
              mask);
  return mask;
}

inline cv::Mat IconDetector::GetCombinedMask(const cv::Mat& frame_bgr) const {
  cv::Mat yellow = GetYellowMask(frame_bgr);
  cv::Mat orange = GetOrangeMask(frame_bgr);
  return yellow | orange;
}

// 形态学处理辅助函数
// 尝试不同的形态学配置，直到找到有效的三角形
// 返回值: pair<bool, Mat> - first表示是否需要继续处理, second是处理后的掩码
inline bool TryMorphologyConfig(const cv::Mat& bg_mask,
                                int morph_type,   // 0=none, 1=open, 2=close
                                int morph_iter,
                                cv::Mat& out_mask) {
  if (morph_type == 0) {
    out_mask = bg_mask.clone();
    return true;
  }

  cv::Mat kernel = cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(3, 3));
  if (morph_type == 1) {  // OPEN
    cv::morphologyEx(bg_mask, out_mask, cv::MORPH_OPEN, kernel, cv::Point(-1,-1), morph_iter);
  } else {  // CLOSE
    cv::morphologyEx(bg_mask, out_mask, cv::MORPH_CLOSE, kernel, cv::Point(-1,-1), morph_iter);
  }
  return true;
}

inline bool IconDetector::IsValidTriangle(
    const std::vector<cv::Point>& contour,
    std::vector<cv::Point>& out_triangle,
    double eps_pct) const {
  // 多边形逼近 (支持可配置epsilon)
  double eps = eps_pct * cv::arcLength(contour, true);
  std::vector<cv::Point> poly;
  cv::approxPolyDP(contour, poly, eps, true);

  if (poly.size() != 3) return false;

  // 计算边长
  std::vector<double> sides;
  for (int i = 0; i < 3; ++i) {
    sides.push_back(cv::norm(poly[i] - poly[(i + 1) % 3]));
  }
  std::sort(sides.begin(), sides.end());

  // Python版有效性检查: s[2] < (s[0] + s[1]) * 1.6 and s[0] > 20
  if (sides[2] >= (sides[0] + sides[1]) * params_.max_side_ratio) return false;
  if (sides[0] < params_.min_side_len) return false;

  out_triangle = poly;
  return true;
}

// 提取三角形内部符号二值图 (仿Python版 _extract_inner_symbol_bin)
inline cv::Mat IconDetector::ExtractInnerSymbol(
    const cv::Mat& frame_bgr,
    const std::vector<cv::Point>& triangle,
    const cv::Rect& /*sign_bbox*/) const {

  // 创建三角形掩码
  cv::Mat mask = cv::Mat::zeros(frame_bgr.size(), CV_8UC1);
  std::vector<std::vector<cv::Point>> pts = {triangle};
  cv::fillPoly(mask, pts, cv::Scalar(255));

  // 裁剪 ROI (与Python版一致: boundingRect + 5px margin)
  cv::Rect bbox = cv::boundingRect(triangle);
  int pad = 5;
  bbox.x = std::max(0, bbox.x - pad);
  bbox.y = std::max(0, bbox.y - pad);
  bbox.width  = std::min(frame_bgr.cols - bbox.x, bbox.width  + 2 * pad);
  bbox.height = std::min(frame_bgr.rows - bbox.y, bbox.height + 2 * pad);

  cv::Mat roi_mask = mask(bbox);

  // 提取黑色像素 (gray 0~80)
  cv::Mat gray;
  cv::cvtColor(frame_bgr(bbox), gray, cv::COLOR_BGR2GRAY);
  cv::Mat black;
  cv::inRange(gray, cv::Scalar(0), cv::Scalar(80), black);

  // 仅保留三角形内的黑色像素 - 返回整个ROI区域而非符号bbox
  // 这样对倾斜的图片也能保持一致性
  cv::Mat inner;
  cv::bitwise_and(black, roi_mask, inner);

  // 返回整个ROI区域用于匹配（更鲁棒）
  return inner.clone();
}

inline cv::Mat IconDetector::ExtractSymbolROI(const cv::Mat& roi_bgr) const {
  cv::Mat gray;
  cv::cvtColor(roi_bgr, gray, cv::COLOR_BGR2GRAY);
  cv::Mat black;
  cv::inRange(gray, cv::Scalar(0), cv::Scalar(80), black);

  std::vector<std::vector<cv::Point>> cnts;
  cv::findContours(black, cnts, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
  if (cnts.empty()) return cv::Mat();

  auto largest = std::max_element(cnts.begin(), cnts.end(),
    [](const std::vector<cv::Point>& a, const std::vector<cv::Point>& b) {
      return cv::contourArea(a) < cv::contourArea(b);
    });

  cv::Rect sym_bbox = cv::boundingRect(*largest);
  return black(sym_bbox).clone();
}

// 模板匹配识别 (与Python版 _identify_inner_symbol 一致的逻辑)
inline IconType IconDetector::MatchByTemplate(const cv::Mat& binary_norm,
                                             double* out_confidence) const {
  if (templates_.empty()) {
    if (out_confidence) *out_confidence = 0.0;
    return IconType::NONE;
  }

  // 归一化到模板尺寸
  cv::Mat detected;
  cv::resize(binary_norm, detected, cv::Size(kTemplateSize, kTemplateSize), 0, 0, cv::INTER_AREA);
  cv::threshold(detected, detected, 127, 255, cv::THRESH_BINARY);

  // 检查黑色像素比例 (放宽限制以适应不同场景)
  int nz = cv::countNonZero(detected);
  int total = kTemplateSize * kTemplateSize;
  double black_ratio = static_cast<double>(nz) / total;
  // 极宽范围：3% - 85%
  if (black_ratio < 0.03 || black_ratio > 0.85) {
    if (out_confidence) *out_confidence = 0.0;
    return IconType::NONE;
  }

  // 对每个模板计算 TM_CCOEFF_NORMED 分数
  IconType best_type = IconType::NONE;
  double best_score = 0.0;

  for (const auto& [itype, tmpl] : templates_) {
    if (tmpl.empty()) continue;

    cv::Mat result;
    cv::matchTemplate(detected, tmpl, result, cv::TM_CCOEFF_NORMED);

    if (result.empty() || result.cols < 1 || result.rows < 1) continue;

    double score = static_cast<double>(result.at<float>(0, 0));

    if (score > best_score) {
      best_score = score;
      best_type = itype;
    }
  }

  // 进一步降低阈值以提高识别灵敏度
  // 实际场景中标志可能倾斜/模糊，匹配分数较低
  double effective_threshold = 0.05;  // 降低阈值到 0.05
  if (best_score < effective_threshold) {
    if (out_confidence) *out_confidence = 0.0;
    return IconType::NONE;
  }

  if (out_confidence) *out_confidence = std::min(best_score, 1.0);
  return best_type;
}

// 识别ROI中的内部符号 (与Python版 _identify_inner_symbol 一致)
inline IconType IconDetector::IdentifyInnerSymbol(
    const cv::Mat& roi, double* out_confidence) const {

  if (roi.empty()) {
    if (out_confidence) *out_confidence = 0.0;
    return IconType::NONE;
  }

  int roi_h = roi.rows, roi_w = roi.cols;

  // 使用BGR颜色空间检测黑色 (与Python版一致)
  cv::Mat black_mask;
  cv::inRange(roi, cv::Scalar(0, 0, 0), cv::Scalar(80, 80, 80), black_mask);

  // 找最大黑色连通域
  std::vector<std::vector<cv::Point>> cnts;
  cv::findContours(black_mask, cnts, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
  if (cnts.empty()) {
    if (out_confidence) *out_confidence = 0.0;
    return IconType::NONE;
  }

  auto largest = std::max_element(cnts.begin(), cnts.end(),
    [](const std::vector<cv::Point>& a, const std::vector<cv::Point>& b) {
      return cv::contourArea(a) < cv::contourArea(b);
    });
  double cnt_area = cv::contourArea(*largest);
  double tri_area = roi_h * roi_w;

  // 验证黑色像素比例 (与Python版一致: 3% ~ 75%)
  if (cnt_area < tri_area * 0.03 || cnt_area > tri_area * 0.75) {
    if (out_confidence) *out_confidence = 0.0;
    return IconType::NONE;
  }

  // 提取符号ROI (与Python版 _extract_symbol_roi 一致)
  cv::Rect sym_bbox = cv::boundingRect(*largest);
  int pad = 2;
  int x1 = std::max(0, sym_bbox.x - pad);
  int y1 = std::max(0, sym_bbox.y - pad);
  int x2 = std::min(roi_w, sym_bbox.x + sym_bbox.width + pad);
  int y2 = std::min(roi_h, sym_bbox.y + sym_bbox.height + pad);

  if (x2 <= x1 || y2 <= y1) {
    if (out_confidence) *out_confidence = 0.0;
    return IconType::NONE;
  }

  cv::Mat symbol_roi = roi(cv::Rect(x1, y1, x2 - x1, y2 - y1));

  if (symbol_roi.rows < 5 || symbol_roi.cols < 5) {
    if (out_confidence) *out_confidence = 0.0;
    return IconType::NONE;
  }

  // 提取二值符号图 (与Python版 _extract_inner_symbol_bin 一致)
  cv::Mat gray;
  cv::cvtColor(symbol_roi, gray, cv::COLOR_BGR2GRAY);
  cv::Mat black;
  cv::inRange(gray, cv::Scalar(0), cv::Scalar(80), black);

  cv::Mat hsv;
  cv::cvtColor(symbol_roi, hsv, cv::COLOR_BGR2HSV);
  cv::Mat yellow;
  cv::inRange(hsv, cv::Scalar(15, 80, 100), cv::Scalar(35, 255, 255), yellow);
  cv::Mat orange;
  cv::inRange(hsv, cv::Scalar(0, 100, 100), cv::Scalar(20, 255, 255), orange);
  cv::Mat border = yellow | orange;

  cv::Mat border_mask = cv::Mat::zeros(gray.size(), CV_8UC1);
  std::vector<std::vector<cv::Point>> border_cnts;
  cv::findContours(border, border_cnts, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
  if (!border_cnts.empty()) {
    auto largest_border = std::max_element(border_cnts.begin(), border_cnts.end(),
      [](const std::vector<cv::Point>& a, const std::vector<cv::Point>& b) {
        return cv::contourArea(a) < cv::contourArea(b);
      });
    std::vector<std::vector<cv::Point>> border_largest = {*largest_border};
    cv::drawContours(border_mask, border_largest, -1, cv::Scalar(255), -1);
  }

  cv::Mat black_inside;
  cv::bitwise_and(black, border_mask, black_inside);

  // 提取符号
  std::vector<std::vector<cv::Point>> sym_cnts;
  cv::findContours(black_inside, sym_cnts, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
  if (sym_cnts.empty()) {
    if (out_confidence) *out_confidence = 0.0;
    return IconType::NONE;
  }

  auto largest_sym = std::max_element(sym_cnts.begin(), sym_cnts.end(),
    [](const std::vector<cv::Point>& a, const std::vector<cv::Point>& b) {
      return cv::contourArea(a) < cv::contourArea(b);
    });
  cv::Rect final_bbox = cv::boundingRect(*largest_sym);

  if (final_bbox.width < 5 || final_bbox.height < 5) {
    if (out_confidence) *out_confidence = 0.0;
    return IconType::NONE;
  }

  cv::Mat sym_bin = black_inside(final_bbox);

  if (sym_bin.empty() || sym_bin.cols <= 0 || sym_bin.rows <= 0) {
    if (out_confidence) *out_confidence = 0.0;
    return IconType::NONE;
  }

  // 归一化到模板尺寸
  cv::Mat detected;
  cv::resize(sym_bin, detected, cv::Size(kTemplateSize, kTemplateSize));

  if (detected.empty() || detected.cols != kTemplateSize || detected.rows != kTemplateSize) {
    if (out_confidence) *out_confidence = 0.0;
    return IconType::NONE;
  }

  if (templates_.empty()) {
    if (out_confidence) *out_confidence = 0.0;
    return IconType::NONE;
  }

  // 模板匹配 (与Python版一致: 阈值0.15)
  double best_score = 0.0;
  IconType best_type = IconType::NONE;

  for (const auto& [itype, tmpl] : templates_) {
    if (tmpl.empty() || tmpl.cols != kTemplateSize || tmpl.rows != kTemplateSize) continue;

    cv::Mat result;
    cv::matchTemplate(detected, tmpl, result, cv::TM_CCOEFF_NORMED);

    if (result.empty() || result.cols < 1 || result.rows < 1) continue;

    double score = static_cast<double>(result.at<float>(0, 0));

    if (score > best_score) {
      best_score = score;
      best_type = itype;
    }
  }

  if (best_score < 0.15) {
    if (out_confidence) *out_confidence = 0.0;
    return IconType::NONE;
  }

  if (out_confidence) *out_confidence = std::min(best_score, 1.0);
  return best_type;
}

inline std::vector<IconDetection> IconDetector::Detect(
    const cv::Mat& frame, int /*frame_idx*/) {
  std::vector<IconDetection> results;
  const int64_t now_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
      std::chrono::system_clock::now().time_since_epoch()).count();

  // 调试可视化
  debug_vis_ = frame.clone();
  int h = frame.rows, w = frame.cols;

  // 1. 合并的黄/橙色掩码
  cv::Mat combined_mask = GetCombinedMask(frame);

  // 2. 形态学处理 (与Python版完全一致)
  // CLOSE 2次填充缺口 + OPEN 1次去除噪声, 5x5矩形核
  cv::Mat kernel = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(5, 5));
  cv::morphologyEx(combined_mask, combined_mask, cv::MORPH_CLOSE, kernel, cv::Point(-1,-1), 2);
  cv::morphologyEx(combined_mask, combined_mask, cv::MORPH_OPEN, kernel, cv::Point(-1,-1), 1);

  // 3. 轮廓检测
  std::vector<std::vector<cv::Point>> contours;
  cv::findContours(combined_mask, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

  for (const auto& contour : contours) {
    double area = cv::contourArea(contour);

    // 面积过滤 (与Python版一致)
    if (area < 500 || area > h * w * 0.8) continue;

    // 三角形验证 (尝试多个epsilon: 2%, 2.5%, 3%)
    std::vector<cv::Point> approx;
    bool found_triangle = false;
    for (double eps_pct : {0.02, 0.025, 0.03}) {
      std::vector<cv::Point> approx_test;
      cv::approxPolyDP(contour, approx_test, eps_pct * cv::arcLength(contour, true), true);
      if (approx_test.size() == 3) {
        approx = approx_test;
        found_triangle = true;
        break;
      }
    }
    if (!found_triangle) continue;

    // 验证三角形有效性 (与Python版一致: s[2] < (s[0]+s[1])*1.6 and s[0] > 20)
    std::vector<double> sides;
    for (int i = 0; i < 3; ++i) {
      sides.push_back(cv::norm(approx[i] - approx[(i + 1) % 3]));
    }
    std::sort(sides.begin(), sides.end());
    if (sides[2] >= (sides[0] + sides[1]) * 1.6 || sides[0] < 20) continue;

    // 4. 提取ROI (与Python版一致)
    cv::Rect bbox = cv::boundingRect(approx);
    int pad = 5;
    int x1 = std::max(0, bbox.x - pad);
    int y1 = std::max(0, bbox.y - pad);
    int x2 = std::min(w, bbox.x + bbox.width + pad);
    int y2 = std::min(h, bbox.y + bbox.height + pad);

    cv::Mat roi = frame(cv::Rect(x1, y1, x2 - x1, y2 - y1));
    if (roi.empty()) continue;

    // 5. 识别内部符号 (与Python版_identify_inner_symbol一致)
    double confidence = 0.0;
    IconType icon_type = IdentifyInnerSymbol(roi, &confidence);

    if (icon_type == IconType::NONE) continue;

    // 绘制检测结果
    cv::Scalar color;
    switch (icon_type) {
      case IconType::ELECTRIC_SHOCK: color = cv::Scalar(0, 255, 255); break;
      case IconType::OXIDIZER:       color = cv::Scalar(0, 128, 255); break;
      case IconType::RADIATION:      color = cv::Scalar(128, 0, 255); break;
      default:                        color = cv::Scalar(255, 255, 255);
    }

    cv::polylines(debug_vis_, approx, true, color, 2);
    cv::rectangle(debug_vis_, bbox, color, 2);

    // 标签
    std::string label = std::string(IconTypeName(icon_type)) + " " +
                        std::to_string(static_cast<int>(confidence * 100)) + "%";
    int font_face = cv::FONT_HERSHEY_SIMPLEX;
    double font_scale = 0.5;
    int thickness = 2;
    cv::Size text_size = cv::getTextSize(label, font_face, font_scale, thickness, nullptr);

    cv::rectangle(debug_vis_,
                  cv::Point(bbox.x, bbox.y - text_size.height - 8),
                  cv::Point(bbox.x + text_size.width + 4, bbox.y),
                  color, -1);
    cv::putText(debug_vis_, label,
                cv::Point(bbox.x + 2, bbox.y - 4),
                font_face, font_scale, cv::Scalar(0, 0, 0), thickness);

    IconDetection det;
    det.type         = icon_type;
    det.confidence   = confidence;
    det.bounding_box = bbox;
    det.timestamp_ms = now_ms;
    results.push_back(det);
  }

  // 按置信度降序排序
  std::sort(results.begin(), results.end(),
            [](const IconDetection& a, const IconDetection& b) {
              return a.confidence > b.confidence;
            });

  return results;
}


