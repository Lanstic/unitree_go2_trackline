/**********************************************************************
 * go2-learn: Unitree Go2 红蓝双色物体跟踪器 (SDK2 版本 v3)
 *
 * === 功能概述 ===
 *   - 红色物体: 方向跟踪 + 距离保持
 *   - 蓝色物体: 安全后退 (优先级高于红色)
 *   - 无目标时: 原地等待
 *
 * === 控制优先级 ===
 *   蓝色(后退) > 红色(跟踪/保持) > 原地等待
 *
 * === 架构 ===
 *   单线程，无独立控制线程，主循环每帧:
 *     摄像头帧 → 蓝/红检测 → 计算速度 → Move() → 显示
 *
 * === 运行方式 ===
 *   ./run_red_tracker.sh [网卡名] [--no-move]
 *   例如: ./run_red_tracker.sh enp8s0
 *         ./run_red_tracker.sh enp8s0 --no-move  (仅检测,不运动)
 *
 * === 依赖 ===
 *   - unitree_sdk2  (VideoClient / SportClient / ChannelFactory)
 *   - OpenCV        (图像采集解码、HSV颜色检测、GUI显示)
 *
 * === 窗口说明 ===
 *   "Go2 Red+Blue Tracker"  — 主画面，叠加检测结果与控制状态
 *   "Red Mask (调参)"       — 红色二值掩码 + 12个HSV滑块
 *   "Blue Mask (调参)"      — 蓝色二值掩码 + 6个HSV滑块
 **********************************************************************/

#include <unitree/robot/go2/video/video_client.hpp>   // SDK2 摄像头客户端
#include <unitree/robot/go2/sport/sport_client.hpp>   // SDK2 运动控制客户端
#include <unitree/robot/channel/channel_factory.hpp>   // SDK2 DDS 通道工厂
#include <opencv2/opencv.hpp>                          // OpenCV 全部模块

#include <algorithm>   // std::max, std::min, std::max_element
#include <chrono>      // std::chrono::milliseconds
#include <csignal>     // std::signal, sig_atomic_t
#include <cmath>       // std::abs
#include <iostream>    // std::cout, std::cerr
#include <string>      // std::string, std::to_string
#include <thread>      // std::this_thread::sleep_for
#include <vector>      // std::vector

// ============================================================
// 全局信号处理 — Ctrl+C 安全退出
// ============================================================
namespace {

/// @brief 全局退出标志，由 Ctrl+C (SIGINT) 或 SIGTERM 触发
volatile std::sig_atomic_t g_signal = 0;

/// @brief 信号处理函数，设置退出标志后主循环自行退出
void SignalHandler(int signal) {
  g_signal = signal;
}

}  // namespace

// ============================================================
// 参数结构体 — 集中管理所有可调参数
// ============================================================

/**
 * @brief 红色物体检测的 HSV 阈值参数
 *
 * OpenCV 中 HSV 取值范围:
 *   H (色相)  : 0 ~ 179
 *   S (饱和度) : 0 ~ 255
 *   V (明度)  : 0 ~ 255
 *
 * 红色在色相环上跨越 0 度边界，需要用两个范围拼接:
 *   低红色: H ∈ [low_h1, low_h2]  (默认 0~15)
 *   高红色: H ∈ [high_h1, high_h2] (默认 155~179)
 *
 * 所有参数可在运行时通过 "Red Mask" 窗口的 Trackbar 实时调节。
 */
struct RedDetectParams {
  // ===== 低红色范围 =====
  int low_h1  = 0;     ///< 低红 色相下限
  int low_s1  = 130;   ///< 低红 饱和度下限 (提高排除棕色/肤色)
  int low_v1  = 100;   ///< 低红 明度下限 (提高排除暗棕)
  int low_h2  = 15;    ///< 低红 色相上限
  int low_s2  = 255;   ///< 低红 饱和度上限
  int low_v2  = 255;   ///< 低红 明度上限

  // ===== 高红色范围 =====
  int high_h1 = 155;   ///< 高红 色相下限
  int high_s1 = 130;   ///< 高红 饱和度下限
  int high_v1 = 100;   ///< 高红 明度下限
  int high_h2 = 179;   ///< 高红 色相上限 (OpenCV H最大值=179)
  int high_s2 = 255;   ///< 高红 饱和度上限
  int high_v2 = 255;   ///< 高红 明度上限

  // ===== 形态学与过滤 =====
  int    morph_kernel_size = 5;       ///< 形态学核大小 (开/闭运算用，越大去噪越强)
  double min_contour_area  = 500.0;   ///< 最小轮廓面积 (像素^2)，小于此值视为噪点
};

/**
 * @brief 蓝色物体检测的 HSV 阈值参数（用于安全后退）
 *
 * 蓝色在色相环上连续分布，只需一个范围:
 *   H ∈ [100, 130]
 *
 * 所有参数可在运行时通过 "Blue Mask" 窗口的 Trackbar 实时调节。
 */
struct BlueDetectParams {
  int    h1 = 100;   ///< 蓝色 色相下限
  int    s1 = 80;    ///< 蓝色 饱和度下限
  int    v1 = 80;    ///< 蓝色 明度下限
  int    h2 = 130;   ///< 蓝色 色相上限
  int    s2 = 255;   ///< 蓝色 饱和度上限
  int    v2 = 255;   ///< 蓝色 明度上限

  int    morph_kernel_size = 5;       ///< 形态学核大小
  double min_contour_area  = 500.0;   ///< 最小轮廓面积
};

/**
 * @brief 跟踪控制参数 — 影响机器人运动行为
 *
 * 转向使用 P (比例) 控制器:
 *   vyaw = -kp_yaw * (目标质心x - 画面中心x)
 *   vyaw 被钳制在 [-max_vyaw, max_vyaw] 范围内
 *
 * 前进速度根据目标轮廓面积判断距离:
 *   面积 < target_area_min  → 全速前进 (目标远)
 *   面积 在 [min, max] 之间 → 原地保持 (距离合适)
 *   面积 > target_area_max  → 慢速后退 (目标太近)
 */
struct TrackParams {
  // ===== 转向控制 =====
  float kp_yaw    = 0.004f;   ///< 转向 P 系数 (像素→rad/s)，越大转弯越猛
  float max_vyaw  = 1.5f;     ///< 最大转向角速度 (rad/s)，防止转太快翻车
  int   dead_zone_x = 80;     ///< 水平死区 (像素)，目标在此范围内不转向，直接前进

  // ===== 前进控制 =====
  float max_vx    = 0.5f;     ///< 最大前进速度 (m/s)
  double target_area_min = 15000.0;  ///< 目标面积下限 (像素^2)，小于此值说明太远→前进
  double target_area_max = 50000.0;  ///< 目标面积上限 (像素^2)，大于此值说明太近→后退
  // 校准方法: 将 30cm×30cm 红色物体放在 50cm 处，观察画面中显示的 Area 值，
  //          把 target_area_min 设为该值*0.6，target_area_max 设为该值*1.5

  // ===== 搜索与安全 =====
  int   lost_timeout = 20;    ///< 丢失超时 (帧数)，超过后原地等待（不旋转搜索）
  float retreat_vx  = -0.25f; ///< 蓝色后退速度 (m/s)，负值=后退
};

/**
 * @brief 红色目标锁定状态 — 方案B: 首次锁定 (Lock-On)
 *
 * 首次检测到红色目标时锁定其 HSV 颜色特征，
 * 后续只追踪颜色最接近锁定特征的目标，无视其他红色干扰物。
 * 目标丢失超过 lock_lost_timeout 帧后自动解锁，重新锁定下一个目标。
 */
struct RedLockState {
  bool  active = false;        ///< 是否已锁定
  float avg_h  = 0.0f;         ///< 锁定目标的平均色相
  float avg_s  = 0.0f;         ///< 锁定目标的平均饱和度
  float avg_v  = 0.0f;         ///< 锁定目标的平均明度
  int   lost_frames = 0;       ///< 锁定后目标连续丢失帧数
  int   lock_lost_timeout = 90; ///< 锁定丢失超时 (帧)，超时后解锁 (≈3秒@30fps)
};

// ============================================================
// 工具函数: HSV 距离计算
// ============================================================

/**
 * @brief 计算两个 HSV 颜色之间的加权欧氏距离
 *
 * H (色相) 是环形的 (0~180)，用环距计算。
 * S/V 是线性的。距离越小表示颜色越接近。
 */
float HSVDistance(float h1, float s1, float v1,
                  float h2, float s2, float v2) {
  // 色相环距 (0~180 环形)
  float dh = std::abs(h1 - h2);
  if (dh > 90.0f) dh = 180.0f - dh;  // 环距不超过 90
  float ds = s1 - s2;
  float dv = v1 - v2;
  // 加权: H 权重最高，S 次之，V 最低
  return std::sqrt(dh * dh * 4.0f + ds * ds + dv * dv * 0.5f);
}

/**
 * @brief 计算一个轮廓在图像中的平均 HSV 颜色
 *
 * 为避免背景干扰，只统计轮廓内部的像素 (使用掩码)。
 */
void AvgHSVOfContour(const cv::Mat& frame_hsv,
                     const std::vector<cv::Point>& contour,
                     float& out_h, float& out_s, float& out_v) {
  // 创建轮廓掩码
  cv::Mat mask = cv::Mat::zeros(frame_hsv.size(), CV_8UC1);
  std::vector<std::vector<cv::Point>> cw = {contour};
  cv::drawContours(mask, cw, -1, cv::Scalar(255), cv::FILLED);

  // 统计掩码内的 HSV 均值
  cv::Scalar mean_hsv = cv::mean(frame_hsv, mask);
  out_h = static_cast<float>(mean_hsv[0]);
  out_s = static_cast<float>(mean_hsv[1]);
  out_v = static_cast<float>(mean_hsv[2]);
}

// ============================================================
// 红色物体检测函数
// ============================================================

/**
 * @brief 在一帧图像中检测最大的红色物体（支持锁定模式）
 *
 * 检测流程:
 *   1. BGR → HSV 色彩空间转换
 *   2. 分别用低红/高红两个 HSV 范围做二值化
 *   3. 合并两个二值掩码 (按位或)
 *   4. 形态学 开运算(去噪) + 闭运算(填洞)
 *   5. 查找所有轮廓并面积过滤
 *   6. 选择策略:
 *      - 未锁定: 取面积最大的轮廓
 *      - 已锁定: 取 HSV 颜色最接近锁定目标的那一个
 *   7. 计算轮廓质心 (图像矩)
 *
 * @param frame       输入帧 (BGR 格式)
 * @param p           红色检测参数
 * @param out_cx      输出: 目标质心 X 坐标
 * @param out_cy      输出: 目标质心 Y 坐标
 * @param out_area    输出: 目标轮廓面积
 * @param out_mask    输出: 红色二值掩码 (用于窗口显示)
 * @param out_contour 输出: 选中轮廓的点集 (用于绘制)
 * @param lock        可选: 锁定状态，非空且 active 时启用颜色锁定
 * @return true 检测到有效的红色物体
 */
bool DetectRedObject(const cv::Mat& frame,
                     const RedDetectParams& p,
                     int& out_cx, int& out_cy, double& out_area,
                     cv::Mat& out_mask,
                     std::vector<cv::Point>& out_contour,
                     RedLockState* lock = nullptr) {
  // 1. 颜色空间转换: BGR → HSV
  cv::Mat hsv, frame_hsv;
  cv::cvtColor(frame, hsv, cv::COLOR_BGR2HSV);
  if (lock && lock->active) {
    frame_hsv = hsv;  // 锁定模式需要 HSV 图像用于颜色比对
  }

  // 2. 低红色范围二值化
  cv::Mat mask_low, mask_high;
  cv::inRange(hsv,
              cv::Scalar(p.low_h1,  p.low_s1,  p.low_v1),
              cv::Scalar(p.low_h2,  p.low_s2,  p.low_v2),  mask_low);

  // 3. 高红色范围二值化
  cv::inRange(hsv,
              cv::Scalar(p.high_h1, p.high_s1, p.high_v1),
              cv::Scalar(p.high_h2, p.high_s2, p.high_v2), mask_high);

  // 4. 合并两个范围 (位或)
  out_mask = mask_low | mask_high;

  // 5. 形态学处理: 开运算去噪点 → 闭运算填空洞
  cv::Mat kernel = cv::getStructuringElement(
      cv::MORPH_ELLIPSE,
      cv::Size(p.morph_kernel_size, p.morph_kernel_size));
  cv::morphologyEx(out_mask, out_mask, cv::MORPH_OPEN,  kernel);
  cv::morphologyEx(out_mask, out_mask, cv::MORPH_CLOSE, kernel);

  // 6. 查找所有外轮廓
  std::vector<std::vector<cv::Point>> contours;
  cv::findContours(out_mask, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
  if (contours.empty()) return false;

  // 7. 过滤面积不足的轮廓，收集有效轮廓
  std::vector<int> valid_idx;
  for (size_t i = 0; i < contours.size(); ++i) {
    if (cv::contourArea(contours[i]) >= p.min_contour_area) {
      valid_idx.push_back(static_cast<int>(i));
    }
  }
  if (valid_idx.empty()) return false;

  // 8. 选择目标轮廓
  int best_idx = valid_idx[0];

  if (lock && lock->active) {
    // ===== 锁定模式: 选 HSV 最接近锁定目标的轮廓 =====
    float best_dist = 1e9f;
    for (int idx : valid_idx) {
      float h, s, v;
      AvgHSVOfContour(frame_hsv, contours[idx], h, s, v);
      float dist = HSVDistance(h, s, v, lock->avg_h, lock->avg_s, lock->avg_v);
      if (dist < best_dist) {
        best_dist = dist;
        best_idx  = idx;
      }
    }
  } else {
    // ===== 未锁定模式: 取面积最大的轮廓 =====
    auto it = std::max_element(valid_idx.begin(), valid_idx.end(),
        [&](int a, int b) { return cv::contourArea(contours[a]) < cv::contourArea(contours[b]); });
    best_idx = *it;
  }

  out_area = cv::contourArea(contours[best_idx]);
  out_contour = contours[best_idx];

  // 9. 图像矩 → 质心 (注意除零保护)
  cv::Moments m = cv::moments(contours[best_idx]);
  if (std::abs(m.m00) < 1e-6) return false;

  out_cx = static_cast<int>(m.m10 / m.m00);  // 质心 X = m10 / m00
  out_cy = static_cast<int>(m.m01 / m.m00);  // 质心 Y = m01 / m00
  return true;
}

// ============================================================
// 蓝色物体检测函数（用于安全后退）
// ============================================================

/**
 * @brief 在一帧图像中检测最大的蓝色物体
 *
 * 检测流程与 DetectRedObject 相同，但蓝色只需一个 HSV 范围 (H: 100~130)
 * 无需像红色那样拼接两个范围。
 *
 * @param frame       输入帧 (BGR 格式)
 * @param p           蓝色检测参数
 * @param out_cx      输出: 目标质心 X 坐标
 * @param out_cy      输出: 目标质心 Y 坐标
 * @param out_area    输出: 目标轮廓面积
 * @param out_mask    输出: 蓝色二值掩码
 * @param out_contour 输出: 最大轮廓点集
 * @return true 检测到有效的蓝色物体
 */
bool DetectBlueObject(const cv::Mat& frame,
                      const BlueDetectParams& p,
                      int& out_cx, int& out_cy, double& out_area,
                      cv::Mat& out_mask,
                      std::vector<cv::Point>& out_contour) {
  // 1. BGR → HSV
  cv::Mat hsv;
  cv::cvtColor(frame, hsv, cv::COLOR_BGR2HSV);

  // 2. 蓝色范围二值化 (单范围，无需拼接)
  cv::inRange(hsv,
              cv::Scalar(p.h1, p.s1, p.v1),
              cv::Scalar(p.h2, p.s2, p.v2), out_mask);

  // 3. 形态学: 开运算 + 闭运算
  cv::Mat kernel = cv::getStructuringElement(
      cv::MORPH_ELLIPSE,
      cv::Size(p.morph_kernel_size, p.morph_kernel_size));
  cv::morphologyEx(out_mask, out_mask, cv::MORPH_OPEN,  kernel);
  cv::morphologyEx(out_mask, out_mask, cv::MORPH_CLOSE, kernel);

  // 4. 查找轮廓
  std::vector<std::vector<cv::Point>> contours;
  cv::findContours(out_mask, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
  if (contours.empty()) return false;

  // 5. 取最大轮廓
  auto it = std::max_element(contours.begin(), contours.end(),
      [](const auto& a, const auto& b) { return cv::contourArea(a) < cv::contourArea(b); });

  // 6. 面积过滤
  out_area = cv::contourArea(*it);
  if (out_area < p.min_contour_area) return false;

  // 7. 质心计算
  cv::Moments m = cv::moments(*it);
  if (std::abs(m.m00) < 1e-6) return false;

  out_cx = static_cast<int>(m.m10 / m.m00);
  out_cy = static_cast<int>(m.m01 / m.m00);
  out_contour = *it;
  return true;
}

// ============================================================
// 主函数
// ============================================================

int main(int argc, char** argv) {
  // ==========================================================
  // 0. 命令行参数解析
  // ==========================================================
  // 用法: red_tracker <网卡名> [--no-move] [--no-lock]
  //   --no-move: 仅检测显示，不控制机器人运动 (用于调试 HSV 参数)
  //   --no-lock: 禁用首次锁定，回退到最大面积模式
  if (argc < 2) {
    std::cout << "用法: " << argv[0] << " <网络接口名> [--no-move] [--no-lock]" << std::endl;
    std::cout << "例如: " << argv[0] << " enp8s0" << std::endl;
    std::cout << "      " << argv[0] << " enp8s0 --no-move" << std::endl;
    std::cout << "      " << argv[0] << " enp8s0 --no-lock   (禁用锁定,回退最大面积)" << std::endl;
    return 1;
  }
  const std::string net_if = argv[1];   // 网络接口名 (如 enp8s0)
  bool no_move  = false;                // 是否禁用运动控制
  bool use_lock = true;                 // 是否使用首次锁定 (默认开启)
  for (int i = 2; i < argc; ++i) {
    if (std::string(argv[i]) == "--no-move") no_move = true;
    if (std::string(argv[i]) == "--no-lock") use_lock = false;
  }

  // 注册信号处理 (Ctrl+C → 安全退出)
  std::signal(SIGINT,  SignalHandler);
  std::signal(SIGTERM, SignalHandler);

  // ==========================================================
  // 1. 初始化 SDK2 通信层
  // ==========================================================

  // 1a. 初始化 DDS 通道 (必须在所有 SDK2 客户端之前调用)
  std::cout << "[INFO] 初始化 DDS Channel (接口: " << net_if << ")..." << std::endl;
  unitree::robot::ChannelFactory::Instance()->Init(0, net_if);

  // 1b. 初始化摄像头客户端 — 用于获取机器狗前置摄像头 JPEG 图像
  std::cout << "[INFO] 初始化 VideoClient..." << std::endl;
  unitree::robot::go2::VideoClient video_client;
  video_client.SetTimeout(1.0f);   // 获取图像超时 1 秒
  video_client.Init();

  // 1c. 初始化运动控制客户端 — 用于发送站立/移动等指令
  std::cout << "[INFO] 初始化 SportClient..." << std::endl;
  unitree::robot::go2::SportClient sport_client;
  sport_client.SetTimeout(10.0f);  // 运动指令超时 10 秒
  sport_client.Init();

  // ==========================================================
  // 2. 站立流程 — 让机器人从任意状态进入站立+行走模式
  // ==========================================================
  // 流程: Damp(释放当前模式) → RecoveryStand(恢复站立) → StandUp(站立) → FreeWalk(自由行走)
  // 每步之间有延时，确保指令被机器人接收并执行
  if (!no_move) {
    std::cout << "[INFO] 释放当前模式 (Damp)..." << std::endl;
    sport_client.Damp();
    std::this_thread::sleep_for(std::chrono::milliseconds(500));

    std::cout << "[INFO] 恢复站立 (RecoveryStand)..." << std::endl;
    sport_client.RecoveryStand();
    std::this_thread::sleep_for(std::chrono::milliseconds(2000));

    std::cout << "[INFO] 站立 (StandUp)..." << std::endl;
    sport_client.StandUp();
    std::this_thread::sleep_for(std::chrono::milliseconds(2000));

    std::cout << "[INFO] 进入自由行走步态 (FreeWalk)..." << std::endl;
    sport_client.FreeWalk();
    std::this_thread::sleep_for(std::chrono::milliseconds(500));

    // 发送测试转向 — 确认运动通道正常工作
    std::cout << "[INFO] 测试转向..." << std::endl;
    sport_client.Move(0.0f, 0.0f, 0.3f);  // 原地右转 0.3 rad/s
    std::this_thread::sleep_for(std::chrono::milliseconds(500));
    sport_client.Move(0.0f, 0.0f, 0.0f);  // 停止

    std::cout << "[INFO] 机器人已就绪，等待摄像头数据..." << std::endl;
  } else {
    std::cout << "[INFO] --no-move 模式: 跳过站立, 仅检测显示" << std::endl;
    std::cout << "[INFO] 等待摄像头数据..." << std::endl;
  }

  // ==========================================================
  // 3. 创建 OpenCV 窗口和 HSV 调参 Trackbar
  // ==========================================================

  // 三个窗口
  const std::string win_main = "Go2 Red+Blue Tracker";  // 主画面
  const std::string win_red  = "Red Mask (调参)";        // 红色掩码
  const std::string win_blue = "Blue Mask (调参)";       // 蓝色掩码
  cv::namedWindow(win_main, cv::WINDOW_AUTOSIZE);
  cv::namedWindow(win_red,  cv::WINDOW_AUTOSIZE);
  cv::namedWindow(win_blue, cv::WINDOW_AUTOSIZE);

  // 参数实例 (Trackbar 直接绑定到这些变量的地址)
  RedDetectParams  red_params;
  BlueDetectParams blue_params;
  TrackParams      trk_params;

  // --- 红色 HSV Trackbar (12个) ---
  // 低红色范围
  cv::createTrackbar("Low H1",  win_red, &red_params.low_h1,  179);
  cv::createTrackbar("Low H2",  win_red, &red_params.low_h2,  179);
  cv::createTrackbar("Low S1",  win_red, &red_params.low_s1,  255);
  cv::createTrackbar("Low V1",  win_red, &red_params.low_v1,  255);
  cv::createTrackbar("Low S2",  win_red, &red_params.low_s2,  255);
  cv::createTrackbar("Low V2",  win_red, &red_params.low_v2,  255);
  // 高红色范围
  cv::createTrackbar("High H1", win_red, &red_params.high_h1, 179);
  cv::createTrackbar("High H2", win_red, &red_params.high_h2, 179);
  cv::createTrackbar("High S1", win_red, &red_params.high_s1, 255);
  cv::createTrackbar("High V1", win_red, &red_params.high_v1, 255);
  cv::createTrackbar("High S2", win_red, &red_params.high_s2, 255);
  cv::createTrackbar("High V2", win_red, &red_params.high_v2, 255);

  // --- 蓝色 HSV Trackbar (6个) ---
  cv::createTrackbar("Blue H1", win_blue, &blue_params.h1, 179);
  cv::createTrackbar("Blue H2", win_blue, &blue_params.h2, 179);
  cv::createTrackbar("Blue S1", win_blue, &blue_params.s1, 255);
  cv::createTrackbar("Blue V1", win_blue, &blue_params.v1, 255);
  cv::createTrackbar("Blue S2", win_blue, &blue_params.s2, 255);
  cv::createTrackbar("Blue V2", win_blue, &blue_params.v2, 255);

  // --- 启动信息 ---
  std::cout << "============================================" << std::endl;
  std::cout << "  Go2 红蓝双色跟踪器 v3" << std::endl;
  std::cout << "============================================" << std::endl;
  std::cout << "  网络接口 : " << net_if << std::endl;
  std::cout << "  运动控制 : " << (no_move ? "关闭" : "开启") << std::endl;
  std::cout << "  \033[31m红色\033[0m: 跟踪+保持" << (use_lock ? " (锁定ON)" : " (最大面积)")
            << " | \033[34m蓝色\033[0m: 安全后退 (优先)" << std::endl;
  std::cout << "  Q / ESC  : 退出程序" << std::endl;
  std::cout << "============================================" << std::endl;

  // ==========================================================
  // 4. 主循环 — 图像采集 → 双色检测 → 控制 → 显示
  // ==========================================================

  std::vector<uint8_t> jpeg_buffer;   // JPEG 原始数据缓冲
  int  frame_count      = 0;          // 帧计数
  bool first_frame      = true;       // 是否首帧
  int  lost_count       = 0;          // 红目标连续丢失帧数
  int  blue_lost_count  = 0;          // 蓝目标连续丢失帧数
  const int BLUE_RETREAT_GRACE = 10;  // 蓝色惯性: 消失后继续后退的帧数
  RedLockState red_lock;              // 红色锁定状态 (方案B: 首次锁定)

  while (g_signal == 0) {

    // === 4a. 获取摄像头图像 (阻塞，直到新帧或超时) ===
    int ret = video_client.GetImageSample(jpeg_buffer);
    frame_count++;
    if (ret != 0 || jpeg_buffer.empty()) {
      if (frame_count <= 3)   // 仅前3帧打印错误，避免刷屏
        std::cerr << "[WARN] GetImageSample 失败 ret=" << ret << std::endl;
      std::this_thread::sleep_for(std::chrono::milliseconds(50));
      continue;  // 跳过此帧
    }

    // === 4b. JPEG 解码为 BGR 图像 ===
    cv::Mat frame = cv::imdecode(jpeg_buffer, cv::IMREAD_COLOR);
    if (frame.empty()) {
      if (frame_count <= 3)
        std::cerr << "[WARN] JPEG 解码失败" << std::endl;
      continue;
    }

    // === 4c. 首帧打印分辨率信息 ===
    if (first_frame) {
      std::cout << "[INFO] 摄像头就绪: " << frame.cols << "x" << frame.rows
                << " | " << jpeg_buffer.size() << " B" << std::endl;
      first_frame = false;
    }

    // 画面几何常量
    const int center_x = frame.cols / 2;   // 画面水平中心 X
    const int frame_h  = frame.rows;       // 画面高度

    // ==========================================================
    // 4d. 蓝色检测 — 安全优先，先于红色
    // ==========================================================
    int    blue_cx = 0, blue_cy = 0;
    double blue_area = 0.0;
    cv::Mat blue_mask;
    std::vector<cv::Point> blue_contour;
    bool blue_found = false;

    try {
      blue_found = DetectBlueObject(frame, blue_params,
                                    blue_cx, blue_cy, blue_area,
                                    blue_mask, blue_contour);
    } catch (...) {}  // 检测异常不崩溃，跳过此帧

    // ==========================================================
    // 4e. 红色检测 — 仅在未检测到蓝色时执行 (蓝优先)
    //     支持首次锁定: 锁定时只追踪颜色最接近初始目标的红色物体
    // ==========================================================
    int    red_cx = 0, red_cy = 0;
    double red_area = 0.0;
    cv::Mat red_mask;
    std::vector<cv::Point> red_contour;
    bool red_found = false;

    if (!blue_found) {
      try {
        RedLockState* lock_ptr = use_lock ? &red_lock : nullptr;
        red_found = DetectRedObject(frame, red_params,
                                    red_cx, red_cy, red_area,
                                    red_mask, red_contour,
                                    lock_ptr);
      } catch (...) {}
    }

    // --- 锁管理: 首次检测到红色 → 锁定其 HSV ---
    if (red_found && use_lock && !red_lock.active) {
      // 计算该目标的平均 HSV 并锁定
      cv::Mat hsv;
      cv::cvtColor(frame, hsv, cv::COLOR_BGR2HSV);
      AvgHSVOfContour(hsv, red_contour,
                      red_lock.avg_h, red_lock.avg_s, red_lock.avg_v);
      red_lock.active = true;
      red_lock.lost_frames = 0;
      std::cerr << "[LOCK] 已锁定红色目标 HSV=("
                << static_cast<int>(red_lock.avg_h) << ","
                << static_cast<int>(red_lock.avg_s) << ","
                << static_cast<int>(red_lock.avg_v) << ")" << std::endl;
    }

    // --- 锁管理: 检测到蓝色 → 强制解锁 ---
    if (blue_found && red_lock.active) {
      red_lock.active = false;
      std::cerr << "[LOCK] 检测到蓝色，强制解锁" << std::endl;
    }

    // 更新蓝目标丢失计数 (用于惯性后退)
    if (blue_found) {
      blue_lost_count = 0;
    } else {
      blue_lost_count++;
    }

    // ==========================================================
    // 4f. 控制逻辑 — 优先级: 蓝色(后退) > 红色(跟踪) > 原地等待
    // ==========================================================
    float vx   = 0.0f;   // 前进速度 (m/s)，正=前进，负=后退
    float vyaw = 0.0f;   // 转向角速度 (rad/s)，正=左转，负=右转

    // 绘制画面垂直中线 — 参考线，目标偏移量的零点
    cv::line(frame, cv::Point(center_x, 0), cv::Point(center_x, frame_h),
             cv::Scalar(255, 0, 0), 1);  // 蓝色细线

    // ---------- 情况1: 检测到蓝色 (或惯性未消) → 安全后退 ----------
    if (blue_found || blue_lost_count < BLUE_RETREAT_GRACE) {
      lost_count = 0;                      // 重置红丢失计数
      vx   = trk_params.retreat_vx;        // 负值 → 后退
      vyaw = 0.0f;                         // 后退时不转向

      try {
        if (blue_found) {
          // 绘制蓝色大十字标记 (比红色更大，表示警告)
          cv::circle(frame, cv::Point(blue_cx, blue_cy), 10,
                     cv::Scalar(255, 0, 0), 3);       // 蓝色圆
          cv::line(frame, cv::Point(blue_cx-16, blue_cy), cv::Point(blue_cx+16, blue_cy),
                   cv::Scalar(255, 0, 0), 3);          // 水平线
          cv::line(frame, cv::Point(blue_cx, blue_cy-16), cv::Point(blue_cx, blue_cy+16),
                   cv::Scalar(255, 0, 0), 3);          // 竖直线
          // 绘制蓝色轮廓
          std::vector<std::vector<cv::Point>> bc = {blue_contour};
          cv::drawContours(frame, bc, -1, cv::Scalar(255, 0, 0), 2);
          // 警告文字
          char info[128];
          snprintf(info, sizeof(info), "!!! BLUE - RETREAT !!! Area:%.0f", blue_area);
          cv::putText(frame, info, cv::Point(10, 30),
                      cv::FONT_HERSHEY_SIMPLEX, 0.7, cv::Scalar(0, 0, 255), 2);
        } else {
          // 惯性后退中 (蓝色刚消失)
          cv::putText(frame, "BLUE RETREAT (惯性 " + std::to_string(blue_lost_count)
                      + "/" + std::to_string(BLUE_RETREAT_GRACE) + ")",
                      cv::Point(10, 30), cv::FONT_HERSHEY_SIMPLEX, 0.7,
                      cv::Scalar(0, 0, 255), 2);
        }
      } catch (...) {}

    // ---------- 情况2: 检测到红色 (且无蓝色) → 方向跟踪前进 ----------
    } else if (red_found) {
      lost_count = 0;                     // 重置丢失计数
      if (use_lock) red_lock.lost_frames = 0;  // 重置锁丢失计数
      int offset_x = red_cx - center_x;   // 目标水平偏移 (正=偏右，负=偏左)

      // --- 转向 P 控制 ---
      // 仅当目标超出死区时才转向
      if (std::abs(offset_x) > trk_params.dead_zone_x) {
        // 负号原因: 目标在画面右侧 → 机器人需右转(负vyaw)
        vyaw = -trk_params.kp_yaw * static_cast<float>(offset_x);
        // 钳制到安全范围
        vyaw = std::max(-trk_params.max_vyaw,
                        std::min(trk_params.max_vyaw, vyaw));
      }

      // --- 前进控制 (仅目标在死区内时前进) ---
      if (std::abs(offset_x) <= trk_params.dead_zone_x) {
        if (red_area < trk_params.target_area_min) {
          vx = trk_params.max_vx;            // 目标太远 → 全速追
        } else if (red_area > trk_params.target_area_max) {
          vx = -0.2f;                        // 目标太近 → 慢速后退
        } else {
          vx = 0.0f;                         // 距离合适 → 保持不动
        }
      }

      // 绘制红色检测标记
      try {
        // 绿色小十字
        cv::circle(frame, cv::Point(red_cx, red_cy), 6, cv::Scalar(0, 255, 0), 2);
        cv::line(frame, cv::Point(red_cx-12, red_cy), cv::Point(red_cx+12, red_cy),
                 cv::Scalar(0, 255, 0), 2);
        cv::line(frame, cv::Point(red_cx, red_cy-12), cv::Point(red_cx, red_cy+12),
                 cv::Scalar(0, 255, 0), 2);
        // 黄色轮廓
        std::vector<std::vector<cv::Point>> rc = {red_contour};
        cv::drawContours(frame, rc, -1, cv::Scalar(0, 255, 255), 2);
        // 信息
        char info[128];
        const char* lock_tag = (use_lock && red_lock.active) ? " [LOCKED]" : "";
        snprintf(info, sizeof(info), "RED:(%d,%d) Area:%.0f Off:%d%s",
                 red_cx, red_cy, red_area, offset_x, lock_tag);
        cv::putText(frame, info, cv::Point(10, 30),
                    cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(0, 255, 0), 2);
      } catch (...) {}

    // ---------- 情况3: 无目标 → 原地等待 ----------
    } else {
      lost_count++;
      // 锁丢失计数
      if (use_lock && red_lock.active) {
        red_lock.lost_frames++;
        if (red_lock.lost_frames > red_lock.lock_lost_timeout) {
          red_lock.active = false;
          std::cerr << "[LOCK] 目标丢失超时，自动解锁" << std::endl;
        }
      }
      if (lost_count > trk_params.lost_timeout) {
        // 超时: 原地不动，等待目标出现
        vyaw = 0.0f;
        vx   = 0.0f;
        cv::putText(frame, "WAITING (lost " + std::to_string(lost_count) + ")",
                    cv::Point(10, 30), cv::FONT_HERSHEY_SIMPLEX, 0.7,
                    cv::Scalar(0, 165, 255), 2);
      } else {
        // 短暂丢失: 保持观望
        cv::putText(frame, "LOST (" + std::to_string(lost_count) + ")",
                    cv::Point(10, 30), cv::FONT_HERSHEY_SIMPLEX, 0.7,
                    cv::Scalar(0, 165, 255), 2);
      }
    }

    // === 4g. 发送运动指令 ===
    // Move(vx, vy, vyaw): 前向速度, 横向速度, 转向角速度
    if (!no_move) {
      try {
        sport_client.Move(vx, 0.0f, vyaw);
      } catch (...) {
        std::cerr << "[FATAL] Move 异常" << std::endl;
        break;  // 异常退出主循环
      }
    }

    // === 4h. 画面底部状态栏 ===
    char status[128];
    const char* lock_str = "";
    if (use_lock && red_lock.active) {
      lock_str = " LOCKED";
    } else if (use_lock) {
      lock_str = " UNLOCKED";
    }
    snprintf(status, sizeof(status), "CMD:vx=%.2f vyaw=%.2f | Lost:%d%s | Frm:%d",
             vx, vyaw, lost_count, lock_str, frame_count);
    cv::putText(frame, status, cv::Point(10, frame_h-15),
                cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(255, 255, 255), 2);

    // === 4i. 显示三个窗口 ===
    try {
      cv::imshow(win_main, frame);       // 主画面
      // 红色掩码窗口 (未检测到时显示黑屏)
      cv::imshow(win_red,  red_found  ? red_mask
                      : cv::Mat::zeros(frame_h, center_x * 2, CV_8UC1));
      // 蓝色掩码窗口 (未检测到时显示黑屏)
      cv::imshow(win_blue, blue_found ? blue_mask
                      : cv::Mat::zeros(frame_h, center_x * 2, CV_8UC1));
    } catch (...) {
      std::cerr << "[FATAL] imshow 异常" << std::endl;
      break;
    }

    // === 4j. 键盘检测 (1ms 超时，不阻塞) ===
    int key = cv::waitKey(1);
    if (key == 'q' || key == 'Q' || key == 27) {   // Q 键 或 ESC 键
      std::cout << "[INFO] 用户退出" << std::endl;
      break;
    }
  }  // end while 主循环

  // ==========================================================
  // 5. 安全清理
  // ==========================================================
  if (!no_move) {
    // 5a. 停止运动
    std::cout << "[INFO] 停止运动..." << std::endl;
    sport_client.StopMove();
    std::this_thread::sleep_for(std::chrono::milliseconds(300));

    // 5b. 趴下 (进入安全状态)
    std::cout << "[INFO] 趴下..." << std::endl;
    sport_client.StandDown();
    std::this_thread::sleep_for(std::chrono::milliseconds(500));
  }

  // 5c. 关闭所有 OpenCV 窗口
  cv::destroyAllWindows();
  std::cout << "[INFO] 红蓝双色跟踪器已安全关闭" << std::endl;
  return 0;
}
