/**********************************************************************
 * light_test: Go2 探照灯测试程序
 *
 * 按回车键开关探照灯，输入 q 退出。
 *
 * 编译:
 *   cd build && cmake .. && make light_test
 *
 * 运行:
 *   ./build/light_test enp8s0
 **********************************************************************/

#include <unitree/robot/go2/vui/vui_client.hpp>
#include <unitree/robot/channel/channel_factory.hpp>

#include <csignal>
#include <iostream>
#include <string>
#include <thread>
#include <chrono>
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>

static volatile bool g_running = true;
void SignalHandler(int) { g_running = false; }

// 设置终端为非阻塞模式
void SetNonBlocking(bool enable) {
  static struct termios oldt;
  static bool set = false;
  if (!set) {
    tcgetattr(STDIN_FILENO, &oldt);
    set = true;
  }
  if (enable) {
    struct termios newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
  } else {
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
  }
}

int main(int argc, char** argv) {
  if (argc < 2) {
    std::cout << "用法: " << argv[0] << " <网卡名>" << std::endl;
    std::cout << "例如: " << argv[0] << " enp8s0" << std::endl;
    return 1;
  }

  std::signal(SIGINT, SignalHandler);

  // 初始化 DDS
  unitree::robot::ChannelFactory::Instance()->Init(0, argv[1]);

  // 初始化 VUI
  unitree::robot::go2::VuiClient vui;
  vui.SetTimeout(1.0f);
  vui.Init();

  // 读取初始亮度
  int brightness = 0, sw = 0;
  vui.GetBrightness(brightness);
  vui.GetSwitch(sw);
  std::cout << "初始 VUI: brightness=" << brightness << " switch=" << sw << std::endl;

  // 打开 VUI
  vui.SetSwitch(1);
  std::this_thread::sleep_for(std::chrono::milliseconds(200));

  bool light_on = (brightness > 0);
  std::cout << "\n=== Go2 探照灯测试 ===" << std::endl;
  std::cout << "按 回车键 开关灯" << std::endl;
  std::cout << "输入 q 退出" << std::endl;
  std::cout << "当前: " << (light_on ? "开" : "关") << " (brightness=" << brightness << ")" << std::endl;

  SetNonBlocking(true);

  while (g_running) {
    char c = 0;
    if (read(STDIN_FILENO, &c, 1) > 0) {
      if (c == 'q' || c == 'Q') break;
      if (c == '\n' || c == ' ') {
        light_on = !light_on;
        int val = light_on ? 10 : 0;
        std::cout << "设置亮度: " << val << " → ";
        vui.SetBrightness(val);
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
        int cur = -1;
        vui.GetBrightness(cur);
        std::cout << (light_on ? "开" : "关") << " (brightness=" << cur << ")" << std::endl;
      }
    }

    // 每 2 秒打印状态
    static auto last_print = std::chrono::steady_clock::now();
    auto now = std::chrono::steady_clock::now();
    if (now - last_print > std::chrono::seconds(2)) {
      last_print = now;
      int cur = -1, s = -1;
      vui.GetBrightness(cur);
      vui.GetSwitch(s);
      std::cout << "[状态] brightness=" << cur << " switch=" << s << std::endl;
    }

    std::this_thread::sleep_for(std::chrono::milliseconds(50));
  }

  SetNonBlocking(false);
  vui.SetBrightness(10);
  std::cout << "已退出, 亮度恢复至 10" << std::endl;
  return 0;
}
