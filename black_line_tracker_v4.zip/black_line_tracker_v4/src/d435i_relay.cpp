/**********************************************************************
 * d435i_relay: RealSense D435i → TCP 图像中继
 *
 * 运行在 Jetson Orin Nano (192.168.123.18) 上。
 * 接收 D435i RGB 帧并通过 TCP 9191 端口转发到开发笔记本，
 * 避免 ROS2 DDS 与 SDK2 DDS 冲突。
 *
 * 协议:
 *   Server (Jetson) → Client (开发笔记本)
 *   [img_width  int32]
 *   [img_height int32]
 *   [raw BGR data  w*h*3 bytes]
 *   上述循环发送。
 *
 * 编译:
 *   cd build && cmake .. -DUSE_REALSENSE=ON && make d435i_relay
 *
 * 运行:
 *   ./d435i_relay
 **********************************************************************/

#include <librealsense2/rs.hpp>

#include <csignal>
#include <cstdint>
#include <iostream>
#include <cstring>
#include <thread>      // std::this_thread::sleep_for
#include <chrono>      // std::chrono::milliseconds

#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>

// ============================================================
// 全局信号处理
// ============================================================
static volatile std::sig_atomic_t g_signal = 0;

void SignalHandler(int signal) {
  g_signal = signal;
}

// ============================================================
// 主函数
// ============================================================
int main() {
  std::signal(SIGINT,  SignalHandler);
  std::signal(SIGTERM, SignalHandler);
  std::signal(SIGPIPE, SIG_IGN);  // 防止 send 到断开客户端时崩溃

  // 1. 初始化 D435i
  std::cout << "[Relay] 初始化 D435i..." << std::endl;
  rs2::pipeline pipe;
  rs2::config cfg;
  cfg.enable_stream(RS2_STREAM_COLOR, 640, 480, RS2_FORMAT_BGR8, 30);
  pipe.start(cfg);
  std::cout << "[Relay] D435i 已启动 (640x480 BGR8 @30fps)" << std::endl;

  // 2. 创建 TCP 服务器 (端口 9191)
  int server_fd = socket(AF_INET, SOCK_STREAM, 0);
  if (server_fd < 0) {
    std::cerr << "[Relay] 创建 socket 失败" << std::endl;
    return 1;
  }

  int opt = 1;
  setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

  sockaddr_in addr{};
  addr.sin_family = AF_INET;
  addr.sin_port   = htons(9191);
  addr.sin_addr.s_addr = INADDR_ANY;

  if (bind(server_fd, (sockaddr*)&addr, sizeof(addr)) < 0) {
    std::cerr << "[Relay] bind 失败 (端口 9191 被占用?)" << std::endl;
    close(server_fd);
    return 1;
  }

  listen(server_fd, 1);
  std::cout << "[Relay] 监听端口 9191，等待连接..." << std::endl;

  int client_fd = -1;

  // 3. 主循环: 等待客户端 → 推流
  while (!g_signal) {
    // 3a. 等待客户端连接 (阻塞)
    if (client_fd < 0) {
      client_fd = accept(server_fd, nullptr, nullptr);
      if (client_fd >= 0) {
        std::cout << "[Relay] 客户端已连接" << std::endl;
      } else if (errno != EINTR) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
        continue;
      } else {
        continue;  // EINTR (信号中断), 重试
      }
    }

    // 3b. 捕获 D435i 帧
    rs2::frameset frames;
    try {
      frames = pipe.wait_for_frames(1000);
    } catch (const rs2::error& e) {
      std::cerr << "[Relay] wait_for_frames 异常: " << e.what() << std::endl;
      continue;
    }

    auto color = frames.get_color_frame();
    if (!color) continue;

    auto vf = color.as<rs2::video_frame>();
    int32_t w = vf.get_width();
    int32_t h = vf.get_height();
    int32_t sz = w * h * 3;

    // 3c. 发送 [w][h][data]
    // MSG_NOSIGNAL: 客户端断开时不触发 SIGPIPE
    if (send(client_fd, &w, sizeof(w), MSG_NOSIGNAL) != sizeof(w) ||
        send(client_fd, &h, sizeof(h), MSG_NOSIGNAL) != sizeof(h) ||
        send(client_fd, color.get_data(), sz, MSG_NOSIGNAL) != sz) {
      std::cout << "[Relay] 客户端断开连接" << std::endl;
      close(client_fd);
      client_fd = -1;
    }
  }

  // 4. 清理
  if (client_fd >= 0) close(client_fd);
  close(server_fd);
  pipe.stop();
  std::cout << "[Relay] 已安全关闭" << std::endl;
  return 0;
}
