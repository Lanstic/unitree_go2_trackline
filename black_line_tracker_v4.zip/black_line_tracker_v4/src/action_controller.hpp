/**********************************************************************
 * action_controller.hpp — Go2 图标动作控制器
 *
 * 根据识别到的图标类型执行预设动作序列。
 * 运动通过 SportClient::Move() 指令序列实现；
 * 灯光通过 VuiClient::SetBrightness() 控制前灯。
 *
 * 图标 → 动作映射:
 *   ELECTRIC_SHOCK → Stretch (伸展: 后退→前进→恢复)
 *   OXIDIZER       → Hello   (招手: 原地摇头摆尾)
 *   RADIATION      → Hello   (招手: 原地摇头摆尾, VUI 前灯闪烁不可用)")
 **********************************************************************/

#pragma once

#include <unitree/robot/go2/sport/sport_client.hpp>
#include <unitree/robot/go2/vui/vui_client.hpp>

#include <chrono>
#include <cmath>
#include <iostream>
#include <string>
#include <thread>
#include <vector>

#include "icon_detector.hpp"

// ============================================================
// 动作类型枚举
// ============================================================
enum class ActionType : uint8_t {
  NONE           = 0,
  STRETCH        = 1,   ///< 伸展 (对应 ELECTRIC_SHOCK)
  HELLO          = 2,   ///< 招手 (对应 OXIDIZER)
  FLASH_LIGHTS   = 3,   ///< 闪烁灯光舞蹈 (对应 RADIATION)
};

/// @brief 动作类型 → 可读字符串
inline const char* ActionTypeName(ActionType t) {
  switch (t) {
    case ActionType::STRETCH:      return "STRETCH";
    case ActionType::HELLO:        return "HELLO";
    case ActionType::FLASH_LIGHTS: return "FLASH_LIGHTS";
    default:                       return "NONE";
  }
}

// ============================================================
// 动作序列中的一步
// ============================================================
struct ActionStep {
  float vx    = 0.0f;   ///< 前进速度 (m/s)
  float vy    = 0.0f;   ///< 横向速度 (m/s)
  float vyaw  = 0.0f;   ///< 转向角速度 (rad/s)
  int   duration_ms = 0;  ///< 该步持续毫秒数
};

// ============================================================
// 图标 → 动作映射表
// ============================================================
struct IconActionMapping {
  IconType  icon;        ///< 图标类型
  ActionType action;     ///< 对应动作
  std::string name;      ///< 动作名称
};

const IconActionMapping kIconActionMappings[] = {
  {IconType::ELECTRIC_SHOCK, ActionType::STRETCH,      "伸展"},
  {IconType::OXIDIZER,       ActionType::HELLO,        "招手"},
  {IconType::RADIATION,      ActionType::FLASH_LIGHTS, "探照灯闪烁"},
};

inline ActionType IconToAction(IconType icon) {
  for (const auto& m : kIconActionMappings) {
    if (m.icon == icon) return m.action;
  }
  return ActionType::NONE;
}

// ============================================================
// 动作控制参数
// ============================================================
struct ActionCtrlParams {
  int cooldown_ms = 5000;        ///< 动作冷却时间 (同图标防止重复触发)
  int confirm_frames = 10;       ///< 连续确认帧数 (每3帧检测1次, 约1秒)
  float confirm_conf = 0.40f;    ///< 最低确认置信度 (多特征综合评分, 0~1)
};

// ============================================================
// 各动作的指令序列 (自定义 Move 序列, 已不再使用)
// 改用 Go2 SDK 内置动作: sport_.Hello() / Stretch() / Content()
// ============================================================

// ============================================================
// 动作控制器
// ============================================================
class ActionController {
public:
  /// @brief 构造
  /// @param sport_client 运动控制客户端引用
  /// @param vui_client   VUI 客户端引用 (用于控制前灯亮度)
  ActionController(unitree::robot::go2::SportClient& sport_client,
                   unitree::robot::go2::VuiClient&   vui_client)
    : sport_(sport_client), vui_(vui_client) {}

  /// @brief 设置参数
  void SetParams(const ActionCtrlParams& params) { params_ = params; }
  ActionCtrlParams& Params() { return params_; }

  /// @brief 根据图标类型执行动作 (阻塞, 持续到动作完成)
  /// @param icon 图标类型
  /// @return true 执行成功
  bool ExecuteAction(IconType icon) {
    ActionType action = IconToAction(icon);
    if (action == ActionType::NONE) {
      std::cout << "[Action] 未知图标类型, 跳过动作" << std::endl;
      return false;
    }

    std::cout << "[Action] 执行: " << ActionTypeName(action)
              << " (" << GetActionName(icon) << ")" << std::endl;

    // 先停止
    sport_.Move(0.0f, 0.0f, 0.0f);
    std::this_thread::sleep_for(std::chrono::milliseconds(300));

    // 使用 Go2 SDK 内置动作 (比自定义 Move 序列更稳定、更生动)
    try {
      switch (action) {
        case ActionType::STRETCH: {
          std::cout << "[Action]   调用 Stretch()..." << std::endl;
          sport_.Stretch();
          std::this_thread::sleep_for(std::chrono::seconds(3));
          break;
        }
        case ActionType::HELLO: {
          std::cout << "[Action]   调用 Hello()..." << std::endl;
          sport_.Hello();
          std::this_thread::sleep_for(std::chrono::seconds(4));
          break;
        }
        case ActionType::FLASH_LIGHTS: {
          FlashFrontLight();
          break;
        }
        default:
          return false;
      }
    } catch (const std::exception& e) {
      std::cerr << "[Action]   SDK 动作异常: " << e.what() << std::endl;
      sport_.Move(0, 0, 0);
      return false;
    }

    // 动作结束后停止
    sport_.Move(0.0f, 0.0f, 0.0f);
    std::this_thread::sleep_for(std::chrono::milliseconds(300));

    std::cout << "[Action] 完成: " << ActionTypeName(action) << std::endl;
    return true;
  }

  /// @brief 获取图标对应的动作中文名
  static const char* GetActionName(IconType icon) {
    for (const auto& m : kIconActionMappings) {
      if (m.icon == icon) return m.name.c_str();
    }
    return "";
  }

private:
  unitree::robot::go2::SportClient& sport_;
  unitree::robot::go2::VuiClient&   vui_;
  ActionCtrlParams params_;

  /// @brief 闪烁探照灯 3 次 (VUI brightness 0~10)
  void FlashFrontLight() {
    const int kFlashCount = 3;
    const int kFlashDelayMs = 300;

    for (int i = 0; i < kFlashCount; ++i) {
      std::cout << "[Action]   探照灯 开 (" << (i+1) << "/" << kFlashCount << ")" << std::endl;
      vui_.SetBrightness(10);
      std::this_thread::sleep_for(std::chrono::milliseconds(kFlashDelayMs));

      std::cout << "[Action]   探照灯 关 (" << (i+1) << "/" << kFlashCount << ")" << std::endl;
      vui_.SetBrightness(0);
      std::this_thread::sleep_for(std::chrono::milliseconds(kFlashDelayMs));
    }
    vui_.SetBrightness(10);  // 恢复开灯
  }
};


