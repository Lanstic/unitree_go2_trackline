/**********************************************************************
 * black_line_tracker: Unitree Go2 黑色线迹巡线器 (SDK2 版本)
 *
 * === 功能概述 ===
 *   底部 ROI 行扫描 + 直线拟合，跟踪地面黑色线迹
 *   - 线可见: 位置偏移 + 角度对齐，双 P 控制巡线
 *   - 线丢失: 立即停止，安全等待
 *
 * === 架构 ===
 *   单线程，主循环每帧:
 *     摄像头帧 → 底部ROI裁剪 → 灰度二值化 → 行扫描 → 直线拟合 → Move() → 显示
 *
 * === 运行方式 ===
 *   ./run_black_line_tracker.sh [网卡名] [--no-move]
 *   例如: ./run_black_line_tracker.sh enp8s0
 *         ./run_black_line_tracker.sh enp8s0 --no-move  (仅检测,不运动)
 *
 * === 依赖 ===
 *   - unitree_sdk2  (SportClient / ChannelFactory)
 *   - OpenCV        (图像处理、GUI显示)
 *   - [可选] D435i 通过 TCP 中继 (d435i_relay 运行在 Jetson, 端口 9191)
 *
 * === 窗口说明 ===
 *   "Line Tracker"         — 主画面，叠加线迹检测结果与控制状态
 *   "Threshold (调参)"     — 底部 ROI 二值化预览 + 阈值滑块
 **********************************************************************/

#ifdef USE_REALSENSE
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <cstdint>
#endif
// Go2 内置摄像头 — 始终需要 (D435i 模式下用于图标识别, 非 D435i 模式用于巡线)
#include <unitree/robot/go2/video/video_client.hpp>
#include <unitree/robot/go2/sport/sport_client.hpp>   // SDK2 运动控制客户端
#include <unitree/robot/go2/vui/vui_client.hpp>       // SDK2 VUI 客户端 (前灯控制)
#include <unitree/robot/go2/robot_state/robot_state_client.hpp>  // 查看可用服务
#include <unitree/robot/channel/channel_factory.hpp>   // SDK2 DDS 通道工厂
#include <opencv2/opencv.hpp>                          // OpenCV 全部模块

#include <algorithm>   // std::max, std::min
#include <chrono>      // std::chrono::milliseconds
#include <csignal>     // std::signal, sig_atomic_t
#include <cmath>       // std::abs
#include <iostream>    // std::cout, std::cerr
#include <string>      // std::string, std::to_string
#include <thread>      // std::this_thread::sleep_for
#include <vector>      // std::vector

// 图标识别与动作控制 (集成 go2_icon_recognition)
#include "icon_detector.hpp"
#include "action_controller.hpp"

// ============================================================
// 全局信号处理 — Ctrl+C 安全退出
// ============================================================
namespace {

/// @brief 全局退出标志，由 Ctrl+C (SIGINT) 或 SIGTERM 触发
volatile std::sig_atomic_t g_signal = 0;

/// @brief 信号处理函数，设置退出标志后主循环自行退出
void SignalHandler(int signal) {
  g_signal = signal;
}

}  // namespace

// ============================================================
// 参数结构体 — 集中管理所有可调参数
// ============================================================

/**
 * @brief 黑色线迹检测参数（底部 ROI 行扫描 + 直线拟合）
 *
 * 检测流程:
 *   1. 裁取画面底部 ROI（感兴趣区域）
 *   2. ROI 内 BGR → 灰度 → 固定阈值二值化(反色) → 形态学去噪
 *   3. 在 ROI 内等间距扫描 N 行，每行找黑色片段的中点
 *   4. 对所有中点做最小二乘直线拟合
 *   5. 提取线的底部偏移量(offset)和方向角度(angle)
 *
 * 所有参数可在运行时通过 Trackbar 实时调节。
 */
struct LineDetectParams {
  // ===== 灰度二值化阈值 =====
  int threshold = 45;       ///< 二值化阈值 (0~255)，值越低只检测越黑的区域

  // ===== 形态学与过滤 =====
  int    morph_kernel_size = 5;       ///< 形态学核大小 (开/闭运算用，越大去噪越强)
  double min_contour_area  = 500.0;   ///< 最小轮廓面积 (像素^2)，小于此值视为噪点

  // ===== ROI 与扫描 =====
  int roi_bottom_ratio = 100;  ///< 底部 ROI 占画面高度的百分比 (%), 100=全屏检测
  int scan_rows        = 6;   ///< ROI 内扫描行数
};

/**
 * @brief 跟踪控制参数 — 影响机器人运动行为
 *
 * 转向使用双 P 控制器 (位置偏移 + 线角度):
 *   vyaw = -(kp_pos * offset + kp_angle * angle)
 *   vyaw 被钳制在 [-max_vyaw, max_vyaw] 范围内
 *
 * 前进速度:
 *   基准速度 base_vx，弯道根据 |angle| 线性减速，最低至 curve_vx_min
 *   线丢失后原地旋转搜索（朝最后已知方向），解决 D435i 窄视野问题
 */
struct TrackParams {
  // ===== 转向控制 =====
  float kp_pos     = 0.01f;   ///< 位置偏移 P 系数 (像素→rad/s)
  float kp_angle   = 0.8f;    ///< 线角度 P 系数 (rad→rad/s)
  float max_vyaw   = 2.5f;    ///< 最大转向角速度 (rad/s)
  int   dead_zone_x = 40;     ///< 水平死区 (像素)，缩小以便更快响应

  // ===== 前进控制 =====
  float base_vx      = 0.35f;   ///< 基准前进速度 (m/s)
  float curve_vx_min = 0.12f;   ///< 弯道最低速度 (m/s)，|angle| 最大时

  // ===== 丢失搜索 =====
  float search_vyaw = 0.8f;   ///< 丢失时旋转搜索角速度 (rad/s)
};

// ============================================================
// 机器人主状态机 — 巡线 ↔ 图标识别 ↔ 图标动作
// ============================================================

/**
 * @brief 机器人主状态
 *
 * LINE_FOLLOW   : 默认巡线, 同时检测底部红点
 * RED_DOT_STOP  : D435i 底部死区发现红点, 暂停前进
 * TURN_RIGHT_90 : 右转 90° 面朝 logo
 * FACE_LOGO     : 面向 logo, 用 Go2 摄像头识别图标
 * ICON_CONFIRM  : 连续确认图标 (防误检)
 * ICON_ACTION   : 执行图标对应动作
 * TURN_LEFT_90  : 左转 90° 回到巡线方向
 */
enum class RobotState : uint8_t {
  LINE_FOLLOW   = 0,
  RED_DOT_STOP  = 1,
  TURN_RIGHT_90 = 2,
  FACE_LOGO     = 3,
  ICON_CONFIRM  = 4,
  ICON_ACTION   = 5,
  TURN_LEFT_90  = 6,
};

/// @brief 状态 → 可读字符串
inline const char* RobotStateName(RobotState s) {
  switch (s) {
    case RobotState::LINE_FOLLOW:   return "LINE_FOLLOW";
    case RobotState::RED_DOT_STOP:  return "RED_DOT_STOP";
    case RobotState::TURN_RIGHT_90: return "TURN_RIGHT";
    case RobotState::FACE_LOGO:     return "FACE_LOGO";
    case RobotState::ICON_CONFIRM:  return "ICON_CONFIRM";
    case RobotState::ICON_ACTION:   return "ICON_ACTION";
    case RobotState::TURN_LEFT_90:  return "TURN_LEFT";
    default:                        return "UNKNOWN";
  }
}

// ============================================================
// 红点检测 — D435i 画面底部死区找红色标记
// ============================================================

/// @brief 红点检测结果
struct RedDotResult {
  bool  found    = false;
  float center_x = 0.0f;   ///< 红点中心 X (像素)
  float center_y = 0.0f;   ///< 红点中心 Y (像素)
  int   area     = 0;      ///< 红点面积 (像素²)
};

/**
 * @brief D435i 画面底部检测红色标记
 *
 * 在画面底部 dead_zone_bottom_pct% 范围内搜索红色区域
 * 红点位于黑线上, 到达底部死区时触发
 *
 * @param frame                D435i BGR 输入帧
 * @param dead_zone_bottom_pct 底部死区占画面高度百分比
 * @param min_area             最小红点面积 (像素²)
 * @return 检测结果
 */
RedDotResult DetectRedBlob(const cv::Mat& frame,
                           int dead_zone_bottom_pct = 30,
                           int min_area = 100) {
  RedDotResult result;
  const int fh = frame.rows;
  const int fw = frame.cols;

  // 1. 裁取底部死区
  int zone_h = fh * dead_zone_bottom_pct / 100;
  if (zone_h < 20) zone_h = 20;
  cv::Rect zone(0, fh - zone_h, fw, zone_h);
  cv::Mat roi = frame(zone);

  // 2. BGR 红色阈值: R >> G 且 R >> B
  cv::Mat red_mask;
  cv::Mat bgr[3];
  cv::split(roi, bgr);
  // R 通道 > 120, 且 R > 1.8*G, R > 1.8*B
  cv::Mat red_hi = bgr[2] > 120;
  cv::Mat r_over_g, r_over_b;
  cv::divide(bgr[2], bgr[1], r_over_g);
  cv::divide(bgr[2], bgr[0], r_over_b);
  red_mask = red_hi & (r_over_g > 1.8f) & (r_over_b > 1.8f);
  // 形态学去噪
  cv::Mat kernel = cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(3, 3));
  cv::morphologyEx(red_mask, red_mask, cv::MORPH_OPEN, kernel);

  // 3. 找最大红色连通域
  std::vector<std::vector<cv::Point>> contours;
  cv::findContours(red_mask, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

  int best_idx = -1;
  double best_area = 0;
  for (size_t i = 0; i < contours.size(); ++i) {
    double a = cv::contourArea(contours[i]);
    if (a > best_area) { best_area = a; best_idx = static_cast<int>(i); }
  }

  if (best_idx < 0 || best_area < min_area) return result;

  // 4. 计算红点中心 (在完整帧坐标系中)
  cv::Moments m = cv::moments(contours[best_idx]);
  if (m.m00 > 0) {
    result.center_x = static_cast<float>(m.m10 / m.m00);
    result.center_y = static_cast<float>(zone.y + m.m01 / m.m00);  // 转换到帧坐标
  }
  result.area      = static_cast<int>(best_area);
  result.found     = true;
  return result;
}

// ============================================================
// 线迹检测函数
// ============================================================

/**
 * @brief 底部 ROI 行扫描 + 最小二乘直线拟合，检测地面黑色线迹
 *
 * 检测流程:
 *   1. 裁取画面底部 ROI
 *   2. 灰度化 + 固定阈值二值化(反色) + 形态学去噪
 *   3. 等间距扫描 N 行，每行找最长黑色片段的中点
 *   4. 对所有有效中点做最小二乘直线拟合 (x = a*y + b)
 *   5. 提取底部偏移 offset 和线角度 angle
 *
 * @param frame          输入帧 (BGR 格式)
 * @param p              线检测参数
 * @param out_offset     输出: 线在画面底部的 X 偏移 (像素)
 * @param out_angle      输出: 线偏离垂直方向的角度 (rad)
 * @param out_mask       输出: ROI 二值掩码 (用于窗口显示)
 * @param out_scan_pts   输出: 行扫描检测到的中点 (ROI 坐标, y 为 ROI 内坐标)
 * @param out_line_bottom 输出: 拟合线在画面底部的端点 (画面坐标, 用于绘制)
 * @param out_line_top   输出: 拟合线在 ROI 顶部的端点 (画面坐标, 用于绘制)
 * @return true 检测到有效的线迹
 */
bool DetectLine(const cv::Mat& frame,
                const LineDetectParams& p,
                float& out_offset,
                float& out_angle,
                cv::Mat& out_mask,
                std::vector<cv::Point2f>& out_scan_pts,
                cv::Point2f& out_line_bottom,
                cv::Point2f& out_line_top) {
  const int fw = frame.cols;
  const int fh = frame.rows;
  const int center_x = fw / 2;

  // 1. 提取底部 ROI
  int roi_h = fh * p.roi_bottom_ratio / 100;
  if (roi_h < 10) roi_h = 10;
  int roi_y = fh - roi_h;
  cv::Rect roi_rect(0, roi_y, fw, roi_h);
  cv::Mat roi = frame(roi_rect);

  // 2. 灰度化 + 对比度增强 (CLAHE) + 二值化反色
  cv::Mat gray;
  cv::cvtColor(roi, gray, cv::COLOR_BGR2GRAY);
  // CLAHE 自适应直方图均衡化: 增强局部对比度, 让黑线更黑、白底更白,
  // 避免灰阶区域被误判为黑色
  {
    cv::Ptr<cv::CLAHE> clahe = cv::createCLAHE(2.5, cv::Size(8, 8));
    clahe->apply(gray, gray);
  }
  cv::threshold(gray, out_mask, p.threshold, 255, cv::THRESH_BINARY_INV);

  // 3. 形态学去噪: 开运算 + 闭运算
  cv::Mat kernel = cv::getStructuringElement(
      cv::MORPH_ELLIPSE,
      cv::Size(p.morph_kernel_size, p.morph_kernel_size));
  cv::morphologyEx(out_mask, out_mask, cv::MORPH_OPEN,  kernel);
  cv::morphologyEx(out_mask, out_mask, cv::MORPH_CLOSE, kernel);

  // 4. 行扫描: 在 ROI 内从下到上等间距扫描，每行找最长黑色段的中点
  out_scan_pts.clear();
  int n = p.scan_rows;
  if (n < 2) n = 2;
  for (int i = 0; i < n; ++i) {
    int y_roi = roi_h - 1 - i * (roi_h - 1) / (n - 1);
    const uchar* row = out_mask.ptr<uchar>(y_roi);

    // 找该行最长白色连续段 (白色=黑色区域)
    int best_start = -1, best_len = 0;
    int run_start = -1;
    for (int x = 0; x < fw; ++x) {
      if (row[x] > 0) {
        if (run_start < 0) run_start = x;
      } else {
        if (run_start >= 0) {
          int len = x - run_start;
          if (len > best_len) { best_start = run_start; best_len = len; }
          run_start = -1;
        }
      }
    }
    if (run_start >= 0) {
      int len = fw - run_start;
      if (len > best_len) { best_start = run_start; best_len = len; }
    }

    if (best_len > 0) {
      float cx = best_start + best_len * 0.5f;
      out_scan_pts.push_back(cv::Point2f(cx, static_cast<float>(y_roi)));
    }
  }

  // 5. 处理检测结果 — 只要有 ≥1 个点就不算丢失
  if (out_scan_pts.size() < 1) return false;  // 全黑无检测 → 真丢失

  if (out_scan_pts.size() == 1) {
    // 只有一个检测点: 用该点位置引导，无角度信息
    const auto& pt = out_scan_pts[0];
    float cx = pt.x;   // ROI 内 X 坐标
    float cy = pt.y;   // ROI 内 Y 坐标
    out_offset = cx - center_x;
    out_angle  = 0.0f;   // 一个点无法确定方向
    out_line_bottom = cv::Point2f(cx, static_cast<float>(roi_y + cy));
    out_line_top    = out_line_bottom;  // 点画成线就缩成一个像素
    return true;
  }

  // 6. 最小二乘直线拟合: x = a * y + b (y 为 ROI 内坐标, 0 在 ROI 顶部)
  double sum_y = 0, sum_x = 0, sum_yy = 0, sum_xy = 0;
  int valid_n = static_cast<int>(out_scan_pts.size());
  for (const auto& pt : out_scan_pts) {
    double xi = pt.x;
    double yi = pt.y;
    sum_y  += yi;
    sum_x  += xi;
    sum_yy += yi * yi;
    sum_xy += xi * yi;
  }
  double denom = valid_n * sum_yy - sum_y * sum_y;
  if (std::abs(denom) < 1e-9) return false;

  double a = (valid_n * sum_xy - sum_x * sum_y) / denom;   // 斜率 dx/dy
  double b = (sum_x * sum_yy - sum_xy * sum_y) / denom;    // 截距 (x 在 y=0 处)

  // 7. 计算输出值
  double bottom_x_roi = a * roi_h + b;       // 线在 ROI 底部的 X
  out_offset = static_cast<float>(bottom_x_roi - center_x);
  out_angle  = static_cast<float>(std::atan(a));

  // 8. 拟合线在画面中的两个端点（用于绘制）
  out_line_bottom = cv::Point2f(static_cast<float>(bottom_x_roi), static_cast<float>(fh));
  out_line_top    = cv::Point2f(static_cast<float>(b), static_cast<float>(roi_y));

  return true;
}

// ============================================================
// 主函数
// ============================================================

int main(int argc, char** argv) {
  // ==========================================================
  // 0. 命令行参数解析
  // ==========================================================
  // 用法: black_line_tracker <网卡名> [--no-move]
  //   --no-move: 仅检测显示，不控制机器人运动 (用于调试参数)
  if (argc < 2) {
    std::cout << "用法: " << argv[0] << " <网络接口名> [--no-move]" << std::endl;
    std::cout << "例如: " << argv[0] << " enp8s0" << std::endl;
    std::cout << "      " << argv[0] << " enp8s0 --no-move" << std::endl;
    return 1;
  }
  const std::string net_if = argv[1];   // 网络接口名 (如 enp8s0)
  bool no_move = false;                  // 是否禁用运动控制

  for (int i = 2; i < argc; ++i) {
    if (std::string(argv[i]) == "--no-move") no_move = true;
  }

  // 注册信号处理 (Ctrl+C → 安全退出)
  std::signal(SIGINT,  SignalHandler);
  std::signal(SIGTERM, SignalHandler);

  // ==========================================================
  // 1. 初始化 SDK2 通信层
  // ==========================================================

  // 1a. 初始化 DDS 通道 (必须在所有 SDK2 客户端之前调用)
  std::cout << "[INFO] 初始化 DDS Channel (接口: " << net_if << ")..." << std::endl;
  unitree::robot::ChannelFactory::Instance()->Init(0, net_if);

#ifdef USE_REALSENSE
  // 1b. 连接到 Jetson 上的 D435i 中继 (TCP 9191)
  //     rs_sock / d435i_connected 在主循环中用于断连/重连
  const char* kRelayHost = "192.168.123.18";
  const int   kRelayPort = 9191;
  int rs_sock = -1;
  bool d435i_connected = false;
  std::signal(SIGPIPE, SIG_IGN);

  {
    auto try_connect = [&]() -> bool {
      rs_sock = socket(AF_INET, SOCK_STREAM, 0);
      if (rs_sock < 0) return false;
      sockaddr_in relay_addr{};
      relay_addr.sin_family = AF_INET;
      relay_addr.sin_port   = htons(kRelayPort);
      inet_pton(AF_INET, kRelayHost, &relay_addr.sin_addr);
      if (connect(rs_sock, (sockaddr*)&relay_addr, sizeof(relay_addr)) == 0) {
        // 设置接收超时 1 秒, 防止中继无响应时永久阻塞
        struct timeval tv;
        tv.tv_sec  = 1;
        tv.tv_usec = 0;
        setsockopt(rs_sock, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
        d435i_connected = true;
        return true;
      }
      close(rs_sock);
      rs_sock = -1;
      return false;
    };

    std::cout << "[INFO] 连接到 D435i 中继 " << kRelayHost << ":" << kRelayPort << "..." << std::endl;
    while (!g_signal && !try_connect()) {
      std::cerr << "[WARN] 连接 D435i 中继失败, 3s 后重试..." << std::endl;
      std::this_thread::sleep_for(std::chrono::seconds(3));
    }
    if (g_signal) return 1;
    std::cout << "[INFO] D435i 中继已连接" << std::endl;
  }
#endif

  // 1b. 初始化 Go2 内置摄像头 — 始终初始化, 用于图标识别
  //     巡线在 USE_REALSENSE 模式下也用 D435i, 但图标识别固定用 Go2 摄像头
  std::cout << "[INFO] 初始化 VideoClient (图标识别)..." << std::endl;
  unitree::robot::go2::VideoClient video_client;
  video_client.SetTimeout(1.0f);   // 获取图像超时 1 秒
  video_client.Init();

  // 1c. 初始化运动控制客户端 — 用于发送站立/移动等指令
  std::cout << "[INFO] 初始化 SportClient..." << std::endl;
  unitree::robot::go2::SportClient sport_client;
  sport_client.SetTimeout(10.0f);  // 运动指令超时 10 秒
  sport_client.Init();

  // 1d. 初始化 VUI 客户端 — 用于控制前灯亮度
  std::cout << "[INFO] 初始化 VuiClient (前灯控制)..." << std::endl;
  unitree::robot::go2::VuiClient vui_client;
  vui_client.SetTimeout(1.0f);
  vui_client.Init();

  // 诊断: 读取 VUI 当前状态
  {
    int brightness = -1, vui_switch = -1;
    vui_client.GetBrightness(brightness);
    vui_client.GetSwitch(vui_switch);
    std::cout << "[INFO] VUI 状态: brightness=" << brightness
              << " switch=" << vui_switch << std::endl;
  }

  // 1e. 打印可用的服务列表 (找探照灯服务名)
  {
    unitree::robot::go2::RobotStateClient rsc;
    rsc.SetTimeout(3.0f);
    rsc.Init();
    std::vector<unitree::robot::go2::ServiceState> svc_list;
    if (rsc.ServiceList(svc_list) == 0) {
      std::cout << "[INFO] 可用服务列表 (" << svc_list.size() << " 个):" << std::endl;
      for (const auto& s : svc_list) {
        std::cout << "  " << s.name << " (status:" << s.status
                  << " protect:" << s.protect << ")" << std::endl;
      }
    }
  }

  // ==========================================================
  // 2. 站立流程 — 让机器人从任意状态进入站立+行走模式
  // ==========================================================
  if (!no_move) {
    std::cout << "[INFO] 释放当前模式 (Damp)..." << std::endl;
    sport_client.Damp();
    std::this_thread::sleep_for(std::chrono::milliseconds(500));

    std::cout << "[INFO] 恢复站立 (RecoveryStand)..." << std::endl;
    sport_client.RecoveryStand();
    std::this_thread::sleep_for(std::chrono::milliseconds(2000));

    std::cout << "[INFO] 站立 (StandUp)..." << std::endl;
    sport_client.StandUp();
    std::this_thread::sleep_for(std::chrono::milliseconds(2000));

    std::cout << "[INFO] 进入自由行走步态 (FreeWalk)..." << std::endl;
    sport_client.FreeWalk();
    std::this_thread::sleep_for(std::chrono::milliseconds(500));

    // 发送测试转向 — 确认运动通道正常工作
    std::cout << "[INFO] 测试转向..." << std::endl;
    sport_client.Move(0.0f, 0.0f, 0.3f);  // 原地右转 0.3 rad/s
    std::this_thread::sleep_for(std::chrono::milliseconds(500));
    sport_client.Move(0.0f, 0.0f, 0.0f);  // 停止

    std::cout << "[INFO] 机器人已就绪，等待摄像头数据..." << std::endl;
  } else {
    std::cout << "[INFO] --no-move 模式: 跳过站立, 仅检测显示" << std::endl;
    std::cout << "[INFO] 等待摄像头数据..." << std::endl;
  }

  // ==========================================================
  // 3. 创建 OpenCV 窗口和参数 Trackbar
  // ==========================================================

  // 两个窗口: 主画面 + 阈值调参
  const std::string win_main = "Line Tracker";                  // 主画面
  const std::string win_thr  = "Threshold (调参)";              // ROI 二值化调参
  cv::namedWindow(win_main, cv::WINDOW_AUTOSIZE);
  cv::namedWindow(win_thr,  cv::WINDOW_AUTOSIZE);

  // 参数实例 (Trackbar 直接绑定到这些变量的地址)
  LineDetectParams line_params;
  TrackParams      trk_params;

  // --- 检测 Trackbar ---
  cv::createTrackbar("Threshold", win_thr, &line_params.threshold, 255);
  cv::createTrackbar("Morph Size", win_thr, &line_params.morph_kernel_size, 21);
  cv::createTrackbar("ROI %",      win_thr, &line_params.roi_bottom_ratio, 100);
  cv::createTrackbar("Scan Rows",  win_thr, &line_params.scan_rows, 20);
  // createTrackbar 修正
  if (line_params.morph_kernel_size < 1) line_params.morph_kernel_size = 1;
  if (line_params.morph_kernel_size % 2 == 0) line_params.morph_kernel_size++;
  if (line_params.scan_rows < 2) line_params.scan_rows = 2;
  if (line_params.roi_bottom_ratio < 5) line_params.roi_bottom_ratio = 5;

  // 图标检测参数
  IconDetectParams icon_params;
  IconDetector icon_detector;
  ActionCtrlParams act_params;
  ActionController action_ctrl(sport_client, vui_client);

  std::cout << "[DEBUG] 开始加载图标模板..." << std::endl;
  std::cout.flush();

  // 加载图标模板 — 支持多种方式:
  try {
  int loaded = 0;
  bool ref_loaded = false;

  // 优先从 reference_icons.png 加载 (Python版使用的方式)
  std::vector<std::string> ref_paths = {
    "go2_icon_recognition/icons/reference_icons.png",
    "../go2_icon_recognition/icons/reference_icons.png",
    "go2_icon_recognition/reference_icons.png",
    "../go2_icon_recognition/reference_icons.png",
  };
  for (const auto& ref_path : ref_paths) {
    std::cout << "[DEBUG] 尝试加载: " << ref_path << std::endl;
    std::cout.flush();
    if (icon_detector.LoadReferenceIcons(ref_path)) {
      ref_loaded = true;
      std::cout << "[INFO] 从 reference_icons.png 加载模板成功" << std::endl;
      break;
    }
  }

  // 如果reference_icons.png加载失败，尝试单张标志图
  if (!ref_loaded) {
    struct { const char* path; IconType type; } kTmplFiles[] = {
      {"go2_icon_recognition/icons/当心触电.png",      IconType::ELECTRIC_SHOCK},
      {"go2_icon_recognition/icons/当心强氧化物.png",   IconType::OXIDIZER},
      {"go2_icon_recognition/icons/当心辐射.png",       IconType::RADIATION},
    };
    for (const auto& t : kTmplFiles) {
      if (icon_detector.LoadSingleTemplate(t.path, t.type)) loaded++;
    }
    if (loaded < 3) {
      struct { const char* path; IconType type; } kAltFiles[] = {
        {"../go2_icon_recognition/icons/当心触电.png",    IconType::ELECTRIC_SHOCK},
        {"../go2_icon_recognition/icons/当心强氧化物.png", IconType::OXIDIZER},
        {"../go2_icon_recognition/icons/当心辐射.png",    IconType::RADIATION},
      };
      for (const auto& t : kAltFiles) {
        if (icon_detector.LoadSingleTemplate(t.path, t.type)) loaded++;
      }
    }
  }

  if (loaded < 3 && !ref_loaded) {
    std::cerr << "[WARN] 图标模板加载不完整 (loaded=" << loaded << "), "
              << "图标识别可能不准确" << std::endl;
    std::cerr << "[WARN] 请确保存在以下文件之一:" << std::endl;
    std::cerr << "  - go2_icon_recognition/icons/reference_icons.png (推荐)" << std::endl;
    std::cerr << "  - go2_icon_recognition/icons/当心触电.png 等三张图片" << std::endl;
  } else {
    std::cout << "[INFO] 图标模板加载完成 (loaded=" << loaded
              << (ref_loaded ? ", ref模式" : "") << ")" << std::endl;
  }
  } catch (const std::exception& e) {
    std::cerr << "[FATAL] 模板加载异常: " << e.what() << std::endl;
    std::cerr << "[FATAL] 图标识别将不可用, 继续运行巡线..." << std::endl;
  }

  // 图标检测窗口
  const std::string win_icon = "Icon Detect (调试)";
  cv::namedWindow(win_icon, cv::WINDOW_AUTOSIZE);

  std::cout << "============================================" << std::endl;
  std::cout << "  Go2 黑色线迹巡线器 (Line Tracker)" << std::endl;
  std::cout << "============================================" << std::endl;
#ifdef USE_REALSENSE
  std::cout << "  摄像头  : D435i (TCP中继 192.168.123.18:9191)" << std::endl;
#else
  std::cout << "  摄像头  : Go2 内置摄像头" << std::endl;
#endif
  std::cout << "  机器人  : " << net_if << std::endl;
  std::cout << "  运动控制 : " << (no_move ? "关闭" : "开启") << std::endl;
  std::cout << "  图标识别 : 已集成" << std::endl;
  std::cout << "  Q / ESC  : 退出程序" << std::endl;
  std::cout << "============================================" << std::endl;

  // ==========================================================
  // 4. 主循环 — 图像采集 → 线迹检测 → 控制 → 显示
  // ==========================================================

  int  frame_count      = 0;          // 帧计数
  int  lost_count       = 0;          // 目标连续丢失帧数
  float last_line_offset = 0.0f;       // 最后一次检测到的线偏移
  float last_line_angle  = 0.0f;       // 最后一次可靠线迹的角度（用于过弯）

  // ---- 图标识别状态变量 ----
  RobotState robot_state      = RobotState::LINE_FOLLOW;
  IconType   pending_icon     = IconType::NONE;
  int        icon_confirm_cnt = 0;       ///< 当前图标连续确认帧数
  int        action_frame_cnt = 0;       ///< 动作执行帧计数
  int        icon_cooldown    = 0;       ///< 冷却倒计时 (帧数)
  int        d435i_recon_cnt  = 0;      ///< D435i 重连尝试计数
  [[maybe_unused]] int icon_debug_frame = 0;  ///< 上次检测到 logo 的帧号

  while (g_signal == 0) {

// ============================================================
// 4a. 获取巡线帧 (来源: D435i 或 Go2 摄像头)
// ============================================================
cv::Mat frame;
#ifdef USE_REALSENSE
    if (d435i_connected) {
      // --- 从 D435i 中继接收帧 ---
      int32_t img_w = 0, img_h = 0;
      ssize_t nr = recv(rs_sock, &img_w, sizeof(img_w), MSG_WAITALL);
      if (nr != sizeof(img_w)) {
        std::cerr << "[WARN] D435i 中继断开, 将自动重连" << std::endl;
        close(rs_sock); rs_sock = -1; d435i_connected = false;
        frame = cv::Mat();  // 空帧
      } else {
        nr = recv(rs_sock, &img_h, sizeof(img_h), MSG_WAITALL);
        if (nr != sizeof(img_h) || img_w <= 0 || img_h <= 0 ||
            img_w > 1920 || img_h > 1080) {
          frame = cv::Mat();
        } else {
          std::vector<uint8_t> img_buf(img_w * img_h * 3);
          nr = recv(rs_sock, img_buf.data(), img_buf.size(), MSG_WAITALL);
          if (nr == static_cast<ssize_t>(img_buf.size())) {
            frame = cv::Mat(img_h, img_w, CV_8UC3, img_buf.data()).clone();
            frame_count++;
          } else {
            frame = cv::Mat();
          }
        }
      }
    } else {
      // D435i 未连接: 每隔 30 次循环尝试重连
      d435i_recon_cnt++;
      if (d435i_recon_cnt % 30 == 0) {
        rs_sock = socket(AF_INET, SOCK_STREAM, 0);
        if (rs_sock >= 0) {
          sockaddr_in addr{};
          addr.sin_family = AF_INET;
          addr.sin_port   = htons(kRelayPort);
          inet_pton(AF_INET, kRelayHost, &addr.sin_addr);
          if (connect(rs_sock, (sockaddr*)&addr, sizeof(addr)) == 0) {
            struct timeval tv;
            tv.tv_sec  = 1;
            tv.tv_usec = 0;
            setsockopt(rs_sock, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
            d435i_connected = true;
            d435i_recon_cnt = 0;
            std::cout << "[INFO] D435i 重连成功" << std::endl;
          } else { close(rs_sock); rs_sock = -1; }
        }
      }
      frame = cv::Mat();  // 空帧, 替换为黑色占位
    }
#else
    // === Go2 内置摄像头 (巡线 + 图标识别共用) ===
    std::vector<uint8_t> jpeg_buffer;
    int ret = video_client.GetImageSample(jpeg_buffer);
    frame_count++;
    if (ret != 0 || jpeg_buffer.empty()) {
      if (frame_count <= 3)
        std::cerr << "[WARN] GetImageSample 失败 ret=" << ret << std::endl;
      std::this_thread::sleep_for(std::chrono::milliseconds(50));
      continue;
    }

    frame = cv::imdecode(jpeg_buffer, cv::IMREAD_COLOR);
    if (frame.empty()) {
      if (frame_count <= 3)
        std::cerr << "[WARN] JPEG 解码失败" << std::endl;
      continue;
    }
#endif

    // D435i 断开时 frame 为空 → 跳过渲染, 但状态机照常运行
    if (frame.empty()) {
      // 确保图标检测和状态机仍运行
      // 但 imshow 需要非空帧 → 用黑色空白代替
      frame = cv::Mat::zeros(480, 640, CV_8UC3);
    }

// ============================================================
// 4b. 获取图标识别帧 (始终使用 Go2 内置摄像头)
// ============================================================
cv::Mat frame_icon;
#ifdef USE_REALSENSE
    // D435i 巡线模式下, 单独取一帧 VideoClient 用于图标识别
    {
      std::vector<uint8_t> icon_jpeg;
      int iret = video_client.GetImageSample(icon_jpeg);
      if (iret == 0 && !icon_jpeg.empty()) {
        frame_icon = cv::imdecode(icon_jpeg, cv::IMREAD_COLOR);
        if (frame_icon.empty()) {
          std::cerr << "[WARN] VideoClient JPEG 解码失败 (帧#" << frame_count << ")" << std::endl;
        }
      } else {
        // 只在首次失败时打印, 避免刷屏
        static bool s_vc_warned = false;
        if (!s_vc_warned) {
          std::cerr << "[WARN] VideoClient.GetImageSample 失败 iret=" << iret
                    << " (帧#" << frame_count << "), 图标识别不可用" << std::endl;
          s_vc_warned = true;
        }
      }
    }
#else
    // 非 D435i 模式下, 巡线和图标识别共用同一帧 (浅拷贝即可)
    frame_icon = frame;
#endif

    // --- 诊断: VUI 状态 (每 150 帧) ---
    if (frame_count % 150 == 0 && !no_move) {
      int b = -1, s = -1;
      vui_client.GetBrightness(b);
      vui_client.GetSwitch(s);
      std::cout << "[VUI] 帧#" << frame_count << " brightness=" << b
                << " switch=" << s << std::endl;
    }
    if (frame_count % 150 == 0) {
      std::cout << "[DIAG] 帧#" << frame_count
                << " 状态=" << RobotStateName(robot_state)
                << " frame_icon=" << (frame_icon.empty() ? "空" :
                    std::to_string(frame_icon.cols)+"x"+std::to_string(frame_icon.rows))
                << " cooldown=" << icon_cooldown
                << std::endl;
    }

    // --- 图标帧降采样 (平衡速度与检测精度) ---
    const int kIconMaxWidth = 960;
    if (!frame_icon.empty() && frame_icon.cols > kIconMaxWidth) {
      double scale = static_cast<double>(kIconMaxWidth) / frame_icon.cols;
      int new_h = static_cast<int>(frame_icon.rows * scale);
      cv::resize(frame_icon, frame_icon, cv::Size(kIconMaxWidth, new_h));
    }

    // 画面几何常量
    const int center_x = frame.cols / 2;   // 画面水平中心 X
    const int frame_h  = frame.rows;       // 画面高度

    // 计算 ROI 参数 (与 DetectLine 一致，用于绘图)
    int roi_h = frame_h * line_params.roi_bottom_ratio / 100;
    if (roi_h < 10) roi_h = 10;
    int roi_y = frame_h - roi_h;

    // 确保 morph_kernel_size 为奇数
    if (line_params.morph_kernel_size < 1) line_params.morph_kernel_size = 1;
    if (line_params.morph_kernel_size % 2 == 0) line_params.morph_kernel_size++;

    // ==========================================================
    // 4c. 线迹检测
    // ==========================================================
    float line_offset = 0.0f, line_angle = 0.0f;
    cv::Mat line_mask;
    std::vector<cv::Point2f> scan_pts;
    cv::Point2f line_bottom, line_top;
    bool line_found = false;

    try {
      line_found = DetectLine(frame, line_params,
                              line_offset, line_angle,
                              line_mask, scan_pts,
                              line_bottom, line_top);
    } catch (...) {}  // 检测异常不崩溃，跳过此帧

    // ==========================================================
    // 4d. 控制逻辑 — 状态机: 巡线 ↔ 图标识别 ↔ 图标动作
    // ==========================================================
    float vx   = 0.0f;   // 前进速度 (m/s)，正=前进
    float vyaw = 0.0f;   // 转向角速度 (rad/s)，正=左转，负=右转

    // 绘制画面垂直中线 — 参考线，偏移量的零点
    cv::line(frame, cv::Point(center_x, 0), cv::Point(center_x, frame_h),
             cv::Scalar(255, 0, 0), 1);  // 蓝色细线

    // 绘制 ROI 边界
    cv::line(frame, cv::Point(0, roi_y), cv::Point(frame.cols, roi_y),
             cv::Scalar(255, 255, 0), 1);  // 黄色横线标记 ROI 上边界

    // ---- 图标检测冷却递减 ----
    if (icon_cooldown > 0) icon_cooldown--;

    // ==========================================================
    // 状态机分支
    // ==========================================================
    switch (robot_state) {

    // ===========================================================
    // 状态1: 巡线 (默认)
    //   D435i 看黑线 + 底部死区检测红点
    // ===========================================================
    case RobotState::LINE_FOLLOW: {
      // --- 线迹控制 ---
      if (line_found) {
        lost_count = 0;
        last_line_offset = line_offset;

        float pos_term = trk_params.kp_pos * line_offset;
        const float kCornerAngle = 0.87f;
        bool at_corner = (std::abs(line_angle) > kCornerAngle);
        if (!at_corner) {
          last_line_angle = line_angle;
          float angle_use = line_angle;
          const float kAngleClip = 1.0f;
          if (angle_use >  kAngleClip) angle_use =  kAngleClip;
          if (angle_use < -kAngleClip) angle_use = -kAngleClip;
          vyaw = -(pos_term - trk_params.kp_angle * angle_use);
        } else {
          vyaw = (last_line_angle >= 0) ? 0.35f : -0.35f;
        }
        vyaw = std::max(-trk_params.max_vyaw, std::min(trk_params.max_vyaw, vyaw));
        if (!at_corner) {
          float angle_abs = std::abs(line_angle);
          float angle_norm = std::min(angle_abs / 1.5f, 1.0f);
          vx = trk_params.base_vx - angle_norm * (trk_params.base_vx - trk_params.curve_vx_min);
        } else { vx = trk_params.base_vx * 0.6f; }

        try {
          for (const auto& pt : scan_pts)
            cv::circle(frame, cv::Point(static_cast<int>(pt.x), roi_y + static_cast<int>(pt.y)),
                       4, cv::Scalar(0,255,0), -1);
          cv::line(frame, cv::Point(static_cast<int>(line_top.x), static_cast<int>(line_top.y)),
                   cv::Point(static_cast<int>(line_bottom.x), static_cast<int>(line_bottom.y)),
                   cv::Scalar(0,255,0), 2);
          char info[128];
          snprintf(info, sizeof(info), "LINE off:%.0f ang:%.1fdeg vx:%.2f vyaw:%.2f",
                   line_offset, line_angle*180.0f/CV_PI, vx, vyaw);
          cv::putText(frame, info, cv::Point(10,30), cv::FONT_HERSHEY_SIMPLEX, 0.5,
                      cv::Scalar(0,255,0), 2);
        } catch (...) {}
      } else {
        lost_count++;
        vx = 0.0f;
        vyaw = (last_line_offset > 0) ? -trk_params.search_vyaw : trk_params.search_vyaw;
        cv::putText(frame, "LINE LOST ("+std::to_string(lost_count)+") SEARCHING",
                    cv::Point(10,30), cv::FONT_HERSHEY_SIMPLEX, 0.7, cv::Scalar(0,165,255), 2);
      }

      // --- 底部死区红点检测 (触发条件) ---
      if (icon_cooldown <= 0) {
        RedDotResult red = DetectRedBlob(frame, 30, 100);
        if (red.found) {
          // 绘制红点 (调试)
          cv::circle(frame, cv::Point(static_cast<int>(red.center_x),
                     static_cast<int>(red.center_y)), 10, cv::Scalar(0,0,255), 2);
          // 红点到达底部死区 → 触发!
          std::cout << "\n[!!!] 红点检测! 中心(" << int(red.center_x) << ","
                    << int(red.center_y) << ") 面积=" << red.area
                    << " 帧#" << frame_count << " 停车+准备右转!" << std::endl;
          if (!no_move) {
            try { sport_client.StopMove(); sport_client.Move(0,0,0); } catch (...) {}
          }
          vx = 0.0f; vyaw = 0.0f;
          robot_state = RobotState::RED_DOT_STOP;
        }
      }
      break;
    }

    // ===========================================================
    // 状态2: 红点触发 → 暂停前进, 等待0.5s 然后右转
    // ===========================================================
    case RobotState::RED_DOT_STOP: {
      vx = 0.0f; vyaw = 0.0f;
      static int red_wait = 0;
      red_wait++;
      if (red_wait > 15) {  // ~0.5s 稳定
        red_wait = 0;
        robot_state = RobotState::TURN_RIGHT_90;
        std::cout << "[TURN] 开始右转90°..." << std::endl;
      }
      cv::putText(frame, "RED DOT! STOPPING...", cv::Point(10,60),
                  cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(0,0,255), 2);
      break;
    }

    // ===========================================================
    // 状态3: 右转90° 面朝 logo
    // ===========================================================
    case RobotState::TURN_RIGHT_90: {
      vx = 0.0f;
      // 右转为负 vyaw, ~1.0 rad/s 转约1.6s = 90°
      const float kTurnSpeed = -1.0f;
      const int   kTurnFrames = 48;  // ~1.6s at 30fps
      static int turn_cnt = 0;
      if (turn_cnt < kTurnFrames) {
        vyaw = kTurnSpeed;
        turn_cnt++;
      } else {
        vyaw = 0.0f;
        turn_cnt = 0;
        robot_state = RobotState::FACE_LOGO;
        if (!no_move) sport_client.Move(0,0,0);
        std::cout << "[TURN] 右转完成, 开始识别logo..." << std::endl;
      }
      cv::putText(frame, "TURNING RIGHT 90deg...", cv::Point(10,60),
                  cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(255,0,255), 2);
      break;
    }

    // ===========================================================
    // 状态4: 面向logo, VideoClient 检测图标
    // ===========================================================
    case RobotState::FACE_LOGO: {
      vx = 0.0f; vyaw = 0.0f;  // 静止
      if (!frame_icon.empty()) {
        auto icon_results = icon_detector.Detect(frame_icon, frame_count);
        if (!icon_results.empty() && icon_results[0].confidence > act_params.confirm_conf) {
          std::cout << "\n[!!!] LOGO 检测! " << IconTypeName(icon_results[0].type)
                    << " (conf:" << int(icon_results[0].confidence*100)
                    << "%) 帧#" << frame_count << " 开始10帧确认..." << std::endl;
          pending_icon  = icon_results[0].type;
          robot_state   = RobotState::ICON_CONFIRM;
        }
      }
      cv::putText(frame, "FACING LOGO - WAITING...", cv::Point(10,60),
                  cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(0,255,255), 2);
      break;
    }

    // ===========================================================
    // 状态5: 图标确认 (3秒时间窗口, 持续检测同一图标才确认)
    // ===========================================================
    case RobotState::ICON_CONFIRM: {
      vx = 0.0f; vyaw = 0.0f;
      bool confirmed = false;
      bool lost      = false;

      if (!frame_icon.empty() && frame_count % 3 == 0) {  // 每3帧检测一次
        auto icon_results = icon_detector.Detect(frame_icon, frame_count);
        if (!icon_results.empty() && icon_results[0].type == pending_icon
            && icon_results[0].confidence > act_params.confirm_conf) {
          icon_confirm_cnt++;
          if (icon_confirm_cnt >= act_params.confirm_frames) confirmed = true;
        } else {
          lost = true;
        }
      }

      if (lost) {
        icon_confirm_cnt = 0;
        pending_icon = IconType::NONE;
        robot_state = RobotState::FACE_LOGO;
        std::cout << "[ICON] 确认丢失/变化, 继续面朝logo" << std::endl;
      } else if (confirmed) {
        std::cout << "\n[!!!] 图标确认! " << IconTypeName(pending_icon)
                  << " (10帧持续检测通过) 执行动作" << std::endl;
        robot_state = RobotState::ICON_ACTION;
        action_frame_cnt = 0;
      }

      char buf[64];
      snprintf(buf, sizeof(buf), "ICON:%s 确认 [%d/%d]",
               IconTypeName(pending_icon), icon_confirm_cnt, act_params.confirm_frames);
      cv::putText(frame, buf, cv::Point(10,90), cv::FONT_HERSHEY_SIMPLEX, 0.6,
                  cv::Scalar(0,255,255), 2);
      break;
    }

    // ===========================================================
    // 状态6: 执行图标动作 (动作后原地停顿 10s 再左转)
    // ===========================================================
    case RobotState::ICON_ACTION: {
      vx = 0.0f; vyaw = 0.0f;
      if (action_frame_cnt == 0) {
        std::cout << "[ICON] 执行: " << IconTypeName(pending_icon)
                  << " (" << ActionController::GetActionName(pending_icon) << ")" << std::endl;
        if (!no_move) action_ctrl.ExecuteAction(pending_icon);
        // 动作 (~8s) 已覆盖识别到巡线的总时长, 稍作停顿即可
        std::cout << "[ICON] 动作完成, 准备左转回路线" << std::endl;
        action_frame_cnt = 1;
      } else {
        action_frame_cnt++;
        if (action_frame_cnt > 10) {
          std::cout << "[ICON] 左转90°回路线" << std::endl;
          robot_state = RobotState::TURN_LEFT_90;
          action_frame_cnt = 0;
        }
      }
      cv::putText(frame, "ACTION:"+std::string(IconTypeName(pending_icon)),
                  cv::Point(frame.cols/2-80, frame_h/2),
                  cv::FONT_HERSHEY_SIMPLEX, 1.0, cv::Scalar(0,0,255), 2);
      break;
    }

    // ===========================================================
    // 状态7: 左转90° 回到线路方向
    // ===========================================================
    case RobotState::TURN_LEFT_90: {
      vx = 0.0f;
      const float kTurnSpeed = 1.0f;   // 左转为正
      const int   kTurnFrames = 48;
      static int lturn_cnt = 0;
      if (lturn_cnt < kTurnFrames) {
        vyaw = kTurnSpeed;
        lturn_cnt++;
      } else {
        vyaw = 0.0f;
        lturn_cnt = 0;
        pending_icon = IconType::NONE;
        icon_cooldown = act_params.cooldown_ms / 33;  // 冷却期防止红点立即再触发
        robot_state = RobotState::LINE_FOLLOW;
        if (!no_move) sport_client.Move(0,0,0);
        std::cout << "[TURN] 左转完成, 恢复巡线 (冷却" << icon_cooldown << "帧)" << std::endl;
      }
      cv::putText(frame, "TURNING LEFT 90deg...", cv::Point(10,60),
                  cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(255,0,255), 2);
      break;
    }
    }  // switch (robot_state)

    // === 4e. 发送运动指令 ===
    // LINE_FOLLOW + 转向状态需要持续发送 Move
    if (!no_move && (robot_state == RobotState::LINE_FOLLOW ||
                     robot_state == RobotState::TURN_RIGHT_90 ||
                     robot_state == RobotState::TURN_LEFT_90)) {
      try { sport_client.Move(vx, 0.0f, vyaw); } catch (...) { break; }
    }

    // === 4f. 画面底部状态栏 ===
    char status[192];
    snprintf(status, sizeof(status),
             "[%s] CMD:vx=%.2f vyaw=%.2f | Lost:%d | Frm:%d | Icon:%s",
             RobotStateName(robot_state),
             vx, vyaw, lost_count, frame_count,
             (pending_icon != IconType::NONE) ? IconTypeName(pending_icon) : "-");
    cv::putText(frame, status, cv::Point(10, frame_h-15),
                cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(255, 255, 255), 2);

    // === 4g. 显示窗口 ===
    try {
      cv::imshow(win_main, frame);       // 主画面
      // ROI 二值化掩码窗口 (未检测到时显示黑屏)
      cv::imshow(win_thr,  line_found ? line_mask
                      : cv::Mat::zeros(roi_h, frame.cols, CV_8UC1));
      // 图标检测调试窗口
      cv::Mat icon_dbg = icon_detector.GetDebugVis();
      if (!icon_dbg.empty()) {
        cv::imshow(win_icon, icon_dbg);
      }
    } catch (...) {
      std::cerr << "[FATAL] imshow 异常" << std::endl;
      break;
    }

    // === 4h. 键盘检测 (1ms 超时，不阻塞) ===
    int key = cv::waitKey(1);
    if (key == 'q' || key == 'Q' || key == 27) {   // Q 键 或 ESC 键
      std::cout << "[INFO] 用户退出" << std::endl;
      break;
    }
  }  // end while 主循环

  // ==========================================================
  // 5. 安全清理
  // ==========================================================
  if (!no_move) {
    // 5a. 停止运动
    std::cout << "[INFO] 停止运动..." << std::endl;
    sport_client.StopMove();
    std::this_thread::sleep_for(std::chrono::milliseconds(300));

    // 5b. 趴下 (进入安全状态)
    std::cout << "[INFO] 趴下..." << std::endl;
    sport_client.StandDown();
    std::this_thread::sleep_for(std::chrono::milliseconds(500));
  }

  // 5c. 关闭所有 OpenCV 窗口
  cv::destroyAllWindows();
  std::cout << "[INFO] 线迹巡线器已安全关闭" << std::endl;
  return 0;
}
