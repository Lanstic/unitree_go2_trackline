#!/usr/bin/env python3
"""
Go2 图标识别 - 模板提取工具
用于从参考图片中提取干净的警示标志模板。
"""

import os
import sys
import cv2
import numpy as np
import argparse


def extract_warning_sign_roi(image: np.ndarray) -> np.ndarray:
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

    yellow_lower = np.array([15, 80, 100], dtype=np.uint8)
    yellow_upper = np.array([35, 255, 255], dtype=np.uint8)
    yellow_mask = cv2.inRange(hsv, yellow_lower, yellow_upper)

    orange_lower = np.array([0, 100, 100], dtype=np.uint8)
    orange_upper = np.array([20, 255, 255], dtype=np.uint8)
    orange_mask = cv2.inRange(hsv, orange_lower, orange_upper)

    combined = cv2.bitwise_or(yellow_mask, orange_mask)

    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (7, 7))
    combined = cv2.morphologyEx(combined, cv2.MORPH_CLOSE, kernel, iterations=3)
    combined = cv2.morphologyEx(combined, cv2.MORPH_OPEN, kernel, iterations=2)

    contours, _ = cv2.findContours(combined, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return image

    largest = max(contours, key=cv2.contourArea)

    epsilon = 0.02 * cv2.arcLength(largest, True)
    approx = cv2.approxPolyDP(largest, epsilon, True)

    if len(approx) != 3:
        return image

    x, y, w, h = cv2.boundingRect(largest)
    pad = max(w, h) // 20
    x, y = max(0, x - pad), max(0, y - pad)
    w, h = w + 2 * pad, h + 2 * pad

    roi = image[y:y + h, x:x + w]
    return roi


def normalize_template(roi: np.ndarray, target_size: int = 128) -> np.ndarray:
    h, w = roi.shape[:2]
    scale = target_size / max(h, w)
    new_w, new_h = int(w * scale), int(h * scale)
    resized = cv2.resize(roi, (new_w, new_h), interpolation=cv2.INTER_AREA)

    canvas = np.ones((target_size, target_size, 3), dtype=np.uint8) * 255
    x_offset = (target_size - new_w) // 2
    y_offset = (target_size - new_h) // 2
    canvas[y_offset:y_offset + new_h, x_offset:x_offset + new_w] = resized
    return canvas


def process_image(image_path: str, output_path: str = None, target_size: int = 128):
    if not os.path.isfile(image_path):
        print(f"[!] 文件不存在: {image_path}")
        return

    image = cv2.imread(image_path)
    if image is None:
        print(f"[!] 无法读取: {image_path}")
        return

    print(f"[*] 处理: {image_path}")

    roi = extract_warning_sign_roi(image)
    print(f"    ROI: {roi.shape}")

    template = normalize_template(roi, target_size)
    print(f"    模板尺寸: {template.shape}")

    if output_path:
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        cv2.imwrite(output_path, template)
        print(f"    保存: {output_path}")
    else:
        base, ext = os.path.splitext(image_path)
        output = f"{base}_template{ext}"
        cv2.imwrite(output, template)
        print(f"    保存: {output}")


def main():
    parser = argparse.ArgumentParser(description='提取警示标志模板')
    parser.add_argument('input', help='输入图片路径或目录')
    parser.add_argument('--output', '-o', default='',
                        help='输出路径 (文件或目录)')
    parser.add_argument('--size', '-s', type=int, default=128,
                        help='模板目标尺寸 (默认: 128)')
    args = parser.parse_args()

    input_path = args.input
    output_path = args.output
    target_size = args.size

    if os.path.isdir(input_path):
        extensions = ['.jpg', '.jpeg', '.png', '.bmp']
        files = [f for f in os.listdir(input_path)
                 if any(f.lower().endswith(ext) for ext in extensions)]

        if not files:
            print(f"[!] 目录中没有图片文件: {input_path}")
            return

        output_dir = output_path if output_path else input_path
        print(f"[*] 批量处理: {len(files)} 张图片")
        for fname in sorted(files):
            fpath = os.path.join(input_path, fname)
            base, ext = os.path.splitext(fname)
            out = os.path.join(output_dir, f"{base}_template{ext}")
            process_image(fpath, out, target_size)
    else:
        out = output_path if output_path else ''
        process_image(input_path, out, target_size)

    print("[*] 处理完成!")


if __name__ == '__main__':
    main()
