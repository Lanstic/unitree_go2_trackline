"""
Go2 图标识别 - 核心检测引擎
基于 OpenCV 图像处理 + 轮廓分析
支持三种警示标志: 当心触电 / 当心强氧化物 / 当心辐射
"""

import cv2
import numpy as np
from enum import Enum
from dataclasses import dataclass
from typing import Optional, Tuple, List


class IconType(Enum):
    NONE = "none"
    ELECTRIC_SHOCK = "electric_shock"
    OXIDIZER = "oxidizer"
    RADIATION = "radiation"
    ALL = "all"


@dataclass
class DetectionResult:
    icon_type: IconType
    confidence: float
    bounding_box: Tuple[int, int, int, int]
    timestamp: float


class WarningTriangleDetector:
    YELLOW_LOWER = np.array([15, 80, 100], dtype=np.uint8)
    YELLOW_UPPER = np.array([35, 255, 255], dtype=np.uint8)
    ORANGE_LOWER = np.array([0, 100, 100], dtype=np.uint8)
    ORANGE_UPPER = np.array([20, 255, 255], dtype=np.uint8)

    TEMPLATE_SIZE = 80

    def __init__(self):
        self._templates = self._load_templates()

    def _load_templates(self) -> dict:
        """Load reference symbol templates from bundled images."""
        import os as _os
        templates = {}
        icon_map = [
            (IconType.ELECTRIC_SHOCK, 0),
            (IconType.OXIDIZER, 1),
            (IconType.RADIATION, 2),
        ]
        icons_dir = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "icons")
        ref_path = _os.path.join(icons_dir, "reference_icons.png")
        if not _os.path.exists(ref_path):
            print(f"[Detector] Warning: reference_icons.png not found at {ref_path}")
            return templates
        ref = cv2.imread(ref_path)
        if ref is None:
            print(f"[Detector] Warning: could not read {ref_path}")
            return templates
        # Bounding boxes of the three warning signs in reference_icons.png
        positions = [(233, 126), (481, 128), (731, 127)]
        for (itype, idx) in icon_map:
            x, y = positions[idx]
            roi = ref[y:y + 160, x:x + 185]
            sym_bin = self._extract_inner_symbol_bin(roi)
            if sym_bin is not None:
                sym_resized = cv2.resize(sym_bin, (self.TEMPLATE_SIZE, self.TEMPLATE_SIZE))
                templates[itype] = sym_resized
        return templates

    def _extract_inner_symbol_bin(self, roi: np.ndarray) -> Optional[np.ndarray]:
        """Extract the inner black symbol as binary mask from a warning-sign ROI."""
        gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
        black = cv2.inRange(gray, np.array(0), np.array(80))
        hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
        yellow = cv2.inRange(hsv, self.YELLOW_LOWER, self.YELLOW_UPPER)
        orange = cv2.inRange(hsv, self.ORANGE_LOWER, self.ORANGE_UPPER)
        border = cv2.bitwise_or(yellow, orange)
        contours, _ = cv2.findContours(border, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            return None
        largest = max(contours, key=cv2.contourArea)
        mask = np.zeros(gray.shape, dtype=np.uint8)
        cv2.drawContours(mask, [largest], -1, 255, -1)
        black_inside = cv2.bitwise_and(black, mask)
        contours2, _ = cv2.findContours(black_inside, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours2:
            return None
        sym_cnt = max(contours2, key=cv2.contourArea)
        x, y, bw, bh = cv2.boundingRect(sym_cnt)
        return black_inside[y:y + bh, x:x + bw]

    def detect(self, frame: np.ndarray, target: IconType = IconType.ALL) -> List[DetectionResult]:
        results = []
        h, w = frame.shape[:2]

        yellow_mask = self._get_yellow_mask(frame)
        orange_mask = self._get_orange_mask(frame)
        bg_mask = cv2.bitwise_or(yellow_mask, orange_mask)

        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
        bg_mask = cv2.morphologyEx(bg_mask, cv2.MORPH_CLOSE, kernel, iterations=2)
        bg_mask = cv2.morphologyEx(bg_mask, cv2.MORPH_OPEN, kernel, iterations=1)

        contours, _ = cv2.findContours(bg_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area < 500 or area > (h * w * 0.8):
                continue

            # Try multiple epsilon values
            approx = None
            for eps_pct in [0.02, 0.025, 0.03]:
                epsilon = eps_pct * cv2.arcLength(cnt, True)
                approx_test = cv2.approxPolyDP(cnt, epsilon, True)
                if len(approx_test) == 3:
                    approx = approx_test
                    break

            if approx is None or len(approx) != 3:
                continue

            sides = self._get_side_lengths(approx)
            if not self._is_triangle_valid(sides):
                continue

            x, y, bw, bh = cv2.boundingRect(cnt)
            pad = 5
            x1 = max(0, x - pad)
            y1 = max(0, y - pad)
            x2 = min(w, x + bw + pad)
            y2 = min(h, y + bh + pad)
            roi = frame[y1:y2, x1:x2]

            if roi.size == 0:
                continue

            icon_type, confidence = self._identify_inner_symbol(roi)

            if icon_type == IconType.NONE:
                continue

            if target != IconType.ALL and icon_type != target:
                continue

            results.append(DetectionResult(
                icon_type=icon_type,
                confidence=confidence,
                bounding_box=(x1, y1, x2 - x1, y2 - y1),
                timestamp=0
            ))

        return results

    def _get_yellow_mask(self, frame: np.ndarray) -> np.ndarray:
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, self.YELLOW_LOWER, self.YELLOW_UPPER)
        return mask

    def _get_orange_mask(self, frame: np.ndarray) -> np.ndarray:
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, self.ORANGE_LOWER, self.ORANGE_UPPER)
        return mask

    def _get_side_lengths(self, approx: np.ndarray) -> List[float]:
        lengths = []
        n = len(approx)
        for i in range(n):
            p1 = approx[i][0]
            p2 = approx[(i + 1) % n][0]
            length = np.linalg.norm(p1.astype(float) - p2.astype(float))
            lengths.append(length)
        return lengths

    def _is_triangle_valid(self, sides: List[float]) -> bool:
        if len(sides) != 3:
            return False
        s = sorted(sides)
        return s[2] < (s[0] + s[1]) * 1.6 and s[0] > 20

    def _identify_inner_symbol(self, roi: np.ndarray) -> Tuple[IconType, float]:
        gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
        h, w = roi.shape[:2]

        black_mask = cv2.inRange(roi, np.array([0, 0, 0]), np.array([80, 80, 80]))
        contours, _ = cv2.findContours(black_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        if not contours:
            return IconType.NONE, 0.0

        largest = max(contours, key=cv2.contourArea)
        cnt_area = cv2.contourArea(largest)
        tri_area = h * w

        if cnt_area < tri_area * 0.03 or cnt_area > tri_area * 0.75:
            return IconType.NONE, 0.0

        symbol_roi = self._extract_symbol_roi(roi, largest)
        if symbol_roi is None:
            return IconType.NONE, 0.0

        sym_h, sym_w = symbol_roi.shape[:2]
        if sym_h < 5 or sym_w < 5:
            return IconType.NONE, 0.0

        sym_bin = self._extract_inner_symbol_bin(symbol_roi)
        if sym_bin is None:
            return IconType.NONE, 0.0

        detected = cv2.resize(sym_bin, (self.TEMPLATE_SIZE, self.TEMPLATE_SIZE))

        if not self._templates:
            return IconType.NONE, 0.0

        scores = {}
        for itype, template in self._templates.items():
            score = cv2.matchTemplate(detected, template, cv2.TM_CCOEFF_NORMED)[0, 0]
            scores[itype] = float(score)

        best_type = max(scores, key=scores.get)
        best_conf = scores[best_type]

        if best_conf < 0.15:
            return IconType.NONE, 0.0

        return best_type, min(best_conf, 1.0)

    def _extract_symbol_roi(self, roi: np.ndarray, cnt) -> Optional[np.ndarray]:
        h, w = roi.shape[:2]
        x, y, cw, ch = cv2.boundingRect(cnt)
        pad = 2
        x1 = max(0, x - pad)
        y1 = max(0, y - pad)
        x2 = min(w, x + cw + pad)
        y2 = min(h, y + ch + pad)
        return roi[y1:y2, x1:x2]

    def _compute_radial_symmetry(self, binary: np.ndarray) -> float:
        h, w = binary.shape
        cy, cx = h // 2, w // 2
        max_r = min(cx, cy) * 0.8
        angles = np.arange(0, 360, 5)
        intensities = []

        for angle in angles:
            rad = np.radians(angle)
            r = int(max_r * 0.6)
            px = int(cx + r * np.cos(rad))
            py = int(cy + r * np.sin(rad))
            if 0 <= py < h and 0 <= px < w:
                intensities.append(1 if binary[py, px] > 0 else 0)

        if len(intensities) < 12:
            return 0.0

        intensities = np.array(intensities)
        n = len(intensities)
        peaks = []
        for i in range(n):
            prev_idx = (i - 1) % n
            next_idx = (i + 1) % n
            if intensities[i] > intensities[prev_idx] and intensities[i] > intensities[next_idx]:
                if intensities[i] == 1:
                    peaks.append(i)

        if len(peaks) >= 2:
            intervals = [(peaks[(i + 1) % len(peaks)] - peaks[i]) % n for i in range(len(peaks) - 1)]
            if len(peaks) == 3:
                intervals.append((peaks[0] - peaks[2]) % n)
            intervals = np.array(intervals) / n * 360
            deviation = np.std(intervals)
            symmetry = max(0, 1 - deviation / 90)
            return symmetry

        return 0.0

    def _count_sharp_corners(self, cnt) -> int:
        if len(cnt) < 3:
            return 0
        angles = []
        n = len(cnt)
        for i in range(n):
            p0 = cnt[(i - 2) % n][0].astype(float)
            p1 = cnt[(i - 1) % n][0].astype(float)
            p2 = cnt[i][0].astype(float)
            v1 = p1 - p0
            v2 = p2 - p1
            norm1 = np.linalg.norm(v1)
            norm2 = np.linalg.norm(v2)
            if norm1 < 1e-6 or norm2 < 1e-6:
                continue
            cos_angle = np.clip(np.dot(v1, v2) / (norm1 * norm2), -1, 1)
            angle = np.degrees(np.arccos(cos_angle))
            angles.append(angle)
        sharp_count = sum(1 for a in angles if 20 < a < 80)
        return sharp_count

    def get_debug_visualization(self, frame: np.ndarray,
                                 results: List[DetectionResult],
                                 show_mask: bool = False) -> np.ndarray:
        debug = frame.copy()

        color_map = {
            IconType.ELECTRIC_SHOCK: (0, 255, 255),
            IconType.OXIDIZER: (0, 128, 255),
            IconType.RADIATION: (128, 0, 255),
        }
        label_map = {
            IconType.ELECTRIC_SHOCK: "ELECTRIC_SHOCK",
            IconType.OXIDIZER: "OXIDIZER",
            IconType.RADIATION: "RADIATION",
        }

        for result in results:
            x, y, bw, bh = result.bounding_box
            color = color_map.get(result.icon_type, (255, 255, 255))
            label = label_map.get(result.icon_type, "?")

            cv2.rectangle(debug, (x, y), (x + bw, y + bh), color, 2)
            text = f"{label} {result.confidence:.0%}"
            (tw, th), baseline = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)
            cv2.rectangle(debug, (x, y - th - 8), (x + tw + 4, y), color, -1)
            cv2.putText(debug, text, (x + 2, y - 4), cv2.FONT_HERSHEY_SIMPLEX,
                        0.55, (0, 0, 0), 2, cv2.LINE_AA)

        if show_mask:
            yellow_mask = self._get_yellow_mask(frame)
            orange_mask = self._get_orange_mask(frame)
            combined = cv2.bitwise_or(yellow_mask, orange_mask)
            mask_color = cv2.cvtColor(combined, cv2.COLOR_GRAY2BGR)
            debug = np.hstack([debug, mask_color])

        return debug
