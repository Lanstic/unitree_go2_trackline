# Go2 图标识别与动作系统

使用宇树 Go2 机器狗的前置摄像头实时识别警示标志，识别后执行动作。

## 支持的标志与动作

| 标志 | 执行动作 |
|------|---------|
| 当心触电 | Stretch() |
| 当心强氧化物 | Hello() |
| 当心辐射 | 前灯闪烁 3 次 |

## 运行

```bash
# RealSense D435i 摄像头
python3 go2_icon_recognition.py --camera realsense --no-display

# 仅测试检测算法
python3 go2_icon_recognition.py --test ./icons/reference_icons.png --no-display
```
