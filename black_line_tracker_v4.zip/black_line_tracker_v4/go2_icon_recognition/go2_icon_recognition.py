#!/usr/bin/env python3
"""
Go2 图标识别 - 主程序
使用 Go2 机器狗的前置摄像头实时识别警示标志,
识别到对应标志后执行相应动作。

支持的标志与动作:
  当心触电    (闪电) → 伸展动作 (Stretch)
  当心强氧化物 (火焰) → 挥手问候 (Hello)
  当心辐射    (三叶) → 前灯闪烁 3 次

使用方法:
  python3 go2_icon_recognition.py [机器人IP]

  # 从 RealSense D435i 摄像头读取 (推荐)
  python3 go2_icon_recognition.py --camera realsense

  # 从本地图片测试
  python3 go2_icon_recognition.py --test ./test_image.jpg

  # 禁用机器人连接 (仅测试检测算法)
  python3 go2_icon_recognition.py --no-robot

  # 禁用动作执行 (仅查看检测结果)
  python3 go2_icon_recognition.py --detect-only
"""

import os
import sys
import time
import argparse
import threading
import cv2
import numpy as np

# 添加本模块路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from icon_detector import WarningTriangleDetector, IconType, DetectionResult
from action_controller import Go2ActionController


class IconRecognitionSystem:
    """
    图标识别系统主类
    协调摄像头输入、检测引擎和动作控制器
    """

    # 确认阈值: 连续 N 帧检测到同一图标才触发动作
    CONFIRM_FRAMES = 3

    # 检测置信度阈值
    CONFIDENCE_THRESHOLD = 0.30

    def __init__(self, args):
        self.args = args
        self.detector = WarningTriangleDetector()
        self.controller = Go2ActionController(
            robot_ip=args.ip,
            use_sdk=not args.detect_only
        )

        self.running = False
        self.frame_count = 0
        self.fps = 0.0
        self.fps_start_time = time.time()
        self.fps_frame_count = 0

        # 连续帧计数器
        self._confirm_counter: dict[IconType, int] = {
            IconType.ELECTRIC_SHOCK: 0,
            IconType.OXIDIZER: 0,
            IconType.RADIATION: 0,
        }
        self._last_confirmed_type = IconType.NONE

        # 摄像头
        self._camera_source = None
        self._video_client = None  # Go2 内置摄像头客户端
        self._realsense_pipeline = None  # RealSense

    def initialize(self) -> bool:
        """初始化系统"""
        print("=" * 55)
        print("  Go2 图标识别系统")
        print("=" * 55)

        # 初始化动作控制器
        if not self.controller.initialize():
            print("[System] 警告: 动作控制器初始化失败")
            if self.args.detect_only:
                print("[System] 由于 --detect-only, 将继续运行")
            else:
                print("[System] 请检查机器人连接或使用 --detect-only")

        # 初始化摄像头
        return self._init_camera()

    def _init_camera(self) -> bool:
        """根据参数初始化摄像头"""
        camera_type = self.args.camera.lower()

        if camera_type == "realsense":
            return self._init_realsense()
        elif camera_type == "go2":
            return self._init_go2_camera()
        elif camera_type == "webcam":
            return self._init_webcam()
        else:
            print(f"[Camera] 未知摄像头类型: {camera_type}")
            print("[Camera] 可用类型: realsense, go2, webcam")
            return False

    def _init_realsense(self) -> bool:
        """初始化 RealSense D435i 摄像头"""
        try:
            import pyrealsense2 as rs
            self._rs = rs
            self._realsense_pipeline = rs.pipeline()

            config = rs.config()
            config.enable_stream(
                rs.stream.color,
                640, 480, rs.format.bgr8, 30
            )

            profile = self._realsense_pipeline.start(config)
            dev = profile.get_device()
            print(f"[Camera] RealSense D435i: {dev.get_info(rs.camera_info.name)}")
            print(f"[Camera] SN: {dev.get_info(rs.camera_info.serial_number)}")
            self._align = rs.align(rs.stream.color)
            return True

        except ImportError:
            print("[Camera] 错误: 未安装 pyrealsense2")
            print("[Camera] 请运行: pip install pyrealsense2")
            return False
        except Exception as e:
            print(f"[Camera] RealSense 初始化失败: {e}")
            return False

    def _init_go2_camera(self) -> bool:
        """初始化 Go2 内置前置摄像头"""
        try:
            from unitree_sdk2py.core.channel import ChannelFactoryInitialize
            from unitree_sdk2py.go2.video.video_client import VideoClient

            if self.args.ip:
                ChannelFactoryInitialize(0, self.args.ip)
            else:
                ChannelFactoryInitialize(0)

            self._video_client = VideoClient()
            self._video_client.SetTimeout(3.0)
            self._video_client.Init()
            print("[Camera] Go2 内置摄像头客户端初始化成功")
            return True

        except ImportError:
            print("[Camera] 错误: 无法导入 unitree_sdk2py")
            return False
        except Exception as e:
            print(f"[Camera] Go2 摄像头初始化失败: {e}")
            return False

    def _init_webcam(self) -> bool:
        """初始化本地 webcam"""
        try:
            self._camera_source = cv2.VideoCapture(0)
            if not self._camera_source.isOpened():
                print("[Camera] 无法打开 webcam")
                return False
            print("[Camera] Webcam 初始化成功")
            return True
        except Exception as e:
            print(f"[Camera] Webcam 初始化失败: {e}")
            return False

    def _grab_frame(self) -> np.ndarray:
        """从当前摄像头获取一帧"""
        if self._realsense_pipeline:
            try:
                frames = self._realsense_pipeline.wait_for_frames(timeout_ms=5000)
                aligned = self._align.process(frames)
                color_frame = aligned.get_color_frame()
                if color_frame:
                    return np.asanyarray(color_frame.get_data())
            except Exception:
                pass

        elif self._video_client:
            try:
                code, data = self._video_client.GetImageSample()
                if code == 0 and data:
                    image_data = np.frombuffer(bytes(data), dtype=np.uint8)
                    return cv2.imdecode(image_data, cv2.IMREAD_COLOR)
            except Exception:
                pass

        elif self._camera_source:
            ret, frame = self._camera_source.read()
            if ret:
                return frame

        return None

    def run(self):
        """主运行循环"""
        self.running = True
        print("\n[System] 开始识别 (按 Q 退出)")
        print("-" * 55)

        try:
            while self.running:
                frame = self._grab_frame()
                if frame is None:
                    time.sleep(0.1)
                    continue

                self.frame_count += 1
                self._update_fps()

                # 检测图标
                results = self.detector.detect(frame)

                # 处理检测结果
                self._process_results(results)

                # 生成并显示调试画面
                if not self.args.no_display:
                    debug_frame = self._generate_debug_frame(frame, results)
                    cv2.imshow("Go2 Icon Recognition", debug_frame)

                    key = cv2.waitKey(30)
                    if key & 0xFF in (ord('q'), ord('Q'), 27):
                        break

        except KeyboardInterrupt:
            pass
        finally:
            self.shutdown()

    def _update_fps(self):
        """更新帧率统计"""
        self.fps_frame_count += 1
        elapsed = time.time() - self.fps_start_time
        if elapsed >= 1.0:
            self.fps = self.fps_frame_count / elapsed
            self.fps_frame_count = 0
            self.fps_start_time = time.time()

    def _process_results(self, results: list):
        """处理检测结果, 确认后触发动作"""
        # 图标消失时重置所有计数器，允许重新触发
        if not results:
            for icon_type in self._confirm_counter:
                self._confirm_counter[icon_type] = 0
            self._last_confirmed_type = IconType.NONE
            return

        confirmed_type = IconType.NONE

        for result in results:
            if result.confidence < self.CONFIDENCE_THRESHOLD:
                continue

            icon_type = result.icon_type
            self._confirm_counter[icon_type] += 1

            if self._confirm_counter[icon_type] >= self.CONFIRM_FRAMES:
                confirmed_type = icon_type

        if confirmed_type != IconType.NONE and confirmed_type != self._last_confirmed_type:
            self._last_confirmed_type = confirmed_type
            print(f"\n[Detect] ✓ 确认识别: {confirmed_type.value} "
                  f"(置信度: {result.confidence:.0%})")
            self.controller.execute_action(confirmed_type)

    def _generate_debug_frame(self, frame: np.ndarray,
                               results: list) -> np.ndarray:
        """生成调试画面"""
        h, w = frame.shape[:2]
        debug = self.detector.get_debug_visualization(frame, results)

        # 叠加信息面板
        info_h = 80
        info_panel = np.ones((info_h, w, 3), dtype=np.uint8) * 25
        info_y = h

        # FPS
        cv2.putText(info_panel, f"FPS: {self.fps:.1f}", (10, 28),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

        # 连续帧计数
        offset_x = 200
        icons_status = [
            (IconType.ELECTRIC_SHOCK, "⚡触电", (0, 255, 255)),
            (IconType.OXIDIZER, "🔥氧化物", (0, 128, 255)),
            (IconType.RADIATION, "☢️辐射", (128, 0, 255)),
        ]

        for i, (itype, label, color) in enumerate(icons_status):
            x = offset_x + i * 180
            count = self._confirm_counter[itype]
            status = f"{label}: {count}/{self.CONFIRM_FRAMES}"

            panel_color = color if count > 0 else (80, 80, 80)
            cv2.putText(info_panel, status, (x, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, panel_color, 2)

            # 进度条
            bar_x, bar_y = x, 45
            cv2.rectangle(info_panel, (bar_x, bar_y),
                          (bar_x + 120, bar_y + 12), (60, 60, 60), -1)
            filled = int(120 * min(count, self.CONFIRM_FRAMES) / self.CONFIRM_FRAMES)
            cv2.rectangle(info_panel, (bar_x, bar_y),
                          (bar_x + filled, bar_y + 12), panel_color, -1)

        # 最后动作时间
        state = self.controller.get_robot_state()
        t = state["time_since_last_action"]
        last_info = f"上次动作: {t:.1f}s 前" if t >= 0 else "上次动作: 无"
        cv2.putText(info_panel, last_info, (w - 220, 28),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (150, 150, 150), 1)

        # 合并
        result_frame = np.vstack([debug, info_panel])

        # 检测计数
        detected = self._confirm_counter.get(self._last_confirmed_type, 0)
        if self._last_confirmed_type != IconType.NONE and detected > 0:
            name_map = {
                IconType.ELECTRIC_SHOCK: "当心触电 - Stretch",
                IconType.OXIDIZER: "当心强氧化物 - Hello",
                IconType.RADIATION: "当心辐射 - 闪灯",
            }
            name = name_map.get(self._last_confirmed_type, "")
            cv2.putText(result_frame, f">>> {name} <<<",
                        (w // 2 - 120, h + 65),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 0), 2)

        return result_frame

    def shutdown(self):
        """关闭系统"""
        self.running = False
        print("\n[System] 正在关闭...")

        if self._realsense_pipeline:
            self._realsense_pipeline.stop()
            print("[Camera] RealSense 已关闭")

        if self._camera_source:
            self._camera_source.release()

        self.controller.shutdown()
        cv2.destroyAllWindows()
        print("[System] 退出完成")


def main():
    parser = argparse.ArgumentParser(
        description="Go2 图标识别与动作系统",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 从 RealSense 摄像头运行 (推荐)
  python3 go2_icon_recognition.py --camera realsense

  # 从 Go2 内置摄像头运行
  python3 go2_icon_recognition.py --camera go2 --ip 192.168.123.161

  # 从本地 webcam 测试
  python3 go2_icon_recognition.py --camera webcam

  # 仅检测模式 (不连接机器人)
  python3 go2_icon_recognition.py --camera realsense --detect-only

  # 从图片文件测试检测算法
  python3 go2_icon_recognition.py --test ./test_image.jpg
        """
    )

    parser.add_argument('ip', nargs='?', default='',
                        help='机器人 IP 地址 (可选)')
    parser.add_argument('--camera', '--cam', dest='camera', default='realsense',
                        choices=['realsense', 'go2', 'webcam'],
                        help='摄像头数据源 (默认: realsense)')
    parser.add_argument('--test', '--test-image', dest='test_image', default='',
                        help='从图片文件测试检测 (同时禁用机器人连接)')
    parser.add_argument('--detect-only', action='store_true',
                        help='仅检测模式, 不执行动作')
    parser.add_argument('--no-robot', action='store_true',
                        help='禁用机器人连接 (等效于 --detect-only)')
    parser.add_argument('--no-display', action='store_true',
                        help='禁用显示窗口')
    parser.add_argument('--confirm-frames', type=int, default=3,
                        help=f'触发动作的确认帧数 (默认: 3)')
    parser.add_argument('--confidence', type=float, default=0.30,
                        help=f'检测置信度阈值 (默认: 0.30)')

    args = parser.parse_args()

    # 兼容旧参数
    if args.no_robot:
        args.detect_only = True

    # 设置置信度和确认帧
    IconRecognitionSystem.CONFIRM_FRAMES = args.confirm_frames
    IconRecognitionSystem.CONFIDENCE_THRESHOLD = args.confidence

    if args.test_image:
        run_image_test(args)
        return

    system = IconRecognitionSystem(args)
    if not system.initialize():
        print("[System] 初始化失败, 退出")
        sys.exit(1)

    system.run()


def run_image_test(args):
    """从图片文件测试检测算法"""
    if not os.path.isfile(args.test_image):
        print(f"[Test] 文件不存在: {args.test_image}")
        sys.exit(1)

    print(f"[Test] 正在测试图片: {args.test_image}")
    frame = cv2.imread(args.test_image)
    if frame is None:
        print(f"[Test] 无法读取图片")
        sys.exit(1)

    detector = WarningTriangleDetector()
    results = detector.detect(frame)

    debug = detector.get_debug_visualization(frame, results)

    print(f"[Test] 检测到 {len(results)} 个图标:")
    for r in results:
        print(f"  - {r.icon_type.value}: 置信度={r.confidence:.0%}")

    # 等比例缩放显示 (最大宽度 960)
    h, w = debug.shape[:2]
    if w > 960:
        scale = 960 / w
        new_w, new_h = 960, int(h * scale)
        debug = cv2.resize(debug, (new_w, new_h))

    # 无头环境跳过 cv2.imshow
    if args.no_display:
        print("[Test] 显示已禁用 (--no-display), 调试图片未展示")
    else:
        try:
            cv2.imshow("Test Result", debug)
            print("[Test] 按任意键退出...")
            cv2.waitKey(0)
            cv2.destroyAllWindows()
        except Exception:
            print("[Test] 无法显示窗口 (无头环境), 请使用 --no-display")


if __name__ == '__main__':
    main()
