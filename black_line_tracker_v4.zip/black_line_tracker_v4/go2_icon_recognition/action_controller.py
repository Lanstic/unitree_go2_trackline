"""
Go2 图标识别 - 动作控制器 (ROS2 直连版)
通过 ROS2 /api/sport/request 和 /api/vui/request 控制机器狗,
避免 unitree_sdk2py CycloneDDS Python 绑定的 segfault 问题。
"""

import os
import time
import threading
import json

# ROS2 运动控制（与 trackline.py 相同方式）
ROS2_AVAILABLE = False
try:
    os.environ['RMW_IMPLEMENTATION'] = 'rmw_cyclonedds_cpp'
    import rclpy
    from rclpy.node import Node
    from unitree_api.msg import Request as ApiRequest
    ROS2_AVAILABLE = True
except ImportError as e:
    rclpy = None
    Node = None
    ApiRequest = None


# ==================== API IDs ====================
SPORT_API_ID_DAMP = 1001
SPORT_API_ID_BALANCESTAND = 1002
SPORT_API_ID_STOPMOVE = 1003
SPORT_API_ID_STANDUP = 1004
SPORT_API_ID_STANDDOWN = 1005
SPORT_API_ID_HELLO = 1016
SPORT_API_ID_STRETCH = 1017

VUI_API_ID_SETBRIGHTNESS = 1005
VUI_API_ID_GETBRIGHTNESS = 1006


class _ROS2Client(Node if ROS2_AVAILABLE else object):
    """ROS2 节点, 同时管理 sport 和 vui 两个服务的发布器"""

    def __init__(self):
        if not ROS2_AVAILABLE:
            return
        super().__init__('icon_recognition_control')
        self._sport_pub = self.create_publisher(
            ApiRequest, '/api/sport/request', 10)
        self._vui_pub = self.create_publisher(
            ApiRequest, '/api/vui/request', 10)
        # 验证通信: 发一条无副作用的 StopMove
        self._send_sport(SPORT_API_ID_STOPMOVE)
        time.sleep(0.05)

    def _send_sport(self, api_id: int, params: dict = None):
        if not ROS2_AVAILABLE or not self._sport_pub:
            return
        req = ApiRequest()
        req.header.identity.api_id = api_id
        req.header.identity.id = 0
        req.header.lease.id = 0
        req.header.policy.priority = 0
        req.parameter = json.dumps(params) if params else '{}'
        self._sport_pub.publish(req)

    def _send_vui(self, api_id: int, params: dict = None):
        if not ROS2_AVAILABLE or not self._vui_pub:
            return
        req = ApiRequest()
        req.header.identity.api_id = api_id
        req.header.identity.id = 0
        req.header.lease.id = 0
        req.header.policy.priority = 0
        req.parameter = json.dumps(params) if params else '{}'
        self._vui_pub.publish(req)

    def stretch(self):
        self._send_sport(SPORT_API_ID_STRETCH)

    def hello(self):
        self._send_sport(SPORT_API_ID_HELLO)

    def set_brightness(self, level: int):
        # level 范围 0-10，对应头部 LED 亮度
        self._send_vui(VUI_API_ID_SETBRIGHTNESS, {"brightness": level})

    def flash_lights(self, times: int = 3):
        """闪烁头部 LED，循环: 亮->暗->亮"""
        for i in range(times):
            self.set_brightness(10)
            time.sleep(0.3)
            self.set_brightness(0)
            time.sleep(0.3)
            time.sleep(0.3)  # 灭态持续
        self.set_brightness(5)  # 恢复到中等亮度


from icon_detector import IconType


class Go2ActionController:
    COOLDOWN_SECONDS = 2.0

    def __init__(self, robot_ip: str = "", use_sdk: bool = True):
        self.robot_ip = robot_ip
        self.use_sdk = use_sdk
        self._ros2_client = None
        self._last_action_time = 0.0
        self._action_lock = threading.Lock()
        self._initialized = False
        self._light_thread = None
        self._light_stop_flag = False

    def initialize(self) -> bool:
        if not self.use_sdk:
            print("[Action] SDK 模式禁用, 仅输出日志")
            self._initialized = True
            return True

        if not ROS2_AVAILABLE:
            print("[Action] ROS2 不可用, 切换到仅日志模式")
            self.use_sdk = False
            self._initialized = True
            return False

        try:
            if not rclpy.ok():
                rclpy.init()
            self._ros2_client = _ROS2Client()
            self._initialized = True
            print("[Action] ROS2 运动控制就绪")
            return True
        except Exception as e:
            print(f"[Action] ROS2 初始化失败: {e}, 切换到仅日志模式")
            self.use_sdk = False
            self._initialized = True
            return False

    def execute_action(self, icon_type: IconType) -> bool:
        if icon_type == IconType.NONE:
            return False

        current_time = time.time()
        if current_time - self._last_action_time < self.COOLDOWN_SECONDS:
            return False

        with self._action_lock:
            self._last_action_time = current_time

        action_map = {
            IconType.ELECTRIC_SHOCK: self._action_electric_shock,
            IconType.OXIDIZER: self._action_oxidizer,
            IconType.RADIATION: self._action_radiation,
        }

        action_fn = action_map.get(icon_type)
        if action_fn:
            t = threading.Thread(target=action_fn, daemon=True)
            t.start()
            return True
        return False

    def _action_electric_shock(self):
        print("[Action] ELECTRIC_SHOCK -> Stretch")
        if self.use_sdk and self._ros2_client:
            try:
                self._ros2_client.stretch()
                print("[Action]   Stretch 已发送")
            except Exception as e:
                print(f"[Action]   Error: {e}")

    def _action_oxidizer(self):
        print("[Action] OXIDIZER -> Hello")
        if self.use_sdk and self._ros2_client:
            try:
                self._ros2_client.hello()
                print("[Action]   Hello 已发送")
            except Exception as e:
                print(f"[Action]   Error: {e}")

    def _action_radiation(self):
        print("[Action] RADIATION -> Flash Lights")
        if self._light_thread and self._light_thread.is_alive():
            self._light_stop_flag = True
            self._light_thread.join(timeout=1.0)
        self._light_stop_flag = False
        self._light_thread = threading.Thread(
            target=self._flash_lights, args=(3,), daemon=True)
        self._light_thread.start()

    def _flash_lights(self, times: int = 3):
        if not (self.use_sdk and self._ros2_client):
            return
        try:
            for i in range(times):
                if self._light_stop_flag:
                    break
                self._ros2_client.set_brightness(10)
                time.sleep(0.3)
                if self._light_stop_flag:
                    break
                self._ros2_client.set_brightness(0)
                time.sleep(0.3)
                self._ros2_client.set_brightness(5)
                time.sleep(0.3)
                print(f"[Action]   Flash {i + 1}/{times}")
        except Exception as e:
            print(f"[Action]   Flash error: {e}")

    def get_robot_state(self) -> dict:
        t = time.time() - self._last_action_time if self._last_action_time > 0 else -1
        return {"initialized": self._initialized, "use_sdk": self.use_sdk,
                "time_since_last_action": t}

    def shutdown(self):
        self._light_stop_flag = True
        if ROS2_AVAILABLE and rclpy and rclpy.ok() and self._ros2_client:
            self._ros2_client.destroy_node()
            rclpy.shutdown()
        print("[Action] 控制器已关闭")
