"""
Go2 黑线巡线 ROS2 Launch 文件
==============================
用法:
  ros2 launch unitree_trackline trackline.launch.py
  ros2 launch unitree_trackline trackline.launch.py speed:=0.3 kp:=0.008
  ros2 launch unitree_trackline trackline.launch.py enable_motion:=false
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    """生成 launch 描述"""

    # --- 声明启动参数 ---
    speed_arg = DeclareLaunchArgument(
        'speed', default_value='0.3',
        description='前进线速度 (m/s)',
    )
    kp_arg = DeclareLaunchArgument(
        'kp', default_value='0.005',
        description='P 控制器比例系数',
    )
    ki_arg = DeclareLaunchArgument(
        'ki', default_value='0.0001',
        description='I 控制器积分系数',
    )
    max_angular_arg = DeclareLaunchArgument(
        'max_angular', default_value='0.5',
        description='最大角速度 (rad/s)',
    )
    lost_threshold_arg = DeclareLaunchArgument(
        'lost_threshold', default_value='30',
        description='丢线停止阈值 (帧数)',
    )
    gray_threshold_arg = DeclareLaunchArgument(
        'gray_threshold', default_value='80',
        description='黑线灰度阈值 (0-255)',
    )
    http_port_arg = DeclareLaunchArgument(
        'http_port', default_value='8081',
        description='HTTP 调试端口',
    )
    enable_http_arg = DeclareLaunchArgument(
        'enable_http', default_value='true',
        description='是否启用 HTTP 调试服务器',
    )
    enable_motion_arg = DeclareLaunchArgument(
        'enable_motion', default_value='true',
        description='是否启用运动控制',
    )

    # --- 巡线节点 ---
    trackline_node = Node(
        package='unitree_trackline',
        executable='trackline_node',
        name='trackline_node',
        output='screen',
        parameters=[{
            'speed': LaunchConfiguration('speed'),
            'kp': LaunchConfiguration('kp'),
            'ki': LaunchConfiguration('ki'),
            'max_angular': LaunchConfiguration('max_angular'),
            'lost_threshold': LaunchConfiguration('lost_threshold'),
            'gray_threshold': LaunchConfiguration('gray_threshold'),
            'http_port': LaunchConfiguration('http_port'),
            'enable_http': LaunchConfiguration('enable_http'),
            'enable_motion': LaunchConfiguration('enable_motion'),
        }],
        # 如果需要在启动时自动 respawn
        # respawn=True,
        # respawn_delay=2.0,
    )

    return LaunchDescription([
        speed_arg,
        kp_arg,
        ki_arg,
        max_angular_arg,
        lost_threshold_arg,
        gray_threshold_arg,
        http_port_arg,
        enable_http_arg,
        enable_motion_arg,
        trackline_node,
    ])
