from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'unitree_trackline'

setup(
    name=package_name,
    version='1.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'),
         glob('launch/*.launch.py')),
        (os.path.join('share', package_name, 'config'),
         glob('config/*.yaml')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Trackline Developer',
    maintainer_email='user@example.com',
    description='Go2 black line following using RealSense D435i and ROS2 native control',
    license='BSD 3-Clause License',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'trackline_node = unitree_trackline.trackline_node:main',
        ],
    },
)
