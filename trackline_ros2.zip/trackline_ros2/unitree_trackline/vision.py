#!/usr/bin/env python3
"""
黑线视觉检测模块
=================
从 RealSense D435i 彩色图像中检测黑线中心线。
支持曲线拟合、偏移量计算和调试可视化。

可独立使用，也可作为 ROS2 节点组件。
"""

import cv2
import numpy as np
from typing import Tuple, List, Optional


class BlackLineDetector:
    """
    黑线检测器

    参数:
        threshold:  灰度二值化阈值 (0-255), 默认 80
        scan_lines: 扫描线数量, 默认 20
        min_width:  最小线宽 (像素), 默认 8
        poly_degree: 多项式拟合阶数, 默认 3
    """

    def __init__(
        self,
        threshold: int = 80,
        scan_lines: int = 20,
        min_width: int = 8,
        poly_degree: int = 3,
    ):
        self.threshold = threshold
        self.scan_lines = scan_lines
        self.min_width = min_width
        self.poly_degree = poly_degree

        # 形态学核
        self._kernel_close = np.ones((3, 3), np.uint8)
        self._kernel_open = np.ones((3, 3), np.uint8)

    def detect(
        self, frame: np.ndarray, draw_debug: bool = True
    ) -> Tuple[np.ndarray, float, int, List[Tuple[int, int]]]:
        """
        检测黑线中心

        参数:
            frame:      BGR 彩色图像 (H, W, 3)
            draw_debug: 是否在结果上绘制调试信息

        返回:
            result:          标注后的图像 (或原图)
            offset:          底部偏移量 (像素), 正值=偏右, 负值=偏左
            points_count:    检测到的有效点数
            detected_points: 检测点列表 [(x, y), ...]
        """
        result = frame.copy() if draw_debug else frame
        height, width = frame.shape[:2]

        # --- 预处理 ---
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        _, binary = cv2.threshold(blurred, self.threshold, 255, cv2.THRESH_BINARY_INV)

        # 形态学去噪
        morphed = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, self._kernel_close, iterations=2)
        morphed = cv2.morphologyEx(morphed, cv2.MORPH_OPEN, self._kernel_open, iterations=1)

        # --- 扫描线检测 ---
        top_y = height // 4
        bottom_y = height - 20
        step_y = max(1, (bottom_y - top_y) // self.scan_lines)
        detected_points = []

        for scan_y in range(bottom_y, top_y, -step_y):
            row = morphed[scan_y, :]
            in_line = False
            start_x = 0

            for x in range(width):
                if row[x] > 0 and not in_line:
                    start_x = x
                    in_line = True
                elif row[x] == 0 and in_line:
                    line_w = x - start_x
                    if line_w >= self.min_width:
                        cx = (start_x + x) // 2
                        detected_points.append((cx, scan_y))
                        if draw_debug:
                            cv2.circle(result, (cx, scan_y), 3, (0, 255, 0), -1)
                    in_line = False

            # 处理行末未闭合段
            if in_line:
                line_w = width - start_x
                if line_w >= self.min_width:
                    cx = (start_x + width) // 2
                    detected_points.append((cx, scan_y))
                    if draw_debug:
                        cv2.circle(result, (cx, scan_y), 3, (0, 255, 0), -1)

        # --- 曲线拟合 ---
        offset = 0.0
        if len(detected_points) >= 5 and draw_debug:
            self._draw_fitted_curve(result, detected_points, height, width)

        if len(detected_points) >= 5:
            offset = self._compute_offset(detected_points, height, width)
            if draw_debug:
                self._draw_centerline(result, height, width, offset)

        # --- 调试绘制 ---
        if draw_debug:
            # 扫描线
            for scan_y in range(bottom_y, top_y, -step_y):
                cv2.line(result, (0, scan_y), (width, scan_y), (100, 100, 100), 1)

        return result, offset, len(detected_points), detected_points

    def _compute_offset(
        self, points: List[Tuple[int, int]], height: int, width: int
    ) -> float:
        """计算底部偏移量"""
        pts = np.array(points)
        try:
            z = np.polyfit(pts[:, 1], pts[:, 0], self.poly_degree)
            p = np.poly1d(z)
            bottom_y = height - 40
            bottom_x = np.clip(int(p(bottom_y)), 0, width - 1)
            return float(bottom_x - width // 2)
        except Exception:
            return 0.0

    def _draw_fitted_curve(
        self, result: np.ndarray, points: List[Tuple[int, int]],
        height: int, width: int
    ):
        """绘制拟合曲线"""
        pts = np.array(points)
        try:
            z = np.polyfit(pts[:, 1], pts[:, 0], self.poly_degree)
            p = np.poly1d(z)

            y_vals = np.linspace(pts[-1, 1], pts[0, 1], 50)
            x_vals = np.clip(p(y_vals).astype(np.int32), 0, width - 1)

            for i in range(len(y_vals) - 1):
                pt1 = (x_vals[i], int(y_vals[i]))
                pt2 = (x_vals[i + 1], int(y_vals[i + 1]))
                cv2.line(result, pt1, pt2, (0, 255, 0), 2)
        except Exception:
            pass

    def _draw_centerline(
        self, result: np.ndarray, height: int, width: int, offset: float
    ):
        """绘制图像中心线和偏移指示"""
        cx = width // 2
        cv2.line(result, (cx, height), (cx, 0), (255, 0, 0), 1)

        # 底部偏移指示圆
        bottom_y = height - 40
        bottom_x = cx + int(offset)
        cv2.circle(result, (bottom_x, bottom_y), 5, (0, 0, 255), -1)

    def set_threshold(self, value: int):
        """动态调整阈值"""
        self.threshold = max(10, min(250, value))


# ==================== 独立测试 ====================
if __name__ == "__main__":
    import sys
    import time

    try:
        import pyrealsense2 as rs
    except ImportError:
        print("需要 pyrealsense2 库. 安装: pip install pyrealsense2")
        sys.exit(1)

    # 测试相机
    pipeline = rs.pipeline()
    config = rs.config()
    config.enable_stream(rs.stream.color, 640, 480, rs.format.bgr8, 30)
    pipeline.start(config)

    detector = BlackLineDetector(threshold=80)

    print("黑线检测测试 | q=退出, s=保存, +/-=调阈值")
    try:
        while True:
            frames = pipeline.wait_for_frames(5000)
            color = np.asanyarray(frames.get_color_frame().get_data())

            result, offset, count, _ = detector.detect(color)

            cv2.putText(result, f"Th:{detector.threshold} | Pts:{count} | Off:{offset:.0f}",
                        (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 2)

            cv2.imshow("BlackLineDetector Test", result)
            key = cv2.waitKey(1) & 0xFF

            if key == ord('q'):
                break
            elif key == ord('s'):
                cv2.imwrite(f"detect_{time.strftime('%H%M%S')}.jpg", result)
                print("截图已保存")
            elif key == ord('+') or key == ord('='):
                detector.set_threshold(detector.threshold + 5)
                print(f"阈值: {detector.threshold}")
            elif key == ord('-'):
                detector.set_threshold(detector.threshold - 5)
                print(f"阈值: {detector.threshold}")
    finally:
        pipeline.stop()
        cv2.destroyAllWindows()
