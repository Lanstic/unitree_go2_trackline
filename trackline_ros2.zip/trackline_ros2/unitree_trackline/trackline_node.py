#!/usr/bin/env python3
"""
Go2 黑线巡线 ROS2 节点
========================
基于 ROS2 原生通信的 Go2 黑线巡线节点。

架构:
  RealSense D435i ──> vision.py (黑线检测) ──> PI 控制器 ──> sport_client.py (ROS2 运动指令)
                                                                    │
                                                              CycloneDDS ──> Go2 机器人

功能:
  - RealSense D435i 实时黑线检测与曲线拟合
  - PI 控制器 (比例 + 积分) 平mooth 巡线
  - ROS2 原生 SportClient 运动控制 (无需 SDK2)
  - 丢线自动减速/停止
  - HTTP 浏览器调试画面
  - 实时参数动态调整 (ROS2 parameters)

用法:
  ros2 run unitree_trackline trackline_node
  ros2 run unitree_trackline trackline_node --ros-args -p speed:=0.3 -p kp:=0.008
"""

import sys
import time
import threading
from collections import deque

import cv2
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.executors import MultiThreadedExecutor
from rclpy.callback_groups import ReentrantCallbackGroup

# 尝试导入 RealSense
try:
    import pyrealsense2 as rs
    HAS_REALSENSE = True
except ImportError:
    HAS_REALSENSE = False
    print('[警告] pyrealsense2 未安装，将使用模拟相机')

from unitree_trackline.vision import BlackLineDetector
from unitree_trackline.sport_client import SportClient
from unitree_trackline.debug_server import DebugHTTPServer


class TracklineNode(Node):
    """
    Go2 黑线巡线 ROS2 节点

    ROS2 Parameters (可通过命令行或 YAML 配置):
        speed:              前进线速度 m/s (默认 0.3)
        kp:                 P 系数 (默认 0.005)
        ki:                 I 系数 (默认 0.0001)
        max_angular:        最大角速度 rad/s (默认 0.5)
        lost_threshold:     丢线多少帧后减速 (默认 30)
        detect_threshold:   最少检测点数 (默认 2)
        gray_threshold:     黑线灰度阈值 (默认 80)
        http_port:          HTTP 调试端口 (默认 8081)
        enable_http:        是否启用 HTTP 调试 (默认 true)
        enable_motion:      是否启用运动控制 (默认 true)
        low_speed_ratio:    减速模式比例 (默认 0.5)
        scan_lines:         扫描线数 (默认 20)
        min_width:          最小线宽 (默认 8)
    """

    def __init__(self):
        super().__init__('trackline_node')

        # --- 声明 ROS2 参数 ---
        self.declare_parameters(
            namespace='',
            parameters=[
                ('speed', 0.3),
                ('kp', 0.005),
                ('ki', 0.0001),
                ('max_angular', 0.5),
                ('lost_threshold', 30),
                ('detect_threshold', 2),
                ('gray_threshold', 80),
                ('http_port', 8081),
                ('enable_http', True),
                ('enable_motion', True),
                ('low_speed_ratio', 0.5),
                ('scan_lines', 20),
                ('min_width', 8),
            ],
        )

        # 读取参数
        self.speed = self.get_parameter('speed').value
        self.kp = self.get_parameter('kp').value
        self.ki = self.get_parameter('ki').value
        self.max_angular = self.get_parameter('max_angular').value
        self.lost_threshold = self.get_parameter('lost_threshold').value
        self.detect_threshold = self.get_parameter('detect_threshold').value
        self.gray_threshold = self.get_parameter('gray_threshold').value
        self.http_port = self.get_parameter('http_port').value
        self.enable_http = self.get_parameter('enable_http').value
        self.enable_motion = self.get_parameter('enable_motion').value
        self.low_speed_ratio = self.get_parameter('low_speed_ratio').value
        self.scan_lines = self.get_parameter('scan_lines').value
        self.min_width = self.get_parameter('min_width').value

        # 参数变化回调
        self.add_on_set_parameters_callback(self._param_callback)

        # --- 初始化组件 ---
        # 黑线检测器
        self.detector = BlackLineDetector(
            threshold=self.gray_threshold,
            scan_lines=self.scan_lines,
            min_width=self.min_width,
        )

        # 运动客户端 (ROS2 原生)
        self.sport_client = SportClient(self) if self.enable_motion else None

        # HTTP 调试服务器
        self.http_server: Optional[DebugHTTPServer] = None
        if self.enable_http:
            self.http_server = DebugHTTPServer(port=self.http_port)
            self.http_server.set_cmd_callback(self._http_cmd_callback)
            self.http_server.start()

        # --- 状态变量 ---
        self.lost_counter = 0
        self.line_was_detected = False
        self.integral_error = 0.0
        self.error_history = deque(maxlen=5)
        self.last_angular = 0.0
        self.frame_count = 0
        self.start_time = time.time()
        self._running = True

        # --- 初始化相机 ---
        self.pipeline = None
        self._init_camera()

        # --- 定时器 (相机帧处理) ---
        self.camera_timer = self.create_timer(
            1.0 / 30.0,  # 30 Hz
            self._process_frame,
            callback_group=ReentrantCallbackGroup(),
        )

        self.get_logger().info('TracklineNode 初始化完成')
        self._print_status()

    def _param_callback(self, params):
        """ROS2 参数动态更新回调"""
        for param in params:
            if param.name == 'speed':
                self.speed = param.value
            elif param.name == 'kp':
                self.kp = param.value
            elif param.name == 'ki':
                self.ki = param.value
            elif param.name == 'max_angular':
                self.max_angular = param.value
            elif param.name == 'lost_threshold':
                self.lost_threshold = param.value
            elif param.name == 'gray_threshold':
                self.gray_threshold = param.value
                self.detector.set_threshold(param.value)
            elif param.name == 'scan_lines':
                self.detector.scan_lines = param.value
            elif param.name == 'min_width':
                self.detector.min_width = param.value
        return rclpy.parameter.SetParametersResult(successful=True)

    def _init_camera(self):
        """初始化 RealSense D435i 相机"""
        if not HAS_REALSENSE:
            self.get_logger().error('pyrealsense2 未安装，无法初始化相机！')
            self.get_logger().error('安装: pip install pyrealsense2')
            sys.exit(1)

        try:
            self.pipeline = rs.pipeline()
            config = rs.config()

            ctx = rs.context()
            devices = ctx.query_devices()
            if len(devices) == 0:
                self.get_logger().error('未检测到 RealSense 设备！请确认 D435i 已连接')
                sys.exit(1)

            device = devices[0]
            self.get_logger().info(
                f'相机: {device.get_info(rs.camera_info.name)}'
            )
            try:
                fw = device.get_info(rs.camera_info.firmware_version)
                self.get_logger().info(f'固件: {fw}')
            except Exception:
                pass

            config.enable_stream(rs.stream.color, 640, 480, rs.format.bgr8, 30)
            self.pipeline.start(config)
            self.get_logger().info('相机已启动 (640x480 @ 30Hz)')

        except Exception as e:
            self.get_logger().error(f'相机初始化失败: {e}')
            sys.exit(1)

    def _process_frame(self):
        """处理一帧图像 (定时器回调)"""
        if not self._running:
            return

        try:
            frames = self.pipeline.wait_for_frames(1000)
            color_frame = frames.get_color_frame()
            if not color_frame:
                return

            color_image = np.asanyarray(color_frame.get_data())
            self.frame_count += 1

            # --- 黑线检测 ---
            result, offset, points_count, _ = self.detector.detect(color_image)

            line_detected = points_count >= 1
            line_confident = points_count >= self.detect_threshold

            # --- 运动控制 ---
            conn_status = 'DISABLED'
            if self.enable_motion and self.sport_client:
                if line_detected:
                    self.lost_counter = 0
                    if not self.line_was_detected:
                        self.get_logger().info(
                            f'[Line] 检测到黑线! (点数:{points_count}) 全速巡线'
                        )
                        self.line_was_detected = True
                        self.integral_error = 0.0

                    if line_confident:
                        # PI 控制
                        self.error_history.append(offset)
                        smooth_offset = float(np.mean(self.error_history))

                        self.integral_error += offset
                        self.integral_error = float(
                            np.clip(self.integral_error, -500, 500)
                        )

                        angular_z = float(np.clip(
                            -self.kp * smooth_offset - self.ki * self.integral_error,
                            -self.max_angular, self.max_angular,
                        ))
                        self.last_angular = angular_z
                        status_text = f'FOLLOW offset={smooth_offset:.0f}px'
                    else:
                        angular_z = 0.0
                        status_text = f'FWD pts={points_count} (直走)'

                    self.sport_client.move(self.speed, 0.0, angular_z)
                    vel_text = f'v={self.speed:.2f} w={angular_z:.3f}'

                else:
                    self.lost_counter += 1
                    self.error_history.clear()

                    if self.lost_counter <= self.lost_threshold:
                        self.sport_client.move(
                            self.speed, 0.0, self.last_angular * 0.3
                        )
                        status_text = f'FWD! lost={self.lost_counter}/{self.lost_threshold}'
                        vel_text = f'v={self.speed:.2f} w={self.last_angular*0.3:.3f}'
                    elif self.lost_counter <= self.lost_threshold * 2:
                        self.sport_client.move(self.speed * self.low_speed_ratio, 0.0, 0.0)
                        status_text = f'SLOW lost={self.lost_counter}'
                        vel_text = f'v={self.speed*self.low_speed_ratio:.2f} w=0'
                    else:
                        if self.line_was_detected:
                            self.get_logger().info(
                                f'[Line] 黑线长时间消失! ({self.lost_counter}帧), 停止'
                            )
                            self.line_was_detected = False
                            self.integral_error = 0.0
                        self.sport_client.stop_move()
                        status_text = f'STOP lost={self.lost_counter}'
                        vel_text = 'v=0 w=0'

                conn_status = (
                    'CONNECTED' if self.sport_client.is_connected() else 'NO_DATA'
                )
            else:
                status_text = f'Offset: {offset}' if offset != 0 else 'No line'
                vel_text = 'MOTION OFF'

            # --- 画面标注 ---
            cv2.putText(
                result, f'Th:{self.gray_threshold} | Pts:{points_count}',
                (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 2,
            )
            cv2.putText(
                result, status_text, (10, 50),
                cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 0), 2,
            )
            cv2.putText(
                result, vel_text, (10, 75),
                cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 200, 255), 2,
            )
            cv2.putText(
                result, f'ROS2: {conn_status}', (10, 100),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                (0, 255, 0) if conn_status == 'CONNECTED' else (0, 0, 255), 2,
            )

            # 底部状态条: 绿=检测到线, 红=未检测到
            bar_color = (0, 255, 0) if line_detected else (0, 0, 255)
            cv2.rectangle(
                result,
                (0, result.shape[0] - 5),
                (result.shape[1], result.shape[0]),
                bar_color, -1,
            )

            # --- 显示 ---
            cv2.imshow('Go2 Trackline — ROS2', result)
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                self._running = False
            elif key == ord('s'):
                filename = f"trackline_{time.strftime('%Y%m%d_%H%M%S')}.jpg"
                cv2.imwrite(filename, result)
                self.get_logger().info(f'截图已保存: {filename}')

            # --- HTTP 更新 ---
            if self.http_server:
                _, jpeg = cv2.imencode(
                    '.jpg', result, [cv2.IMWRITE_JPEG_QUALITY, 75]
                )
                self.http_server.update(
                    jpeg.tobytes(),
                    status=status_text,
                    vel=vel_text,
                    conn=conn_status,
                    points=str(points_count),
                )

            # 定期 FPS 输出
            if self.frame_count % 30 == 0:
                elapsed = time.time() - self.start_time
                fps = self.frame_count / elapsed if elapsed > 0 else 0
                self.get_logger().info(
                    f'FPS:{fps:.1f} | {status_text} | {vel_text}',
                    throttle_duration_sec=2.0,
                )

        except Exception as e:
            self.get_logger().error(f'帧处理异常: {e}')

    def _http_cmd_callback(self, cmd: str):
        """HTTP 调试页面运动命令回调"""
        if not self.sport_client:
            return
        try:
            if cmd == 'stand_up':
                self.sport_client.stand_up()
            elif cmd == 'stand_down':
                self.sport_client.stand_down()
            elif cmd == 'balance_stand':
                self.sport_client.balance_stand()
            elif cmd == 'damp':
                self.sport_client.damp()
            elif cmd == 'stop':
                self.sport_client.stop_move()
        except Exception as e:
            self.get_logger().error(f'HTTP 命令执行失败: {e}')

    def _print_status(self):
        """打印运行状态信息"""
        self.get_logger().info('=' * 55)
        self.get_logger().info('  Go2 黑线巡线 — ROS2 原生控制')
        if self.enable_motion:
            self.get_logger().info('  运动控制: ROS2 SportClient (CycloneDDS)')
        else:
            self.get_logger().info('  运动控制: 禁用 (仅调试)')
        self.get_logger().info(f'  速度: {self.speed} m/s | P:{self.kp} I:{self.ki}')
        if self.enable_http:
            self.get_logger().info(f'  调试页面: http://127.0.0.1:{self.http_port}')
        self.get_logger().info('  q - 退出 | s - 保存截图')
        self.get_logger().info('=' * 55)

    def cleanup(self):
        """清理资源"""
        self._running = False
        self.get_logger().info('正在停止...')

        if self.sport_client:
            self.sport_client.stop_move()
            time.sleep(0.1)

        if self.pipeline:
            self.pipeline.stop()

        cv2.destroyAllWindows()

        if self.http_server:
            self.http_server.stop()

    @property
    def is_running(self):
        return self._running


def main(args=None):
    rclpy.init(args=args)

    node = TracklineNode()

    # 使用 MultiThreadedExecutor 支持定时器和订阅并发
    executor = MultiThreadedExecutor(num_threads=2)
    executor.add_node(node)

    try:
        while rclpy.ok() and node.is_running:
            executor.spin_once(timeout_sec=0.1)
    except KeyboardInterrupt:
        node.get_logger().info('收到退出信号 (Ctrl+C)')
    finally:
        node.cleanup()
        executor.shutdown()
        rclpy.shutdown()
        print('[Main] 退出完成。')


if __name__ == '__main__':
    main()
