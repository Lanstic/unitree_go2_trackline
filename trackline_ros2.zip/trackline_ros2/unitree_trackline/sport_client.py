#!/usr/bin/env python3
"""
Go2 ROS2 运动控制客户端
========================
通过 ROS2 原生话题 (unitree_api/Request) 直接控制 Go2 运动，
无需 SDK2 Python 绑定。运动指令通过 CycloneDDS 直接发送给机器人。

API 参考:
    Move:         api_id=1008  {"vx": ..., "vy": ..., "vyaw": ...}
    StandUp:      api_id=1004
    StandDown:    api_id=1005
    BalanceStand: api_id=1002
    StopMove:     api_id=1003
    Damp:         api_id=1001
    RecoveryStand:api_id=1006
    Sit:          api_id=1009
    RiseSit:      api_id=1010
    SpeedLevel:   api_id=1015  {"level": 1|2}
    Euler:        api_id=1007  {"roll": ..., "pitch": ..., "yaw": ...}
"""

import json
import time
import threading
from collections import deque
from typing import Optional, Tuple

import numpy as np
import rclpy
from rclpy.node import Node
from unitree_api.msg import Request, RequestHeader, RequestIdentity
from unitree_go.msg import SportModeState


# API IDs (与 C++ ros2_sport_client.h 保持一致)
API_ID = {
    'Damp': 1001,
    'BalanceStand': 1002,
    'StopMove': 1003,
    'StandUp': 1004,
    'StandDown': 1005,
    'RecoveryStand': 1006,
    'Euler': 1007,
    'Move': 1008,
    'Sit': 1009,
    'RiseSit': 1010,
    'SpeedLevel': 1015,
    'Hello': 1016,
    'Stretch': 1017,
    'Dance1': 1022,
    'Dance2': 1023,
    'Pose': 1028,
    'Scrape': 1029,
    'FrontJump': 1031,
    'Heart': 1036,
    'FreeWalk': 2045,
    'FreeBound': 2046,
    'FreeJump': 2047,
    'FreeAvoid': 2048,
}


class SportClient:
    """
    Go2 ROS2 运动客户端

    使用 ROS2 原生话题发布运动指令，直接与 Go2 通信。

    用法:
        client = SportClient(node)
        client.stand_up()
        client.move(vx=0.3, vyaw=0.1)
        client.stop_move()
    """

    # 高频状态话题
    TOPIC_HIGHSTATE = 'lf/sportmodestate'
    REQUEST_TOPIC = '/api/sport/request'

    def __init__(self, node: Node):
        """
        参数:
            node: ROS2 Node 实例
        """
        self._node = node
        self._logger = node.get_logger()

        # 请求发布器
        self._req_pub = node.create_publisher(Request, self.REQUEST_TOPIC, 10)

        # 状态订阅
        self._state: Optional[SportModeState] = None
        self._state_lock = threading.Lock()
        self._state_sub = node.create_subscription(
            SportModeState,
            self.TOPIC_HIGHSTATE,
            self._state_callback,
            1,
        )

        # 速度平滑
        self._vel_filter = deque(maxlen=3)
        self._current_gait = 0  # 0=idle, 1=balanceStand, 3=locomotion...

        # 请求 ID 计数器
        self._req_id_counter = 0

    def _state_callback(self, msg: SportModeState):
        """接收机器人状态"""
        with self._state_lock:
            self._state = msg
            self._current_gait = msg.gait_type

    def _next_req_id(self) -> int:
        """生成递增请求 ID"""
        self._req_id_counter += 1
        return self._req_id_counter

    def _build_request(self, api_id: int, parameter: dict = None) -> Request:
        """构建 API 请求消息"""
        req = Request()
        req.header.identity.id = self._next_req_id()
        req.header.identity.api_id = api_id
        if parameter:
            req.parameter = json.dumps(parameter)
        return req

    def _publish(self, req: Request):
        """发布请求"""
        self._req_pub.publish(req)

    # ==================== 基础运动 API ====================

    def damp(self):
        """阻尼模式 (1001)"""
        req = self._build_request(API_ID['Damp'])
        self._publish(req)
        self._logger.info('[SportClient] Damp')

    def balance_stand(self):
        """平衡站立 (1002)"""
        req = self._build_request(API_ID['BalanceStand'])
        self._publish(req)
        self._logger.info('[SportClient] BalanceStand')

    def stop_move(self):
        """停止移动 (1003)"""
        req = self._build_request(API_ID['StopMove'])
        self._publish(req)

    def stand_up(self):
        """起立 (1004)"""
        req = self._build_request(API_ID['StandUp'])
        self._publish(req)
        self._logger.info('[SportClient] StandUp')

    def stand_down(self):
        """趴下 (1005)"""
        req = self._build_request(API_ID['StandDown'])
        self._publish(req)
        self._logger.info('[SportClient] StandDown')

    def recovery_stand(self):
        """恢复站立 (1006)"""
        req = self._build_request(API_ID['RecoveryStand'])
        self._publish(req)
        self._logger.info('[SportClient] RecoveryStand')

    def euler(self, roll: float = 0.0, pitch: float = 0.0, yaw: float = 0.0):
        """欧拉角控制 (1007)"""
        req = self._build_request(API_ID['Euler'], {
            'roll': roll, 'pitch': pitch, 'yaw': yaw
        })
        self._publish(req)

    def move(self, vx: float, vy: float = 0.0, vyaw: float = 0.0):
        """
        速度移动 (1008)

        参数:
            vx:   前进速度 (m/s), 正=前进
            vy:   横向速度 (m/s), 正=左移
            vyaw: 角速度 (rad/s), 正=左转
        """
        # 速度平滑
        self._vel_filter.append((vx, vyaw))
        if len(self._vel_filter) >= 2:
            vx = float(np.mean([v[0] for v in self._vel_filter]))
            vyaw = float(np.mean([v[1] for v in self._vel_filter]))

        req = self._build_request(API_ID['Move'], {
            'vx': vx, 'vy': vy, 'vyaw': vyaw
        })
        self._publish(req)

    def sit(self):
        """坐下 (1009)"""
        req = self._build_request(API_ID['Sit'])
        self._publish(req)
        self._logger.info('[SportClient] Sit')

    def rise_sit(self):
        """站起 (1010)"""
        req = self._build_request(API_ID['RiseSit'])
        self._publish(req)
        self._logger.info('[SportClient] RiseSit')

    def speed_level(self, level: int):
        """设置速度级别 (1015), level=1 慢速, level=2 快速"""
        req = self._build_request(API_ID['SpeedLevel'], {'level': level})
        self._publish(req)

    def hello(self):
        """挥手 (1016)"""
        req = self._build_request(API_ID['Hello'])
        self._publish(req)

    def stretch(self):
        """伸展 (1017)"""
        req = self._build_request(API_ID['Stretch'])
        self._publish(req)

    def dance1(self):
        """舞蹈1 (1022)"""
        req = self._build_request(API_ID['Dance1'])
        self._publish(req)

    def dance2(self):
        """舞蹈2 (1023)"""
        req = self._build_request(API_ID['Dance2'])
        self._publish(req)

    def front_jump(self):
        """前跳 (1031)"""
        req = self._build_request(API_ID['FrontJump'])
        self._publish(req)

    def heart(self):
        """比心 (1036)"""
        req = self._build_request(API_ID['Heart'])
        self._publish(req)

    # ==================== 状态查询 ====================

    def get_state(self) -> Optional[SportModeState]:
        """获取最新机器人运动状态"""
        with self._state_lock:
            return self._state

    def get_position(self) -> Tuple[float, float, float]:
        """获取当前位置 (x, y, z)"""
        state = self.get_state()
        if state is None:
            return (0.0, 0.0, 0.0)
        return (state.position[0], state.position[1], state.position[2])

    def get_velocity(self) -> Tuple[float, float, float, float]:
        """获取当前速度 (vx, vy, vz, yaw_speed)"""
        state = self.get_state()
        if state is None:
            return (0.0, 0.0, 0.0, 0.0)
        return (state.velocity[0], state.velocity[1],
                state.velocity[2], state.yaw_speed)

    def get_gait_type(self) -> int:
        """获取当前步态类型"""
        with self._state_lock:
            return self._current_gait

    def is_connected(self) -> bool:
        """检查是否有机器人状态数据"""
        with self._state_lock:
            return self._state is not None
