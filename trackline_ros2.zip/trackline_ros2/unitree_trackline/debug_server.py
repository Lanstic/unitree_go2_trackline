#!/usr/bin/env python3
"""
HTTP 调试服务器
===============
轻量级 HTTP 服务器，在浏览器中实时查看黑线检测画面和运动状态。
与 ROS2 节点松耦合，通过回调更新画面数据。
"""

import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import Optional


HTML_PAGE = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Go2 巡线 - ROS2 D435i</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{
  font-family:'Segoe UI',Arial,sans-serif;
  text-align:center;
  background:#0d1117;
  color:#c9d1d9;
  padding:20px;
  min-height:100vh;
}
h1{color:#58a6ff;font-size:22px;margin-bottom:5px}
.subtitle{color:#8b949e;font-size:13px;margin-bottom:18px}
.panel{
  background:#161b22;
  border:1px solid #30363d;
  border-radius:12px;
  padding:15px;
  display:inline-block;
  box-shadow:0 4px 24px rgba(0,0,0,.3);
}
.panel img{
  border-radius:8px;
  width:640px;
  height:480px;
  object-fit:contain;
  background:#000;
}
.info{
  margin-top:12px;
  font-size:14px;
  color:#8b949e;
  display:flex;
  gap:20px;
  justify-content:center;
  flex-wrap:wrap;
}
.fps{color:#d2a8ff;font-size:12px;margin-top:5px}
.status{color:#3fb950;font-weight:bold}
.status.offline{color:#f85149}
.status.warn{color:#d2991d}
.controls{
  margin-top:15px;
  display:flex;
  gap:12px;
  justify-content:center;
  flex-wrap:wrap;
}
.controls button{
  background:#21262d;
  color:#c9d1d9;
  border:1px solid #30363d;
  border-radius:6px;
  padding:6px 16px;
  cursor:pointer;
  font-size:13px;
}
.controls button:hover{background:#30363d}
.controls button.active{background:#1f6feb;border-color:#1f6feb}
</style>
</head>
<body>
<h1>🐕 Go2 黑线巡线 — ROS2 实时画面</h1>
<div class="subtitle">RealSense D435i + Unitree ROS2 (CycloneDDS)</div>
<div class="panel">
  <h2 style="color:#58a6ff;font-size:16px;margin-bottom:8px;">调试画面</h2>
  <img id="debugImg" alt="等待画面...">
  <div class="fps">刷新率: <span id="fpsCounter">--</span> fps</div>
</div>
<div class="info">
  <span>SDK2: <span id="connStatus" class="status">--</span></span>
  <span>状态: <span id="statusText">--</span></span>
  <span>速度: <span id="velText">v=0 w=0</span></span>
  <span>点数: <span id="ptsText">0</span></span>
</div>
<div class="controls">
  <button onclick="sendCmd('stand_up')">起立</button>
  <button onclick="sendCmd('stand_down')">趴下</button>
  <button onclick="sendCmd('balance_stand')">平衡站立</button>
  <button onclick="sendCmd('damp')">阻尼</button>
  <button onclick="sendCmd('stop')">停止</button>
</div>
<script>
let count=0,fps=0;
setInterval(()=>{fps=count;count=0},1000);

async function refresh(){
  try{
    let r=await fetch('/snapshot?t='+Date.now());
    if(!r.ok)throw new Error('HTTP '+r.status);
    let b=await r.blob(),url=URL.createObjectURL(b);
    let img=document.getElementById('debugImg'),old=img.src;
    img.src=url;
    if(old.startsWith('blob:'))URL.revokeObjectURL(old);
    count++;
    document.getElementById('fpsCounter').textContent=fps;

    let st=r.headers.get('X-Status')||'--';
    let conn=r.headers.get('X-Connection')||'--';
    let vel=r.headers.get('X-Velocity')||'v=0 w=0';
    let pts=r.headers.get('X-Points')||'0';

    document.getElementById('statusText').textContent=st;
    document.getElementById('velText').textContent=vel;
    document.getElementById('ptsText').textContent=pts;

    let connEl=document.getElementById('connStatus');
    connEl.textContent=conn;
    connEl.className=conn==='CONNECTED'?'status':'status offline';
  }catch(e){console.error(e)}
  setTimeout(refresh,30);
}

async function sendCmd(cmd){
  try{
    await fetch('/cmd/'+cmd,{method:'POST'});
  }catch(e){console.error(e)}
}

refresh();
</script>
</body>
</html>"""


class DebugHTTPServer:
    """
    轻量 HTTP 调试服务器

    用法:
        server = DebugHTTPServer(host='0.0.0.0', port=8081)
        server.start()

        # 在主循环中
        _, jpeg = cv2.imencode('.jpg', frame)
        server.update(jpeg.tobytes(), status='FOLLOW', vel='v=0.3 w=0.1')
    """

    def __init__(self, host: str = '0.0.0.0', port: int = 8081):
        self.host = host
        self.port = port
        self.lock = threading.Lock()
        self.latest_jpeg: Optional[bytes] = None
        self.status_text = '--'
        self.vel_text = 'v=0 w=0'
        self.conn_status = 'DISCONNECTED'
        self.points_count = '0'
        self.server: Optional[HTTPServer] = None
        self._cmd_callback = None  # 可选的命令回调

    def update(
        self,
        jpeg_bytes: bytes,
        status: str = '',
        vel: str = '',
        conn: str = '',
        points: str = '',
    ):
        """更新最新画面和状态信息（线程安全）"""
        with self.lock:
            self.latest_jpeg = jpeg_bytes
            if status:
                self.status_text = status
            if vel:
                self.vel_text = vel
            if conn:
                self.conn_status = conn
            if points:
                self.points_count = points

    def set_cmd_callback(self, callback):
        """设置运动命令回调函数 callback(cmd_name)"""
        self._cmd_callback = callback

    def start(self):
        """启动 HTTP 服务器（后台线程）"""
        parent = self

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path == '/' or self.path == '/index.html':
                    self.send_response(200)
                    self.send_header('Content-Type', 'text/html; charset=utf-8')
                    self.end_headers()
                    self.wfile.write(HTML_PAGE.encode())
                elif self.path.startswith('/snapshot'):
                    with parent.lock:
                        data = parent.latest_jpeg
                        st = parent.status_text
                        vel = parent.vel_text
                        conn = parent.conn_status
                        pts = parent.points_count
                    if data:
                        self.send_response(200)
                        self.send_header('Content-Type', 'image/jpeg')
                        self.send_header('Cache-Control', 'no-cache')
                        self.send_header('Content-Length', str(len(data)))
                        self.send_header('X-Status', st)
                        self.send_header('X-Velocity', vel)
                        self.send_header('X-Connection', conn)
                        self.send_header('X-Points', pts)
                        self.end_headers()
                        self.wfile.write(data)
                    else:
                        self.send_response(503)
                        self.end_headers()
                else:
                    self.send_response(404)
                    self.end_headers()

            def do_POST(self):
                if self.path.startswith('/cmd/'):
                    cmd = self.path[len('/cmd/'):]
                    if parent._cmd_callback:
                        parent._cmd_callback(cmd)
                    self.send_response(200)
                    self.send_header('Content-Type', 'text/plain')
                    self.end_headers()
                    self.wfile.write(f'OK: {cmd}'.encode())
                else:
                    self.send_response(404)
                    self.end_headers()

            def log_message(self, format, *args):
                pass  # 静默 HTTP 日志

        self.server = HTTPServer((self.host, self.port), Handler)
        t = threading.Thread(target=self.server.serve_forever, daemon=True)
        t.start()
        print(f'[HTTP] 调试页面: http://127.0.0.1:{self.port}')

    def stop(self):
        """停止 HTTP 服务器"""
        if self.server:
            self.server.shutdown()
            self.server = None
