# Go2 黑线巡线 — ROS2 原生版

基于 Unitree ROS2 原生通信的 Go2 机器狗黑线巡线，无需 SDK2 Python 绑定。
通过 CycloneDDS 直接与 Go2 通信，使用 RealSense D435i 视觉检测黑线。

## 与 trackline (SDK2 版) 的区别

| 特性 | ROS2 版 (本项目) | SDK2 直连版 (trackline.py) |
|------|-----------------|---------------------------|
| 通信方式 | ROS2 topic (CycloneDDS) | SDK2 Python SportClient |
| 依赖 | ROS2 + unitree_go/unitree_api | unitree_sdk2_python |
| 参数管理 | ROS2 Parameters (动态可调) | 命令行参数 |
| 语言 | Python (ROS2 rclpy) | Python (独立脚本) |
| 启动方式 | `ros2 launch` / `ros2 run` | `python3 trackline.py` |
| 与其他 ROS2 工具集成 | ✓ (rviz2, rosbag, etc.) | ✗ |

## 硬件要求

- Unitree Go2 机器狗
- Intel RealSense D435i 深度相机
- Ubuntu 20.04+ / ROS2 Foxy 或 Humble

## 安装

### 1. 编译 Unitree ROS2 工作空间

```bash
# 安装 ROS2 依赖
sudo apt install ros-$ROS_DISTRO-rmw-cyclonedds-cpp
sudo apt install ros-$ROS_DISTRO-rosidl-generator-dds-idl
sudo apt install libyaml-cpp-dev

# 编译 cyclonedds_ws
cd ~/unitree_ros2/cyclonedds_ws
source /opt/ros/$ROS_DISTRO/setup.bash
colcon build

# 编译 example (包含 trackline 和其他示例)
cd ~/unitree_ros2/example
source ~/unitree_ros2/cyclonedds_ws/install/setup.bash
colcon build
```

### 2. 安装 Python 依赖

```bash
pip install opencv-python numpy pyrealsense2
```

## 使用方法

### 1. 连接 Go2

用网线连接 Go2 和电脑，设置电脑 IP 为 `192.168.123.99/24`。

### 2. 配置环境

```bash
# 自动检测网口
source ~/unitree_ros2/setup.sh

# 或指定网口
source ~/unitree_ros2/setup.sh eth0

# 验证连接
ros2 topic list | grep sport
```

### 3. 启动巡线

```bash
# 方式一：直接运行
ros2 run unitree_trackline trackline_node

# 方式二：launch 文件 (带参数)
ros2 launch unitree_trackline trackline.launch.py

# 方式三：带自定义参数
ros2 launch unitree_trackline trackline.launch.py \
    speed:=0.3 \
    kp:=0.008 \
    gray_threshold:=70

# 方式四：使用 YAML 参数文件
ros2 run unitree_trackline trackline_node \
    --ros-args --params-file ~/unitree_ros2/example/src/unitree_trackline/config/trackline_params.yaml
```

### 4. 仅调试画面 (不控制机器人)

```bash
ros2 launch unitree_trackline trackline.launch.py enable_motion:=false
```

### 5. 查看调试页面

浏览器打开 `http://127.0.0.1:8081`

## 动态参数调整

运行时可通过 ROS2 命令行动态调整参数：

```bash
# 查看当前参数
ros2 param list

# 调整速度
ros2 param set /trackline_node speed 0.4

# 调整 P 系数
ros2 param set /trackline_node kp 0.008

# 调整灰度阈值
ros2 param set /trackline_node gray_threshold 70
```

## 参数说明

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `speed` | 0.3 | 前进线速度 (m/s) |
| `kp` | 0.005 | P 控制器比例系数 |
| `ki` | 0.0001 | I 控制器积分系数 |
| `max_angular` | 0.5 | 最大角速度 (rad/s) |
| `lost_threshold` | 30 | 丢线停止阈值 (帧) |
| `detect_threshold` | 2 | 最少有效检测点数 |
| `gray_threshold` | 80 | 黑线灰度阈值 (0-255) |
| `http_port` | 8081 | HTTP 调试服务器端口 |
| `enable_http` | true | 是否启用 HTTP 调试 |
| `enable_motion` | true | 是否启用运动控制 |
| `low_speed_ratio` | 0.5 | 丢线减速比例 |
| `scan_lines` | 20 | 黑线扫描线数量 |
| `min_width` | 8 | 最小线宽 (像素) |

## 包结构

```
unitree_trackline/
├── package.xml                 # ROS2 包元数据
├── setup.py                    # Python 安装脚本
├── setup.cfg
├── resource/
│   └── unitree_trackline       # ament 索引标记
├── launch/
│   └── trackline.launch.py     # ROS2 Launch 文件
├── config/
│   └── trackline_params.yaml   # 默认参数配置
├── unitree_trackline/
│   ├── __init__.py
│   ├── trackline_node.py       # 主 ROS2 节点
│   ├── vision.py               # 黑线视觉检测模块
│   ├── sport_client.py         # Go2 ROS2 运动客户端
│   └── debug_server.py         # HTTP 调试服务器
└── README.md
```

## 模块说明

### vision.py — 黑线检测
独立的黑线检测模块，可脱离 ROS2 使用：
```python
from unitree_trackline.vision import BlackLineDetector
detector = BlackLineDetector(threshold=80)
result, offset, count, points = detector.detect(frame)
```

### sport_client.py — 运动控制
ROS2 原生 Go2 运动客户端，封装了 Unitree 运动 API：
```python
from unitree_trackline.sport_client import SportClient
client = SportClient(node)
client.stand_up()
client.move(vx=0.3, vyaw=0.1)
client.stop_move()
```

### debug_server.py — 调试服务器
轻量 HTTP 服务器，提供浏览器实时画面和运动命令按钮。

## 故障排除

### 相机未检测到
```bash
# 检查 USB 设备
lsusb | grep Intel
# 检查 udev 规则 (可能需要 sudo)
```

### ROS2 话题无数据
```bash
# 检查连接
ros2 topic list
# 检查网口 IP 是否为 192.168.123.99
ip addr show
# 测试连通
ping 192.168.123.161
```

### 运动指令无响应
确保 Go2 处于运动模式 (非阻尼/锁定)，在 HTTP 调试页面点击"平衡站立"。
